---
name: 业务-T 知识库200问答对生成
description: >
  阿里巴巴国际站供应商 AI 私域知识库一键生成技能。给个店铺链接，它就自动潜入你的店、
  全网把你的底细摸清楚（官网、领英、展会、认证全挖一遍），然后帮你写出 200 条专业又
  有销售力的中英双语问答（QA）。把这套喂给阿里后台的 AI 生意助手，你的 AI 就能像个
  干了十年的老业务，24 小时在线接客，专业不掉链子。还会自动列出哪些信息网上查不到、
  需要你手动补，确保知识库一个死角都没有。
  触发关键词：知识库、QA、问答库、问答对、AI生意助手、智能接待训练、私域知识库、
  国际站知识库、供应商知识库、200问、alibaba KB。
  适用场景：用户给出国际站供应商链接（alibaba.com / xxx.en.alibaba.com），
  要生成可直接上传到 AI 生意助手后台的标准化知识库时触发。
user-invocable: true
always_apply: false
---

# 阿里国际站供应商 AI 知识库问答对生成（一键 200 问）

## 这技能是干嘛的（大白话版）

简单说，它是个帮你**训练 AI 客服**的金牌策划。

你开了阿里国际站，后台有个"AI 生意助手"，可以替你 7×24 小时回客户。但这玩意儿不喂料就是个傻子——客户问个认证、问个起订量、问个交期，它要么答不上来，要么瞎答。

这技能干的就是：**自动把你公司的底细摸清楚，帮你写好 200 条专业问答，让你的 AI 一开口就像个十年老业务。** 客户半夜来询盘，AI 也能对答如流，主打一个"不掉链子、不丢单"。

**四个核心本事：**
1. **全网背景侦察** — 不光扒阿里，还去搜你的官网、领英、Facebook、展会记录，把你的真实实力摸透。
2. **11 大模块全覆盖** — 从公司资质、产品参数、定制流程到售后物流，把 AI 的知识盲区全补齐。
3. **行业灵魂注入** — 内置阿里国际站官方**全部 41 个一级类目**的认证/关键词/买家痛点三件套，配套 3615 个三级类目参考文件；表里没有的还有"通用提取公式"现场生成，做到**任意类目都能套**，让 AI 说话有深度、能"教育"买家。
4. **缺口预警** — 自动列出哪些信息网上查不到，提醒你手动补，绝不瞎编。

---

## 执行流程（严格按这 6 步走，约 30 分钟）

```
输入：供应商国际站链接（URL）
        ↓
Step 1  企业身份锁定        （2 分钟）
        ↓
Step 2  全网五维调研        （10 分钟）
        ↓
Step 3  行业通识匹配        （3 分钟）
        ↓
Step 4  生成 200 条 QA      （15 分钟）
        ↓
Step 5  缺口补全清单        （2 分钟）
        ↓
Step 6  打包交付            （2 分钟）
        ↓
输出：200 条 QA 知识库（.md） + 缺口清单 + 维护建议
```

---

### Step 1：企业身份锁定（先搞清楚"你是谁"）

**目标**：2 分钟内锁定这家供应商的核心标签。

**怎么干：**
1. 用 `web_fetch` 抓供应商主页（`https://xxx.en.alibaba.com/`）和它的 `company_profile.html`。
2. 抓不动时（反爬/验证码）用 `browser` 直接打开店铺主页做数据建模，再不行转 `web_search`。
3. 重点扒这些字段：

| 信息项 | 一般在哪 | 重要度 |
|--------|---------|--------|
| 公司中英文全称 | 顶部 / About Us | ⭐⭐⭐ |
| 主营产品类目 | 导航栏 / 首页分类 | ⭐⭐⭐ |
| 工厂 or 贸易商 | 标签栏 | ⭐⭐⭐ |
| 已有认证标志 | 右侧信息栏 | ⭐⭐⭐ |
| 开店年限 / 星级勋章 | 信息栏 | ⭐⭐ |
| 员工人数 / 厂房面积 | Company Profile | ⭐⭐ |
| 主要出口市场 | Company Profile | ⭐⭐ |

**遇到坑怎么办：**
- 页面"流量异常"或弹验证码 → 立刻转 `web_search`，关键词：`"[公司英文名]" alibaba profile products certifications`
- 是新店、信息少得可怜 → 启用**极简模式**（见文末附录），让供应商填《极简 10 问》，查不到的数据一律标 `[待供应商确认]`

---

### Step 2：全网五维调研（把"你的实力"挖出来）

**目标**：从 5 个维度补全公司信息，让 QA 有深度、有底气。这 5 个搜索可以并行跑。

| 维度 | 搜索关键词模板 | 重点挖什么 |
|------|--------------|-----------|
| 官网 | `"[公司英文名]" official website products` | 公司简介、产品参数、核心卖点、联系方式 |
| 资质 | `"[公司英文名]" ISO BSCI CE certifications factory audit` | 认证类型、有效期、是不是第三方颁发 |
| 社媒 | `"[公司英文名]" LinkedIn Facebook Instagram` | 品牌调性、客户评价、产品实拍 |
| 展会 | `"[公司英文名]" Canton Fair exhibition trade show` | 参展年限、获奖、新品发布 |
| 竞对 | `[主营产品] manufacturer [所在城市] top supplier` | 头部企业的卖点话术、差异化方向 |

**调研记录表（每家填一份，带置信度——这步别省）：**

| 维度 | 信息来源 URL | 关键信息摘要 | 置信度 |
|------|------------|------------|--------|
| 官网 | | | 高/中/低 |
| 认证 | | | 高/中/低 |
| 社媒 | | | 高/中/低 |
| 展会 | | | 高/中/低 |
| 竞对 | | | 高/中/低 |

> 置信度低的信息，写进 QA 时要么标 `[待确认]`，要么不写。**宁可空着，也不瞎编。**

---

### Step 3：行业通识匹配（给 AI 注入"行业灵魂"）

**目标**：让 AI 不只会介绍产品，还能"教育"买家——这是高转化 AI 和傻瓜 AI 的分水岭。

**怎么匹配（三级保底，任意类目都能套）：**
1. **先定一级类目** — 按 Step 1 认出的主营产品，在下方速查表（覆盖阿里官方 41 个一级类目）找对应行业包。
2. **再细化二/三级** — 需要更精准时，查同目录参考文件 `category_reference.md`（含全部 956 二级 / 3615 三级类目），定位到具体三级类目后，结合一级行业包微调。
3. **都没有就用公式** — 实在匹配不上，用文末「通用提取公式」现场生成。
4. 把行业包内容注入**模块十一（行业通识）**，同时把行业标准参数融进**模块三（产品技术参数）**。

**行业通识速查表（覆盖阿里国际站官方全部 41 个一级类目 + 买家痛点）：**

> 本表对齐阿里国际站官方一级类目体系（41 一级 / 956 二级 / 3615 三级）。
> - **一级类目**：直接查下表，拿认证/关键词/痛点三件套。
> - **二级 / 三级类目**：查同目录参考文件 `category_reference.md`（含全部 3615 个三级类目），定位到对应一级后套用本表，再用「通用提取公式」补细分差异。
> - 表里实在没有的：用文末「通用提取公式」现场生成，做到任意类目都不掉链子。

### 大组一：电子电气与通信（家用电器·消费电子·电脑硬件软件·通信·电子元器件·电气设备与用品·灯具照明）

| 一级类目 | 核心认证 | 技术关键词 | 买家高频痛点 |
|---------|---------|-----------|------------|
| **家用电器** | CE/FCC/RoHS/PSE/ERP/UL | 功率/能效等级/无刷电机/容量/噪音 | 电压适配/认证合规/售后配件/FBA 发货 |
| **消费电子** | CE/FCC/RoHS/CB/UN38.3/蓝牙SIG | 芯片方案/续航 mAh/分辨率/协议/快充 | 兼容性/电池安全/认证/迭代快 |
| **电脑硬件与软件** | CE/FCC/RoHS/UL/能源之星 | 接口/速率/兼容性/散热/协议 | 兼容/真伪/驱动/授权合规 |
| **通信** | CE/FCC/RoHS/RED/IC/Anatel | 频段/制式/天线增益/协议 | 频段合规/网络兼容/认证 |
| **电子元器件** | RoHS/REACH/UL/ISO9001 | 封装/参数/公差/工作温度 | 真伪/批次一致/参数虚标/交期 |
| **电气设备与用品** | CE/UL/IEC/RoHS/CB | 额定电压/电流/防护 IP/绝缘等级 | 安全认证/耐用/适配标准 |
| **灯具照明** | CE/RoHS/ERP/UL/DLC/能源之星 | 流明/色温/显指 CRI/IP 等级/驱动 | 光衰/认证/驱动寿命/眩光 |

### 大组二：机械装备与工业（机械·机械零件与加工服务·工具·五金·测量与分析仪器·服务设备）

| 一级类目 | 核心认证 | 技术关键词 | 买家高频痛点 |
|---------|---------|-----------|------------|
| **机械** | CE/ISO9001/CE-MD/UL | 精度/产能/功率/材质标号/自动化程度 | 售后维修/备件供应/调试培训/质保 |
| **机械零件与加工服务** | ISO9001/IATF16949/RoHS | 公差/材质等级/表面处理/工艺 | 一致性/批次稳定/图纸还原度/交期 |
| **工具** | ISO9001/CE/GS/ANSI | 硬度 HRC/扭矩/镀层/材质/精度 | 耐用性/精度稳定/配件/握感 |
| **五金** | ISO9001/CE/REACH/SGS | 材质标号/镀层/承重/防锈/精度 | 防锈/一致性/规格精度/售后 |
| **测量与分析仪器** | CE/ISO/CNAS/校准证书 | 量程/精度/分辨率/重复性 | 校准合规/精度漂移/认证/售后 |
| **服务设备** | CE/ISO9001/NSF/UL | 容量/能耗/材质/卫生标准 | 卫生认证/耐用/能耗/售后 |

### 大组三：纺织服装鞋包配饰（服装·纺织与皮革制品·鞋类与配件·箱包·时尚配饰·钟表珠宝眼镜）

| 一级类目 | 核心认证 | 技术关键词 | 买家高频痛点 |
|---------|---------|-----------|------------|
| **服装** | OEKO-TEX/BSCI/GOTS/WRAP/CPSIA | GSM/支数/色牢度/成分/版型/尺码 | 色差/交期/MOQ/尺码体系 |
| **纺织与皮革制品** | OEKO-TEX/GRS/REACH/LWG | 克重/成分/色牢度/缩水率/皮质等级 | 批次色差/环保认证/MOQ/异味 |
| **鞋类与配件** | REACH/CPSIA/OEKO-TEX/SATRA | 鞋楦/耐磨/防滑/材质/五金 | 做工/版型/MOQ/色差 |
| **箱包** | REACH/CPSIA/OEKO-TEX | 材质/拉链五金/承重/防水/工艺 | 做工/起订量/五金质量/色差 |
| **时尚配饰** | REACH/CPSIA/镍释放/OEKO-TEX | 材质/电镀/工艺/过敏原 | 过敏/掉色/电镀脱落/认证 |
| **钟表珠宝眼镜** | REACH/镍释放/CE/FDA(镜片)/贵金属检测 | 材质/机芯/纯度/镀层/镜片参数 | 真伪/过敏/电镀/认证/精度 |

### 大组四：家居家具建材园艺（家居与园艺·家具·建筑与房地产·矿产冶金·橡胶与塑料）

| 一级类目 | 核心认证 | 技术关键词 | 买家高频痛点 |
|---------|---------|-----------|------------|
| **家居与园艺** | LFGB/FDA/CARB/REACH/CE | 材质/食品级/耐温/承重/环保等级 | 食品安全/破损率/定制周期/认证 |
| **家具** | CARB/FSC/BIFMA/REACH/CA TB117 | E0 级/承重/实木 vs 贴皮/防火 | 甲醛/破损率/定制周期/组装 |
| **建筑与房地产** | CE/CARB/EN/ASTM/ISO | 防火等级/隔热/承重/规格精度/环保 | 甲醛/规格精度/运输破损/认证 |
| **矿产冶金** | ISO9001/SGS/MTC 材质证书/MSDS | 牌号/成分/纯度/力学性能/规格 | 成分一致/批次质量/检测报告/规格 |
| **橡胶与塑料** | RoHS/REACH/FDA/SGS | 材质/硬度邵氏/熔指/环保等级 | 环保认证/批次一致/老化/异味 |

### 大组五：母婴玩具文教（玩具与爱好·办公与学习用品·礼品与工艺品）

| 一级类目 | 核心认证 | 技术关键词 | 买家高频痛点 |
|---------|---------|-----------|------------|
| **玩具与爱好** | EN71/ASTM F963/CPSC/CE/CPSIA | 年龄段/无毒材质/圆角/小件/阻燃 | 安全认证/召回风险/材质/小件吞咽 |
| **办公与学习用品** | EN71/CE/ASTM/REACH/FSC | 无毒/规格/耐用/环保/材质 | 安全/起订量/质量一致/环保 |
| **礼品与工艺品** | REACH/CPSIA/FSC/CE | 材质/工艺/电镀/无毒/包装 | 做工/MOQ/色差/认证 |

### 大组六：美妆健康医疗（美容与个人护理·健康与医疗）

| 一级类目 | 核心认证 | 技术关键词 | 买家高频痛点 |
|---------|---------|-----------|------------|
| **美容与个人护理** | FDA/MSDS/GMPC/ISO22716/CPNP | 成分/PH/保质期/包材/功效 | 成分合规/备案/保质期/过敏 |
| **健康与医疗** | CE-MDR/FDA 510K/ISO13485/CFDA | 等级分类/无菌/材质/精度 | 注册合规/认证/批次/无菌 |

### 大组七：食品农业宠物（食品饮料·农业）

| 一级类目 | 核心认证 | 技术关键词 | 买家高频痛点 |
|---------|---------|-----------|------------|
| **食品饮料** | FDA/HACCP/HALAL/KOSHER/ISO22000 | 保质期/配料/冷链/包装/添加剂 | 合规风险/保质期/清关/标签 |
| **农业** | FDA/有机认证/熏蒸证/植检证/GAP | 等级/水分/规格/产地/品种 | 清关/熏蒸/保质期/农残 |

### 大组八：化工包装运输能源安防运动环保（化工·包装与印刷·汽车与摩托车·交通运输·运动与娱乐·安全用品·能源·环境环保·库存尾货）

| 一级类目 | 核心认证 | 技术关键词 | 买家高频痛点 |
|---------|---------|-----------|------------|
| **化工** | REACH/SDS/危险品 UN/GHS/ISO | 纯度/CAS 编号/危险品分类/含量 | 合规/运输限制/MSDS/纯度 |
| **包装与印刷** | FSC/SGS/食品级/RoHS | 克重/抗压/印刷精度/材质/环保 | 破损率/定制 MOQ/环保/色差 |
| **汽车与摩托车** | IATF16949/RoHS/E-Mark/DOT | OEM 配套/耐温/防腐/适配车型 | 车型适配/质量一致/认证/售后 |
| **交通运输** | CE/ISO/EN/DOT/E-Mark | 载重/材质/安全等级/规格 | 安全认证/耐用/合规/售后 |
| **运动与娱乐** | CE/ASTM/EN/UL/CPSIA | 承重/防水 IP/耐候/材质/安全 | 安全认证/耐用/使用场景/认证 |
| **安全用品** | CE/EN/ANSI/NIOSH/ISO | 防护等级/材质/标准符合/耐用 | 防护认证/标准合规/真伪/耐用 |
| **能源** | CE/TUV/UL/IEC/RoHS | 功率/转换效率/容量/循环寿命 | 效率/认证/质保/安全 |
| **环境环保** | CE/ISO14001/NSF/RoHS | 处理量/效率/材质/能耗 | 处理效果/认证/能耗/售后 |
| **商业服务 / 库存尾货 / 等服务类** | 视具体服务而定 | 服务范围/资质/交付标准/时效 | 资质核验/交付保障/合同条款 |


### 🔧 通用提取公式（任意行业现场套用 —— 表里没有就用这个）

遇到速查表里没列的行业，**别瞎编、别空着**，按这套公式 60 秒现场生成行业通识包：

**Step ①：现场调研三连搜**（用 `web_search`）
```
1. 认证合规：  [行业名] export certification required EU US 2025
2. 技术指标：  [行业名] product key specifications buyer evaluation
3. 买家痛点：  [行业名] B2B buyer common concerns complaints FAQ
```

**Step ②：套这 5 个维度填空**（每个行业通识包都包含这 5 块）

| 维度 | 要填什么 | 怎么找 |
|------|---------|--------|
| 🛂 **核心认证** | 目标市场的强制认证（欧盟/美国/其他） | 搜"行业+certification required" |
| 📐 **关键技术指标** | 买家最看重的 3-5 个参数 | 搜"行业+specifications" |
| 😣 **买家高频痛点** | 这行最容易出问题的 3 个点 | 搜"行业+buyer concerns" |
| 📈 **行业趋势** | 未来 1-2 年方向（环保/智能/个性化） | 搜"行业+market trend 2025" |
| 🌍 **区域偏好差异** | 欧/美/中东/东南亚的不同要求 | 搜"行业+regional preferences" |

**Step ③：把结果注入两处**
- 注入 **模块十一（行业通识 Q184-Q200）** → 替换里面的 `[产品类目]` 占位
- 把关键参数同步进 **模块三（产品技术参数 Q34-Q63）**

**Step ④：沉淀**
新行业的通识包整理好后，可补进上面的速查表对应大类，越用越全（知识积累）。

> **铁律**：公式生成的内容同样守质量红线——查不到的认证/参数一律标 `[待确认]`，绝不脑补。

---

### Step 4：生成 200 条 QA（核心产出）

#### 4.1 模块结构与条数分配（锁定 200 条）

| 模块 | 名称 | 条数 | 核心覆盖 |
|------|------|:---:|---------|
| 一 | 公司基本信息 Company Profile | 15 | 身份/规模/市场/年限/研发/客户 |
| 二 | 资质与认证 Certifications | 18 | 产品认证/工厂审计/各市场合规/专利 |
| 三 | 产品与技术参数 Product & Specs | 30 | 核心参数/材质/测试/配件/使用 |
| 四 | OEM/ODM 定制 Customization | 20 | 起订量/开模/打样/IP 保护/设计协作 |
| 五 | 交期与生产 Lead Time & Production | 16 | 交期/产能/跟单/验货/分批 |
| 六 | 价格与付款 Pricing & Payment | 18 | 贸易术语/付款/折扣/样品/汇率 |
| 七 | 售后与质保 After-sales & Warranty | 16 | 质保/次品/配件/维修/故障排查 |
| 八 | 物流与配送 Shipping & Logistics | 16 | 港口/运输/FBA/追踪/装柜 |
| 九 | 竞争优势与差异化 Competitive Advantage | 16 | 差异化/品控/价格反击/案例 |
| 十 | 场景化解决方案 Scenario Solutions | 18 | 各类买家方案/人机切换 |
| 十一 | 行业通识 Industry Knowledge | 17 | 行业标准/认证科普/趋势/区域偏好 |
| **合计** | | **200** | |

#### 4.2 QA 写作质量标准

**格式（每条都这样）：**
```markdown
**Q[编号]: [问题]**
A: [回答内容]
```

**回答质量对照表（照着右边写，别学左边）：**

| 维度 | ❌ 不合格 | ✅ 合格 |
|------|----------|--------|
| 完整性 | "我们支持定制。" | "支持 LOGO 丝印/激光镭雕/全彩包装定制，起订量 500 件起，3 天内出设计初稿。" |
| 说服力 | "我们质量很好。" | "100% 出厂全检，次品率控制在 0.5% 以内，低于行业平均 1-2% 的水平。" |
| 数据支撑 | "交期较短。" | "大货通常 15-20 个工作日，旺季（Q3-Q4）建议提前 30 天下单。" |
| 行业深度 | "我们有 CE 认证。" | "CE 由 TÜV 第三方颁发（非自我声明），含完整技术文件（DoC+测试报告），可应对欧洲海关抽检。" |

#### 4.3 三类"特殊 QA"必须覆盖（高转化的灵魂）

每份知识库必须包含这三类，少一类都不合格：

**① 价格反击类（≥2 条）**
> 买家说"隔壁更便宜"时，AI 怎么不掉价地反击。讲清楚低价货的隐患（劣质料/省工序/无认证）+ 自己的长期价值。

**② 风险拒止类 / 红线（≥3 条）**
> 明确告诉 AI 什么不能承诺：没有的认证不能说有、超产能的交期不能瞎接、人为损坏不免费修。诚信是底线。

**③ 人机切换类（≥2 条）**
> 什么情况 AI 必须停下来喊人工。示例阈值：单笔订单超 $50,000、改合同条款、质量纠纷、法律问题——这些一律转专业商务。

#### 4.4 双语规范

- 所有 QA 写**中英双语**：问题和回答都给英文版（客户看英文，老板看中文）。
- 国际通用术语保持英文：MOQ / FOB / CIF / DDP / OEM / ODM / NDA / FBA / Trade Assurance。

---

### Step 5：缺口补全清单（Gap Analysis）

调研查不到、但谈单又很关键的信息，整理成《待补全清单》发给供应商确认：

```markdown
## 【待供应商确认的关键信息】

| 优先级 | 模块 | 缺失项 | 建议获取方式 |
|--------|------|--------|------------|
| 🔴 高 | 模块六 | 主力产品 FOB 报价区间 | 业务员提供 |
| 🔴 高 | 模块二 | CE 证书有效期及编号 | 查看证书原件 |
| 🟡 中 | 模块一 | 服务过的知名客户案例 | 问老板/销售总监 |
| 🟡 中 | 模块五 | 旺季最大可承接单量 | 问生产主管 |
| 🟢 低 | 模块三 | 新款产品参数（若有） | 产品目录/样品说明书 |
```

---

### Step 6：打包交付

**文件命名规范：**
```
[公司简称]_KB_QA200_[YYYYMMDD].md
```
示例：`QuanLv_KB_QA200_20260613.md`

**交付三件套：**
1. ✅ QA 知识库主文件（Markdown，可直接复制上传到 AI 生意助手后台）
2. ✅ 待补全清单（表格）
3. ✅ 知识库维护建议（见下方周期表）

> 输出文件用 `.md` 格式（不是 `.xlsx`，更不是 `.xlsl`）。如客户明确要 Excel，再单独转。

---

## 知识库维护周期建议

| 周期 | 该干啥 |
|------|--------|
| 每月 | 更新现货库存、报价有效期 |
| 每季度 | 把业务员实战遇到的新问题补进去 |
| 每半年 | 核实认证有效期、新增产品型号 QA |
| 每年 | 全面复盘，删过时内容，注入最新行业趋势 |

---

## 质量红线（这几条死守，不许破）

1. **严禁脑补** — 所有具体数据（产能/认证/价格）必须来自调研，查不到一律标 `[待确认]`。
2. **严禁空洞** — 回答不能只有"可以""支持"，必须带具体细节（数字、流程、条件）。
3. **特殊 QA 必覆盖** — 价格反击≥2、风险拒止≥3、人机切换≥2，缺一不可。
4. **行业通识不许空** — 模块十一至少 17 条真行业知识，不能拿水话凑数。
5. **信息冲突以官方为准** — 阿里描述和官方文件（证书/验厂报告）打架时，以可核实文件为准，差异处标 `[待供应商核实]`。

---

## 使用工具

- `web_fetch` / `web_search`：跨平台扒供应商背景。
- `browser`：反爬时直接开店铺主页建模。
- `write`：生成知识库 .md 文件。

---

# 附录 A：200 条 QA 可填空模板（中英双语 · 适配任意行业）

> 用法：把 `[方括号内容]` 换成供应商真实信息；`[待确认]` 表示要向供应商核实。
> 每条都给中英双语：A(中) 是给老板看的，A(EN) 是直接喂给 AI / 给客户看的。

```
公司名称：[中文全称] / [英文全称]
主营产品：[产品类目]      所在城市：[城市名]      生成日期：[YYYY-MM-DD]
```

## 【模块一】公司基本信息 Company Profile（Q1-Q15）

**Q1: 你们公司叫什么名字？主营什么产品？ / What's your company name and main products?**
A: 我们是[公司英文名]，品牌[品牌名]，专注[主营产品]的研发、设计、生产与销售，服务全球[X]个国家和地区。
A(EN): We are [Company], brand [Brand], focusing on R&D, design, manufacturing and sales of [products], serving clients in [X] countries.

**Q2: 公司成立多久了？ / How long has your company been established?**
A: 成立于[年份]，[X]年行业经验，是[城市]专注[品类]领域的[工厂/制造商]之一。
A(EN): Established in [year], with [X] years of experience, one of the leading [factories/manufacturers] of [category] in [city].

**Q3: 工厂在哪里？ / Where is your factory located?**
A: 工厂位于[省/市/工业园区]，距[最近港口]约[X]小时车程，物流便捷。
A(EN): Our factory is in [location], about [X] hours' drive from [port], with convenient logistics.

**Q4: 工厂规模有多大？ / How big is your factory?**
A: 厂房[X]平方米，员工[X]人，具备[工艺1/工艺2]全流程自主生产能力。[待确认]
A(EN): [X] sqm plant, [X] staff, full in-house production capability covering [process1/process2]. [TBC]

**Q5: 你们是工厂还是贸易公司？ / Are you a factory or trading company?**
A: 我们是[工厂/工贸一体]，不经中间商，给客户最有竞争力的价格和最直接的沟通。
A(EN): We are a [factory / manufacturer-trader], no middleman, offering the most competitive prices and direct communication.

**Q6: 你们有官网吗？ / Do you have an official website?**
A: 有，可访问[官网URL]，也可在国际站主页[alibaba链接]看全部产品。
A(EN): Yes, visit [website], or see all products on our Alibaba store [link].

**Q7: 有多少产品型号在售？ / How many product models do you offer?**
A: 目前[X]款在售，覆盖[品类1/品类2]多个系列，每年新增[X]款，欢迎告知需求精准推荐。[待确认]
A(EN): [X] active models across [series], [X] new items yearly. Tell us your needs for tailored recommendations. [TBC]

**Q8: 主要出口到哪些市场？ / Which markets do you mainly export to?**
A: 主要出口[市场1]、[市场2]、[市场3]，对各市场合规、采购习惯、物流标准都有丰富经验。
A(EN): Mainly [market1], [market2], [market3], with rich experience in their compliance, purchasing habits and logistics.

**Q9: 有自己的研发团队吗？ / Do you have an in-house R&D team?**
A: 有独立 R&D 部门，能自主设计、开模、迭代，每年完成[X]款新品开发。[待确认]
A(EN): Yes, an independent R&D dept for design, tooling and iteration, developing [X] new products yearly. [TBC]

**Q10: 有多少年出口经验？ / How many years of export experience?**
A: 外贸出口超[X]年，专业出口团队，熟悉[目标市场]贸易规则和客户需求。
A(EN): Over [X] years of export experience with a professional team familiar with [market] trade rules.

**Q11: 你们的年产值/营业额大概多少？ / What's your annual output value?**
A: 年产值约[$X]，产能稳定，具备承接大客户长期订单的实力。[待确认]
A(EN): Annual output around [$X], stable capacity, capable of long-term large-client orders. [TBC]

**Q12: 公司有没有获得过什么荣誉或称号？ / Any honors or titles?**
A: 我们获得过[高新技术企业/出口示范企业/行业协会会员]等[荣誉]，是行业内受认可的供应商。[待确认]
A(EN): We hold honors like [High-tech Enterprise / Export Demonstration / Association Member], a recognized supplier in the industry. [TBC]

**Q13: 你们服务过哪些类型的客户？ / What types of clients do you serve?**
A: 客户涵盖[品牌商/进口商/批发商/电商卖家/连锁零售]，从初创卖家到大型采购方都有成熟服务经验。
A(EN): Clients range from [brands / importers / wholesalers / e-commerce sellers / chain retailers], from startups to large buyers.

**Q14: 你们的核心团队/管理层背景如何？ / What's your core team's background?**
A: 核心团队在[行业]深耕[X]年，既懂生产工艺又懂海外市场，能从买家视角给专业建议。[待确认]
A(EN): Our core team has [X] years in [industry], understanding both production and overseas markets. [TBC]

**Q15: 怎么才能更快了解你们公司？ / How can I quickly learn more about you?**
A: 最快方式：①看本知识库；②访问官网[URL]；③直接发询盘，我们 24 小时内回复并发公司介绍 PPT/视频。
A(EN): Fastest ways: this KB, our website [URL], or send an inquiry — we reply within 24h with a company profile deck/video.

## 【模块二】资质与认证 Certifications（Q16-Q33）

**Q16: 你们产品有哪些认证？ / What certifications do your products have?**
A: 已通过[认证1]、[认证2]、[认证3]，所有文件按需提供，请告知目标市场，我们匹配对应文件。
A(EN): Certified with [cert1], [cert2], [cert3]. All docs available on request — tell us your target market.

**Q17: 有工厂审计认证吗？ / Do you have factory audit certifications?**
A: 已通过[BSCI/ISO9001/SEDEX/SA8000]，符合国际品牌商和零售商对供应链的合规要求。[待确认]
A(EN): Audited by [BSCI/ISO9001/SEDEX/SA8000], meeting global brands' supply-chain compliance. [TBC]

**Q18: 认证是自我声明还是第三方？ / Self-declared or third-party certified?**
A: 我们的[认证名]由[TÜV/SGS/Intertek/BV]第三方机构颁发，权威性高，可应对海关抽检。[待确认]
A(EN): Our [cert] is issued by third-party bodies like [TÜV/SGS/Intertek/BV], authoritative for customs checks. [TBC]

**Q19: 产品符合欧盟要求吗？ / Are products EU-compliant?**
A: 符合，通过[CE/RoHS/REACH]，满足欧盟强制要求，可在成员国合规销售。[待确认]
A(EN): Yes, certified with [CE/RoHS/REACH], compliant for sale across EU member states. [TBC]

**Q20: 能在美国市场合规销售吗？ / Compliant for the US market?**
A: 可以，持有[FCC/FDA/UL/CPSC]等美国所需认证，符合联邦法规。[待确认]
A(EN): Yes, holding [FCC/FDA/UL/CPSC] as required for US federal compliance. [TBC]

**Q21: 支持特殊市场认证申请吗？ / Support special-market certifications?**
A: 支持，如[澳洲SAA/日本PSE/加拿大IC/沙特SASO]，可协助安排检测和认证，请提前告知市场。
A(EN): Yes, e.g. [SAA/PSE/IC/SASO] — we assist testing and certification. Please inform us in advance.

**Q22: 支持第三方验厂吗？ / Do you allow third-party factory audits?**
A: 完全支持，欢迎[SGS/BV/Intertek]实地审计，随时安排，全力配合。
A(EN): Fully support — welcome on-site audits by [SGS/BV/Intertek], anytime, full cooperation.

**Q23: 有产品相关专利吗？ / Any product patents?**
A: 持有[X]项[外观/实用新型/发明]专利，核心产品受法律保护，详情可联系商务团队。[待确认]
A(EN): We hold [X] [design/utility/invention] patents protecting core products. [TBC]

**Q24: 能提供测试报告吗？ / Can you provide test reports?**
A: 有，可提供[跌落/盐雾/老化/燃烧]测试报告，告知需求即匹配对应文件。[待确认]
A(EN): Yes — [drop/salt-spray/aging/burning] test reports available on request. [TBC]

**Q25: 怎么获取完整认证文件包？ / How to get the full certification package?**
A: 询盘注明所需认证和目标市场，商务团队[X]个工作日内整理发送，敏感文件签 NDA 后提供。
A(EN): Note required certs and market in your inquiry — we send the package within [X] working days; sensitive docs after NDA.

**Q26: 认证有效期内会过期吗？怎么保证？ / How do you ensure certs stay valid?**
A: 我们建立认证台账，到期前主动续证，确保供货期间认证持续有效，可提供最新有效证书。[待确认]
A(EN): We maintain a certification ledger and renew proactively, ensuring validity throughout supply. [TBC]

**Q27: 你们的环保合规做得怎么样？ / How about environmental compliance?**
A: 产品符合[RoHS/REACH/OEKO-TEX/FSC]，不含[有害物质]，可进环保要求严格的欧美市场。
A(EN): Compliant with [RoHS/REACH/OEKO-TEX/FSC], free of [substances], fit for strict EU/US markets.

**Q28: 有社会责任相关认证吗？ / Any social-responsibility certifications?**
A: 已通过[BSCI/Sedex/SA8000]社会责任审计，劳工、安全、环境管理符合国际标准。[待确认]
A(EN): Audited by [BSCI/Sedex/SA8000] for labor, safety and environmental management. [TBC]

**Q29: 你们的质量管理体系是什么？ / What's your quality management system?**
A: 执行[ISO9001]质量管理体系，从来料到出货全流程标准化管控。[待确认]
A(EN): We run an [ISO9001] quality management system, standardized from incoming material to shipment. [TBC]

**Q30: 认证文件能验真吗？ / Can the certificates be verified?**
A: 可以，所有第三方证书都可在颁发机构官网或数据库查询验证，绝无伪造。
A(EN): Yes — all third-party certs are verifiable on the issuing body's website/database. No fakes.

**Q31: 不同产品型号认证一样吗？ / Same certs for all models?**
A: 认证按产品系列/型号区分，请告知具体型号，我们提供对应的准确证书，不混用。
A(EN): Certs differ by series/model. Tell us the exact model and we provide the matching certificate.

**Q32: 你们能协助做目标国清关合规吗？ / Help with destination-country clearance compliance?**
A: 可以，提供[目标市场]所需的合规文件清单和符合性声明，协助你顺利清关。
A(EN): Yes — we provide the compliance doc checklist and declarations needed for [market] clearance.

**Q33: ⚠️ 你们没有的认证会怎么说？（红线）/ What if you don't hold a cert? (Red line)**
A: 我们绝不谎称持有未获得的认证。如目标市场需要而我们暂无[某认证]，会如实告知并协助安排申请，诚信第一。
A(EN): We never claim certs we don't hold. If [a cert] is missing for your market, we tell you honestly and help arrange it.

## 【模块三】产品与技术参数 Product & Technical Specs（Q34-Q63）

**Q34: 你们主要有哪几类产品？ / What product categories do you have?**
A: 核心产品线[X]类：[类1]、[类2]、[类3]，覆盖[应用场景]，全系列可定制。
A(EN): [X] core lines: [cat1], [cat2], [cat3], covering [scenarios]; all customizable.

**Q35: 核心技术参数是什么？ / What are the key technical specs?**
A: [核心产品名]主要参数：[参1:值]、[参2:值]、[参3:值]，满足[行业标准]。[待确认]
A(EN): Key specs of [product]: [p1:val], [p2:val], [p3:val], meeting [standard]. [TBC]

**Q36: 主要材质是什么？有什么优势？ / What materials, and their advantages?**
A: 用[材质/规格]，相比常用的[普通材质]，[强度更高/更环保/更耐用]，寿命提升约[X]%。[待确认]
A(EN): We use [material], which is [stronger/greener/more durable] than common [material], extending life by ~[X]%. [TBC]

**Q37: 通过了哪些性能测试？ / What performance tests are passed?**
A: 出厂前过[测1/测2/测3]，标准符合[行业编号]，记录存档备查。[待确认]
A(EN): Tested with [t1/t2/t3] to [standard], records archived. [TBC]

**Q38: 有哪些规格/型号？ / What specs/models are available?**
A: 提供[X]种规格：[规1]/[规2]/[规3]，满足不同场景，详细规格表可发你参考。
A(EN): [X] specs: [s1]/[s2]/[s3] for different scenarios; full spec sheet available.

**Q39: 使用寿命/耐久性如何？ / What about lifespan/durability?**
A: 按[测试标准]，设计寿命[X 年/小时/次]，高于行业平均[X]。[待确认]
A(EN): Per [standard], designed lifespan is [X], above the industry average of [X]. [TBC]

**Q40: 有哪些颜色/外观可选？ / What colors/finishes are available?**
A: 标准色[色1/色2/色3]，支持 Pantone 定制，色差控制在行业标准内。
A(EN): Standard colors [c1/c2/c3], Pantone customization supported, color deviation within standard.

**Q41: 尺寸和重量是多少？ / What are the dimensions and weight?**
A: 标准款[长×宽×高]mm，净重约[X]kg，包装重约[X]kg，其他尺寸可定制。[待确认]
A(EN): Standard [L×W×H]mm, net ~[X]kg, packed ~[X]kg; other sizes customizable. [TBC]

**Q42: 产品环保吗？ / Are the products eco-friendly?**
A: 符合[RoHS/REACH/OEKO-TEX/FSC]，不含[有害物质]，可进环保严格的欧美市场。
A(EN): Compliant with [RoHS/REACH/OEKO-TEX/FSC], free of [substances], fit for strict markets.

**Q43: 适用电压/频率？（电气类）/ Voltage/frequency? (electrical)**
A: 标准款适配[110V/220-240V/100-240V]，频率[50/60/50-60Hz]，可按市场定制。
A(EN): Supports [110V/220-240V/100-240V], [50/60/50-60Hz], customizable per market.

**Q44: 有防水/防尘等级吗？ / Any waterproof/dustproof rating?**
A: 达[IPX4/IP65/IP68]，可在[淋雨/水下/粉尘]环境使用，测试报告可提供。[待确认]
A(EN): Rated [IPX4/IP65/IP68], usable in [rain/underwater/dusty] conditions; report available. [TBC]

**Q45: 包装尺寸和装箱量？ / Packaging size and quantity per carton?**
A: 单件[X×X×X]cm，每箱[X]件，毛重约[X]kg，20GP 约装[X]件，40HQ 约装[X]件。[待确认]
A(EN): Unit [X×X×X]cm, [X]pcs/carton, GW ~[X]kg; 20GP ~[X]pcs, 40HQ ~[X]pcs. [TBC]

**Q46: 标配包含哪些配件？ / What accessories are included?**
A: 标配：[配1]、[配2]、[配3]。选配：[选1]、[选2]，所有配件可单独采购。
A(EN): Standard: [a1], [a2], [a3]. Optional: [o1], [o2]; all separately purchasable.

**Q47: 有使用限制或注意事项吗？ / Any usage limits or precautions?**
A: 建议[注意1]、[注意2]，不建议用于[限制场景]，详见随附用户手册。
A(EN): We advise [note1], [note2]; not recommended for [scenario]. See the user manual.

**Q48: 有新款/升级版在研发吗？ / Any new/upgraded version coming?**
A: 正在研发[新功能/升级点]，预计[季度]推出，有意向可提前预约，优先向重要伙伴开放试用。[待确认]
A(EN): We're developing [feature], launching in [quarter]; key partners get early trial access. [TBC]

**Q49: 能耗/能效等级如何？ / What's the energy efficiency?**
A: 能效达[等级/数值]，相比同类省电约[X]%，帮终端客户降低使用成本。[待确认]
A(EN): Energy class [grade], saving ~[X]% vs peers, lowering end-user costs. [TBC]

**Q50: 噪音/振动等指标如何？ / What about noise/vibration?**
A: 运行噪音约[X]dB，低于行业常见[X]dB，适合[家用/办公等]安静场景。[待确认]
A(EN): Operating noise ~[X]dB, below the typical [X]dB, fit for quiet [home/office] use. [TBC]

**Q51: 材料来源稳定吗？会断供吗？ / Is material supply stable?**
A: 核心原料与[长期/优质]供应商合作，库存充足，不会因断料影响交期。
A(EN): Core materials come from [long-term] suppliers with ample stock — no supply disruptions to lead time.

**Q52: 产品适配哪些应用场景？ / What application scenarios fit?**
A: 适用于[场景1/场景2/场景3]，不同场景我们有对应配置建议，告知你的用途即可推荐。
A(EN): Suitable for [s1/s2/s3]; we recommend configs per scenario — just tell us your use case.

**Q53: 产品安全性怎么保证？ / How is product safety ensured?**
A: 通过[安全认证/测试]，关键部位做[保护设计]，从设计到出厂全程把控安全。
A(EN): Verified by [safety certs/tests], with [protective design] on key parts, safety controlled end-to-end.

**Q54: 有产品视频或实拍图吗？ / Any product videos or real photos?**
A: 有，可提供高清实拍图、细节图和功能演示视频，方便你做 listing 和营销。
A(EN): Yes — HD photos, detail shots and demo videos for your listings and marketing.

**Q55: 不同型号怎么选最合适？ / How to choose the right model?**
A: 告诉我们你的[目标市场/价位/用途]，我们按经验帮你选最匹配的型号，不让你多花冤枉钱。
A(EN): Tell us your [market/price range/use] and we'll match the best model — no overspending.

**Q56: 产品有哪些核心卖点？ / What are the key selling points?**
A: 三大卖点：①[卖点1]；②[卖点2]；③[卖点3]，这也是客户复购的主要原因。
A(EN): Three USPs: [1], [2], [3] — the main reasons customers reorder.

**Q57: 材质能提供材质证明/SGS 报告吗？ / Material certificate / SGS report?**
A: 可以，提供材质成分报告和 SGS/第三方检测，确保你拿到的料真材实料。[待确认]
A(EN): Yes — material composition and SGS/third-party reports available. [TBC]

**Q58: 产品能耐多高/多低温度？ / Temperature tolerance?**
A: 工作温度[X℃ ~ X℃]，可在[高温/低温]环境稳定运行，适合[目标市场气候]。[待确认]
A(EN): Operating range [X℃–X℃], stable in [hot/cold] conditions, fit for [climate]. [TBC]

**Q59: 产品重量/体积对运费影响大吗？ / Impact on freight cost?**
A: 我们优化了包装体积比，降低体积重，帮你节省海运/空运成本，可提供精确装柜数据。
A(EN): We optimize packing volume to cut volumetric weight, saving sea/air freight; exact loading data available.

**Q60: 能否提供样品先测一下？ / Can I test a sample first?**
A: 当然，强烈建议先打样测试，[X]个工作日出样，确认满意再下大货，稳妥。[待确认]
A(EN): Absolutely — we recommend sampling first, ready in [X] days, then bulk after approval. [TBC]

**Q61: 产品和图片/描述一致吗？ / Does the product match photos/description?**
A: 100% 一致，我们所有图片均为实拍，参数真实，绝不货不对板，可视频验货。
A(EN): 100% consistent — all photos are real, specs accurate, no discrepancies; video inspection available.

**Q62: 产品有哪些常见质量风险点？怎么规避？ / Common quality risks and how you avoid them?**
A: 行业常见风险是[风险点]，我们通过[工艺/检测]规避，把这类问题挡在出厂前。
A(EN): A common risk is [issue]; we prevent it via [process/inspection] before shipment.

**Q63: 能根据我的市场调整产品参数吗？ / Can specs be tuned for my market?**
A: 可以，按[目标市场]的电压/语言/标准/偏好做针对性调整，让产品落地即合规、即好卖。
A(EN): Yes — we adjust voltage/language/standards/preferences for [market] so it's compliant and sellable on arrival.

## 【模块四】OEM/ODM 定制 Customization（Q64-Q83）

**Q64: 支持 OEM 定制吗？ / Do you support OEM?**
A: 完全支持，超[X]年代工经验，可定制 LOGO、颜色、包装、结构，NDA 随时签。
A(EN): Fully — over [X] years of OEM experience; customize LOGO, color, packaging, structure; NDA anytime.

**Q65: OEM 最低起订量多少？ / What's the OEM MOQ?**
A: LOGO 定制[X]件起；全彩包装[X]件起；结构 ODM 开模通常[X]件起，视复杂度评估。[待确认]
A(EN): LOGO from [X]pcs; full-color packaging from [X]pcs; structural ODM from [X]pcs. [TBC]

**Q66: ODM 开模费多少？ / How much is the tooling fee?**
A: 视复杂度，模具费约[$X–$X]，模具归客户所有，量产达约定数量可全额返还。[待确认]
A(EN): Tooling ~[$X–$X] depending on complexity; mold belongs to you, fully refundable upon agreed volume. [TBC]

**Q67: 从提需求到拿样品多久？ / Lead time from brief to sample?**
A: 需求确认[X]天→3D 出图[X]天→打样[X]天→确认[X]天，全程约[X]周，配专属跟单。[待确认]
A(EN): Brief [X]d → 3D [X]d → sample [X]d → approval [X]d, ~[X] weeks total, with a dedicated merchandiser. [TBC]

**Q68: 颜色定制支持 Pantone 吗？ / Pantone color matching?**
A: 支持，按你提供的 Pantone 色号调色，色差控制 ΔE≤[X]，保品牌视觉一致。[待确认]
A(EN): Yes, matched to your Pantone code, deviation ΔE≤[X] for brand consistency. [TBC]

**Q69: 包装可以完全定制吗？ / Can packaging be fully customized?**
A: 可以，全定制彩盒/礼盒/手提袋，尺寸材质印刷工艺（哑光/亮光/UV）按品牌风格设计，也可做 FBA 标准包装。
A(EN): Yes — fully custom boxes/gift boxes/bags, with [matte/gloss/UV] finishes, including FBA-ready packaging.

**Q70: 我有设计图，能按图生产吗？ / Can you produce per my drawings?**
A: 可以，给 2D 图纸或 3D 文件（Step/STL/IGES），工程师[X]个工作日内评估可行性并报价。
A(EN): Yes — send 2D/3D files (Step/STL/IGES); engineers assess feasibility and quote within [X] days.

**Q71: 定制产品的知识产权怎么保障？ / How is my IP protected?**
A: 严格保护，签约前可先签 NDA，模具和设计归你所有，绝不把方案给任何第三方。
A(EN): Strictly protected — NDA available, mold/design owned by you, never shared with any third party.

**Q72: 能定制多语言说明书吗？ / Multi-language manuals?**
A: 可以，支持[英/德/法/西/阿拉伯语]等多语言说明书，也可按你提供文本制作。
A(EN): Yes — manuals in [EN/DE/FR/ES/AR] etc., or per your provided text.

**Q73: 可以从零开发全新产品吗？ / Can you develop a brand-new product?**
A: 可以，R&D 团队承接从概念到量产全流程，给功能需求和目标售价，我们出开发方案并报价。
A(EN): Yes — R&D handles concept-to-mass-production; share requirements and target price for a dev plan and quote.

**Q74: 打样收费吗？ / Is there a sampling fee?**
A: 定制样品收[$X]样品费+运费，下大货后样品费可全额抵扣货款。[待确认]
A(EN): Custom sample fee [$X] + freight, fully deductible from bulk payment. [TBC]

**Q75: 定制订单交期会更长吗？ / Longer lead time for custom orders?**
A: 比现货稍长，含开模的定制约[X–X]天，我们会在接单时书面确认排产档期。[待确认]
A(EN): Slightly longer — custom with tooling ~[X–X] days; we confirm the schedule in writing at order. [TBC]

**Q76: 能小批量试做定制吗？ / Small-batch custom trial?**
A: 可以，理解你要先验证市场，支持[X]件小批量定制试单，成功再放量。[待确认]
A(EN): Yes — we support a small trial batch of [X]pcs to validate the market before scaling. [TBC]

**Q77: 定制过程中能改方案吗？ / Can I revise during customization?**
A: 打样确认前可调整方案，确认后量产为保证一致性需另议，我们会提前讲清每个节点。
A(EN): Revisions allowed before sample approval; post-approval changes are discussed separately for consistency.

**Q78: 你们能帮我做产品设计建议吗？ / Can you advise on product design?**
A: 可以，结合你的目标市场和畅销趋势，主动给配色、功能、包装建议，帮你的产品更好卖。
A(EN): Yes — based on your market and best-selling trends, we proactively advise on color, function and packaging.

**Q79: 定制产品质量和标准品一样吗？ / Same quality as standard products?**
A: 一样甚至更严，定制件按同一质量体系生产+全检，不会因为是定制就降标准。
A(EN): Same or stricter — custom items follow the same QC system with full inspection.

**Q80: 能定制配套的展示/零售包装吗？ / Retail/display packaging?**
A: 可以，做适合货架陈列的彩盒、吊牌、说明卡，帮你的产品在零售端更出彩。
A(EN): Yes — shelf-ready boxes, hangtags and info cards to make your product stand out at retail.

**Q81: 模具完成后归谁？后续还能用吗？ / Who owns the mold afterward?**
A: 模具归客户所有，后续返单可直接用，不重复收模具费，也不会用你的模具给别人生产。
A(EN): The mold is yours — reusable for reorders with no repeat tooling fee, never used for others.

**Q82: 定制能配合我的品牌全案吗？ / Can you support my whole brand package?**
A: 可以，从产品、包装到说明书、合格证一整套都能按你的 VI 来，帮你打造统一品牌形象。
A(EN): Yes — product, packaging, manuals and certificates all aligned to your VI for a unified brand.

**Q83: ⚠️ 哪些定制做不了？（红线）/ What customization can't you do? (Red line)**
A: 超出现有工艺/设备能力的结构，我们会如实告知做不了或需外协，不会硬接导致质量翻车。
A(EN): For structures beyond our process/equipment, we tell you honestly rather than risk quality.

## 【模块五】交期与生产 Lead Time & Production（Q84-Q99）

**Q84: 正常生产交期多久？ / What's the normal lead time?**
A: 现货[X]个工作日发货；定制大货（有模具）[X–X]天；ODM 开模[X–X]天（含开模+首件确认）。[待确认]
A(EN): Stock: [X] days; custom bulk (with mold): [X–X] days; ODM tooling: [X–X] days. [TBC]

**Q85: 旺季交期会延误吗？ / Delays in peak season?**
A: 旺季（[月份]）是高峰，建议提前[X]天下单，接单时书面确认排产，保障你的销售节点。
A(EN): Peak ([months]) is busy — order [X] days early; we confirm the schedule in writing to protect your timeline.

**Q86: 月产能多大？能接大单吗？ / Monthly capacity for big orders?**
A: 月产能[X]件，产能充足，超[X]件的大单建议提前[X]天沟通排产。[待确认]
A(EN): Monthly capacity [X]pcs; for orders over [X]pcs, please discuss scheduling [X] days ahead. [TBC]

**Q87: 生产中能跟进进度吗？ / Can I track production progress?**
A: 可以，每单配专属跟单员，定期发图片/视频汇报（备料→开工→半成品→品检→包装→装箱）。
A(EN): Yes — a dedicated merchandiser sends photo/video updates through each stage.

**Q88: 有现货可以快发吗？ / Any stock for fast shipment?**
A: 有，常备热销款现货，[X]个工作日内发货，告知型号数量立即确认库存。[待确认]
A(EN): Yes — best-sellers in stock, shipped within [X] days; tell us model & qty to confirm. [TBC]

**Q89: 生产前能验原材料吗？ / Inspect raw materials before production?**
A: 支持，可在原料入库阶段安排第三方现场检验，也可提供原料检验报告。
A(EN): Yes — third-party incoming-material inspection or material reports available.

**Q90: 出货前能验货吗？ / Pre-shipment inspection?**
A: 支持，可安排 SGS/BV/Intertek 在我厂做出货前检验（PSI），全力配合。
A(EN): Yes — PSI by SGS/BV/Intertek at our factory, fully supported.

**Q91: 订单能分批发货吗？ / Can orders ship in batches?**
A: 可以，按你的库存节奏或仓储空间分批生产、分批发货，合同里写清分批计划。
A(EN): Yes — batch production/shipment per your inventory needs, specified in the contract.

**Q92: 怎么保证按时交货？ / How do you ensure on-time delivery?**
A: 接单即排产并书面确认档期，关键节点跟踪，历史按时交货率超[X]%。[待确认]
A(EN): Production is scheduled and confirmed in writing at order, with milestone tracking; on-time rate over [X]%. [TBC]

**Q93: 万一延误怎么补救？ / What if there's a delay?**
A: 极少发生，一旦预判延误会第一时间通知你并给补救方案（加急/部分先发/空运补差），绝不让你被动。
A(EN): Rare — if a delay is foreseen we notify you immediately with remedies (expedite/partial ship/air freight).

**Q94: 急单能加急吗？ / Can you rush an urgent order?**
A: 可以，告知截止日期，我们评估后优先排产、加急生产，尽量满足你的时效。[待确认]
A(EN): Yes — share your deadline; we prioritize and expedite where possible. [TBC]

**Q95: 你们的生产稳定性如何？ / How stable is your production?**
A: 自有工厂+稳定工人队伍，不依赖外协，产能和质量稳定，不会忽高忽低。
A(EN): Own factory + stable workforce, minimal outsourcing — consistent capacity and quality.

**Q96: 首单一般多久能走完流程？ / How long for a first order?**
A: 首单含确认+打样略长，约[X]周；返单走熟流程更快，约[X]周。[待确认]
A(EN): First orders take ~[X] weeks (incl. sampling); reorders ~[X] weeks. [TBC]

**Q97: 生产环境/车间能看吗？ / Can I see the workshop?**
A: 欢迎，可视频看厂或线下到访，眼见为实，也欢迎安排第三方验厂。
A(EN): Welcome — video factory tour or on-site visit; third-party audits welcome too.

**Q98: 你们怎么控制大批量的一致性？ / How do you ensure batch consistency?**
A: 标准化工艺+首件确认+过程抽检+出货全检，确保每一批和样品一致。
A(EN): Standardized process + first-article approval + in-line sampling + full final inspection.

**Q99: ⚠️ 哪些交期不能承诺？（红线）/ Which lead times can't you promise? (Red line)**
A: 超出实际产能的交期我们不接，宁可如实说"做不到"，也不接单后延误坑你。
A(EN): We won't accept lead times beyond real capacity — honesty over over-promising.

## 【模块六】价格与付款 Pricing & Payment（Q100-Q117）

**Q100: 报价基于什么贸易术语？ / What trade term is the quote based on?**
A: 默认 FOB [港口]，也可报 CIF（含保险运费到目的港）或 DDP（完税到门），请注明偏好。
A(EN): Default FOB [port]; also CIF or DDP on request — please state your preference.

**Q101: 支持哪些付款方式？ / What payment methods?**
A: T/T（[X]%定金+[X]%见提单）、阿里信保 Trade Assurance、L/C（$[X] 以上），小额样品费可 PayPal。
A(EN): T/T ([X]% deposit + [X]% before B/L), Alibaba Trade Assurance, L/C (over $[X]); small sample fees via PayPal.

**Q102: 价格能谈吗？有批量折扣吗？ / Negotiable? Volume discounts?**
A: 报价已是工厂直供价。[X]件基础价，[X]件优惠约[X]%，[X]件以上再谈，告知目标数量。[待确认]
A(EN): Already factory-direct. [X]pcs base; ~[X]% off at [X]pcs; more negotiable above [X]pcs. [TBC]

**Q103: 报价单有效期多长？ / How long is the quote valid?**
A: 通常[X]天。原料大幅波动（超[X]%）会提前告知，绝不在执行中单方面改价。
A(EN): Usually [X] days. If material costs swing over [X]% we notify in advance — never unilateral changes mid-order.

**Q104: 样品怎么收费？ / How are samples charged?**
A: 样品费[$/件]（视型号），运费客户承担（建议提供快递账号），下单后样品费全额抵货款。[待确认]
A(EN): Sample fee [$/pc], freight by buyer; fully deductible from bulk payment. [TBC]

**Q105: 首次合作定金比例能调吗？ / Adjustable deposit for first order?**
A: 首次建议用阿里信保下单，资金平台托管，双方都安心，欢迎优先采用。
A(EN): For first orders we recommend Trade Assurance — funds held by the platform, safe for both sides.

**Q106: 有长期合作优惠吗？ / Discounts for long-term cooperation?**
A: 年采购超[$X]的长期客户，享专属年度返点（[X]%–[X]%）+优先排产+专属客服。[待确认]
A(EN): Annual purchase over [$X] earns rebates ([X]%–[X]%), priority production and dedicated support. [TBC]

**Q107: 汇率波动怎么处理？ / How do you handle exchange-rate swings?**
A: 报价以美元计价，有效期内不因汇率单方面调价，超期订单重新报价，保障双方利益。
A(EN): Quotes in USD; no unilateral changes within validity; re-quote after expiry.

**Q108: 价格为什么比某些同行高？ / Why higher than some peers?**
A: 我们用[更好的料/更严的检/正规认证]，单价看着略高，但帮你省下退货、差评、封号的隐性成本，长期更省钱。
A(EN): We use [better materials/stricter QC/proper certs] — slightly higher unit price, but saving you hidden costs of returns, bad reviews and bans.

**Q109: 能给目标价匹配方案吗？ / Can you match my target price?**
A: 告诉我们目标价和数量，我们在保质量前提下给可行配置（调材质/简化包装/上量），帮你达成成本。
A(EN): Share your target price & qty; we offer feasible configs (material/packaging/volume) without sacrificing quality.

**Q110: 付款安全怎么保障？ / How is my payment secured?**
A: 强烈建议走阿里信保，钱在平台托管，确认收货才放款，从根本上保障你的资金安全。
A(EN): Use Trade Assurance — funds escrowed by the platform, released only after you confirm receipt.

**Q111: 尾款什么时候付？ / When is the balance due?**
A: 通常见提单副本付尾款（发货前），也可按信保约定节点，灵活但都白纸黑字写清。
A(EN): Usually against B/L copy before shipment, or per Trade Assurance terms — always clearly documented.

**Q112: 报价含税吗？ / Is the quote tax-inclusive?**
A: FOB 报价为出口价，目的国关税/增值税由买方承担；选 DDP 我们可代付，总价提前算清。
A(EN): FOB is export price; destination duties/VAT borne by buyer. With DDP we prepay and quote all-in.

**Q113: 小订单也接吗？ / Do you accept small orders?**
A: 接，理解新买家要先试水，达到 MOQ 即可下单，先把合作跑起来比什么都重要。
A(EN): Yes — we get that new buyers test first; once MOQ is met, let's start the cooperation.

**Q114: 报价能拆明细吗？ / Can you break down the quote?**
A: 可以，提供含产品、包装、配件、运费的明细报价，让你清清楚楚知道钱花在哪。
A(EN): Yes — itemized quote covering product, packaging, accessories and freight, fully transparent.

**Q115: 涨价会提前通知吗？ / Will you notify before price increases?**
A: 会，任何调价都提前书面通知并说明原因，绝不悄悄涨，长期合作靠的是信任。
A(EN): Yes — any change is announced in writing with reasons; no silent increases.

**Q116: 能提供形式发票 PI 吗？ / Can you provide a Proforma Invoice?**
A: 可以，确认型号、数量、贸易术语后，[X]小时内出正式 PI，方便你内部走流程付款。
A(EN): Yes — after confirming details, a formal PI within [X] hours for your internal process.

**Q117: ⚠️ 哪些价格承诺不能做？（红线）/ What pricing can't you promise? (Red line)**
A: 低于成本的"赔本价"我们做不了，也不会先报超低价骗单再加价，明码实价才走得长远。
A(EN): We won't quote below cost, nor bait-and-switch with fake low prices — fair pricing only.

## 【模块七】售后与质保 After-sales & Warranty（Q118-Q133）

**Q118: 质保期多久？ / What's the warranty period?**
A: 整机质保[X]个月，[易损件/电池/核心件]质保[X]个月，自客户签收起算。[待确认]
A(EN): [X] months for the unit, [X] months for [wearing parts/battery/core parts], from receipt. [TBC]

**Q119: 质保期内出问题怎么办？ / What if issues arise within warranty?**
A: 发现问题[X]个工作日内给照片/视频，核实后优先补发良品或下单冲抵金额。
A(EN): Send photos/videos within [X] days; after verification we replace or credit your next order.

**Q120: 次品率超标怎么办？ / What if defect rate exceeds normal?**
A: 承诺次品率不超[X]%，超出部分全额补发，并给品质改善报告。[待确认]
A(EN): We guarantee defect rate under [X]%; excess is fully replaced with an improvement report. [TBC]

**Q121: 有出厂检验流程吗？ / Do you have outgoing inspection?**
A: 有，100% 出厂全检，含[检验项1/项2/项3]，记录存档。
A(EN): Yes — 100% final inspection covering [item1/2/3], records archived.

**Q122: 质保后能买配件吗？ / Spare parts after warranty?**
A: 可以，为在售产品保障至少[X]年配件供应，[易损件]支持单独采购。[待确认]
A(EN): Yes — at least [X] years of spare-part supply; [wearing parts] separately purchasable. [TBC]

**Q123: 有英文用户手册吗？ / English user manual?**
A: 有，标配英文手册（安装+使用+维护+排障），其他语言定制订单可提供。
A(EN): Yes — English manual included (install/use/maintain/troubleshoot); other languages on custom orders.

**Q124: 有故障排查文档吗？ / Troubleshooting guide?**
A: 有《常见故障诊断手册》，涵盖[X]种问题自助排查，随货或邮件提供。[待确认]
A(EN): Yes — a troubleshooting guide for [X] common issues, shipped or emailed. [TBC]

**Q125: 重大质量纠纷怎么处理？ / How are major quality disputes handled?**
A: 金额较大的纠纷走阿里信保平台申请，平台介入调解，我们全力配合，保障买家权益。
A(EN): Large disputes go through Trade Assurance for platform mediation; we cooperate fully.

**Q126: 售后响应多快？ / How fast is after-sales response?**
A: 售后问题[X]小时内响应，给明确处理方案和时间表，不让你干等。[待确认]
A(EN): After-sales issues answered within [X] hours with a clear plan and timeline. [TBC]

**Q127: 退换货政策是什么？ / What's the return/exchange policy?**
A: 质量问题导致的退换由我方负责（补发/退款/下单冲抵）；非质量原因协商解决，政策写进合同。
A(EN): Quality-related returns are on us (replace/refund/credit); others negotiated — all in the contract.

**Q128: 能提供远程技术支持吗？ / Remote technical support?**
A: 可以，提供视频/邮件远程指导安装调试，复杂问题安排工程师对接。
A(EN): Yes — video/email guidance for installation and setup; engineers for complex issues.

**Q129: 批量货到有破损怎么算？ / What about transit damage on bulk?**
A: 运输破损凭签收异常和照片处理，属我方包装问题的补发，属承运责任协助你向保险/货代索赔。
A(EN): With proof, packaging-caused damage is replaced; carrier-caused, we help you claim from insurer/forwarder.

**Q130: 你们会持续改进质量吗？ / Do you continuously improve quality?**
A: 会，每批客诉都录入改善系统，定期复盘工艺，让问题不再第二次发生。
A(EN): Yes — every complaint enters our improvement system; processes are reviewed to prevent recurrence.

**Q131: 老客户售后有优先吗？ / Priority after-sales for repeat clients?**
A: 有，长期合作客户享售后绿色通道，问题优先处理，专属对接人全程跟。
A(EN): Yes — long-term clients get a fast-track after-sales channel with a dedicated contact.

**Q132: 质保凭证怎么留存？ / How is warranty documented?**
A: 每单留有订单号、出货记录和质保说明，售后凭单号即可快速核对，不用反复举证。
A(EN): Each order has an ID, shipping record and warranty note; claims are verified by order ID quickly.

**Q133: ⚠️ 哪些售后不在保障范围？（红线）/ What's NOT covered by after-sales? (Red line)**
A: 人为损坏、超期使用、违规操作导致的损坏不在免费质保内，我们会如实说明，但可付费维修/供配件。
A(EN): Misuse, overuse and improper operation aren't covered free; we explain honestly but offer paid repair/parts.

## 【模块八】物流与配送 Shipping & Logistics（Q134-Q149）

**Q134: 从哪个港口出货？ / Which port do you ship from?**
A: 通常从[港口]出货，距厂约[X]小时车程，也可按你指定的港口安排。
A(EN): Usually from [port], ~[X] hours from the factory; other ports on request.

**Q135: 支持哪些运输方式？ / What shipping methods?**
A: 海运整柜 FCL、海运拼箱 LCL、空运、快递（DHL/FedEx/UPS，小批量推荐，[X–X]天到欧美）。
A(EN): FCL, LCL, air freight, and express (DHL/FedEx/UPS, [X–X] days to EU/US for small batches).

**Q136: 支持亚马逊 FBA 入仓吗？ / Do you support Amazon FBA?**
A: 完全支持，熟悉 FBA 标签和外箱要求（FNSKU/外箱标准），按 FBA 标准打包贴标，你无需二次处理。
A(EN): Fully — familiar with FBA labeling (FNSKU/carton specs); we pack and label per FBA, no rework for you.

**Q137: 包装能扛长途运输吗？ / Can packaging withstand long transit?**
A: 可以，出口包装专业设计，内衬防震，外箱瓦楞符合国际标准，过振动/跌落模拟测试。
A(EN): Yes — export packaging with shock-proof lining and standard corrugated cartons, tested for vibration/drop.

**Q138: 能用我指定的货代吗？ / Can I use my own forwarder?**
A: 完全可以，给货代联系方式，我们装箱并配合提货，提供全套单证（装箱单/发票/提单）。
A(EN): Absolutely — share your forwarder; we load and cooperate, providing full docs (PL/CI/B/L).

**Q139: 发货后能追踪吗？ / Can I track after shipment?**
A: 可以，发货后[X]小时内给提单号/快递单号和在线追踪链接，实时掌握货况。
A(EN): Yes — B/L or tracking number within [X] hours plus an online tracking link.

**Q140: 一个柜能装多少？ / How much fits in a container?**
A: 以标准包装为例，20GP 约[X]件，40HQ 约[X]件，我们给精确装柜方案。[待确认]
A(EN): With standard packing, 20GP ~[X]pcs, 40HQ ~[X]pcs; we provide exact loading plans. [TBC]

**Q141: 海运到主要市场要多久？ / Transit time to main markets?**
A: [港口]到欧洲约[X]天，美西约[X]天，美东约[X]天，中东约[X]天。
A(EN): From [port]: EU ~[X]d, US West ~[X]d, US East ~[X]d, Middle East ~[X]d.

**Q142: 能做 DDP 一条龙到门吗？ / Can you do door-to-door DDP?**
A: 可以，提供 DDP 完税到门方案，关税清关全包，你只管收货，总价提前算清。
A(EN): Yes — DDP door-to-door with duties and clearance included; you just receive, all-in price upfront.

**Q143: 运费大概多少？ / How much is freight roughly?**
A: 运费随油价/旺季/目的地浮动，告知目的港/邮编和数量，我们当天给实时报价。[待确认]
A(EN): Freight varies by fuel/season/destination; share port/zip and qty for a same-day quote. [TBC]

**Q144: 急货能空运吗？ / Air freight for urgent goods?**
A: 可以，急单走空运或快递，[X–X]天到，运费稍高但保你不误销售旺季。[待确认]
A(EN): Yes — air/express in [X–X] days, costlier but saves your sales window. [TBC]

**Q145: 出口单证齐全吗？ / Are export documents complete?**
A: 齐全，提供装箱单、商业发票、提单、产地证（CO/FORM E/A 等）、必要的认证文件。
A(EN): Complete — PL, CI, B/L, certificate of origin (CO/FORM E/A), and required cert docs.

**Q146: 能合并多个订单一起发吗？ / Can you consolidate orders?**
A: 可以，多单合并装柜省运费，按你的节奏安排合并发货，帮你摊薄物流成本。
A(EN): Yes — consolidating orders saves freight; we arrange per your schedule.

**Q147: 货物保险怎么处理？ / How about cargo insurance?**
A: CIF/DDP 含保险；FOB 可代购保险或你自理，建议大货都投保，万一出事有保障。
A(EN): CIF/DDP include insurance; for FOB we can arrange or you self-insure — recommended for bulk.

**Q148: 偏远地区/内陆能送到吗？ / Delivery to remote/inland areas?**
A: 可以，通过 DDP 或指定货代送到内陆城市/海外仓，告知详细地址即可评估方案和时效。
A(EN): Yes — via DDP or forwarder to inland cities/overseas warehouses; share the address for a plan.

**Q149: ⚠️ 物流上哪些不能保证？（红线）/ What can't you guarantee in logistics? (Red line)**
A: 海关查验、罢工、天气等不可抗力导致的延误不在我方可控范围，但会第一时间协助你处理。
A(EN): Force majeure (customs holds, strikes, weather) is beyond our control, but we assist immediately.

## 【模块九】竞争优势与差异化 Competitive Advantage（Q150-Q165）

**Q150: ⚠️ 市场上有更便宜的，你们凭什么值这价？（价格反击）/ There are cheaper options — why are you worth it?**
A: 低价货通常用劣质料、省关键工序、没正规认证，背后是安全风险、质量不稳、售后扯皮。我们坚持[核心优势]，给[X]个月质保，帮你的品牌避开差评、退货、封号风险，长期算总账反而更划算。
A(EN): Cheap goods often mean poor materials, skipped processes and no certs — bringing safety risks, instability and disputes. We insist on [USP], offer [X]-month warranty, and protect your brand from bad reviews, returns and bans. Cheaper in the long run.

**Q151: 你们和同行最大的优势是什么？ / Your biggest edge over peers?**
A: 三点：①[差异1，如自主研发/自有模具房]；②[差异2，如品控更严/次品率更低]；③[差异3，如交期更稳/响应更快]。
A(EN): Three: ①[diff1, e.g. in-house R&D]; ②[diff2, e.g. stricter QC]; ③[diff3, e.g. stable lead time].

**Q152: 品控比别的工厂强在哪？ / How is your QC stronger?**
A: 三道防线：IQC 来料检+IPQC 过程抽检+OQC 出货全检，次品率控制[X]%以内，低于行业平均[X]%。[待确认]
A(EN): Three lines: IQC + IPQC + OQC; defect rate under [X]%, below the [X]% industry average. [TBC]

**Q153: 交货稳定性如何？ / How stable is your delivery?**
A: 长期服务[欧美/中东/东南亚]客户，按时交货率超[X]%，每单书面排产确认，旺季提前锁产能。[待确认]
A(EN): Serving [EU/US/ME/SEA] clients, on-time rate over [X]%, written scheduling, peak capacity locked early. [TBC]

**Q154: 你们能帮我提升产品竞争力吗？ / Can you boost my competitiveness?**
A: 可以，定期做市场趋势研究，向合作客户分享新品方向和畅销配置，不只是接单，更帮你保持领先。
A(EN): Yes — we research trends and share new-product directions with partners, not just taking orders.

**Q155: 服务过知名品牌吗？ / Have you served known brands?**
A: 有，长期为多个[欧美/知名]品牌做 OEM，因保密无法公开名字，签 NDA 后可提供参考案例。[待确认]
A(EN): Yes — OEM for several [EU/US] brands; names confidential, references available after NDA. [TBC]

**Q156: 你们的响应速度怎么样？ / How responsive are you?**
A: 工作时间内[X]分钟内回复，非工作时间 AI 接待+次日跟进，绝不让你的询盘石沉大海。
A(EN): Within [X] minutes during work hours; AI reception off-hours with next-day follow-up — no inquiry ignored.

**Q157: 为什么选源头工厂而非贸易商？ / Why a factory over a trader?**
A: 直接对接工厂=价格更实、信息不失真、问题响应快、定制更灵活，中间环节少一层省一层心。
A(EN): Direct factory means truer prices, accurate info, faster response and flexible customization.

**Q158: 你们的研发能力体现在哪？ / Where does your R&D show?**
A: 每年[X]款新品、[X]项专利、能按客户需求做结构改良，帮你拿到差异化产品抢市场。
A(EN): [X] new products/year, [X] patents, structural improvements on demand — differentiated products to win the market.

**Q159: 大客户有什么专属服务？ / Special service for key accounts?**
A: 专属客户经理、优先排产、年度返点、定制账期、市场情报共享，把你当长期伙伴而非一次性买家。
A(EN): Dedicated manager, priority production, annual rebates, custom terms and market intel — a long-term partnership.

**Q160: 你们能跟我一起成长吗？ / Can you grow with me?**
A: 这正是我们想要的合作。从小单试水到品牌共建，每个阶段给对应支持，你做大我们才做大。
A(EN): That's exactly what we want — from trial orders to brand building, supporting each stage. We grow when you do.

**Q161: 你们环保/可持续做得怎样？ / How about sustainability?**
A: 用[环保材料/节能工艺/可回收包装]，符合欧美买家 ESG 要求，帮你的品牌讲好可持续故事。[待确认]
A(EN): We use [eco materials/energy-saving processes/recyclable packaging], meeting ESG needs. [TBC]

**Q162: 你们的客户复购率高吗？ / Is your repeat-order rate high?**
A: 老客户复购率约[X]%，很多客户合作[X]年以上，稳定品质和服务是他们留下的原因。[待确认]
A(EN): Repeat rate ~[X]%, many clients staying [X]+ years thanks to stable quality and service. [TBC]

**Q163: 出问题你们会甩锅吗？ / Will you dodge responsibility on issues?**
A: 不会，属我们的问题我们认、我们赔、我们改，绝不推诿。有担当才有长期生意。
A(EN): No — if it's on us, we own it, compensate and fix it. Accountability builds lasting business.

**Q164: 你们能提供哪些增值服务？ / What value-added services?**
A: 免费选品建议、市场合规指导、营销素材（图/视频）、海外仓对接，帮你省心又省成本。
A(EN): Free product advice, compliance guidance, marketing assets (photos/videos), overseas-warehouse links.

**Q165: ⚠️ 你们绝不会做的事？（红线汇总）/ What you'll never do? (Red-line summary)**
A: 不谎称没有的认证、不接超产能的单、不报赔本骗单价、不货不对板、不出问题甩锅。诚信是我们做外贸的底线。
A(EN): We never fake certs, over-promise capacity, bait with fake prices, ship wrong goods, or dodge blame. Integrity is our bottom line.

## 【模块十】场景化解决方案 Scenario Solutions（Q166-Q183）

**Q166: 我是亚马逊新卖家刚起步，你们能配合吗？ / I'm a new Amazon seller — can you support me?**
A: 完全可以，给新卖家：低起订量（[X]件起）、FBA 合规包装、完整认证文件包、英文 listing 建议。从一款核心品起步，帮你快速进市场。
A(EN): Absolutely — low MOQ ([X]pcs), FBA-ready packaging, full cert package and English listing tips. Start with one core product.

**Q167: 我是欧洲品牌商，合规要求很严，能满足吗？ / I'm an EU brand with strict compliance needs.**
A: 可以，给欧洲客户完整合规包：CE 技术文件/RoHS 声明/REACH 符合性/BSCI 报告，签约后提供。
A(EN): Yes — full EU compliance pack: CE tech file, RoHS, REACH declarations, BSCI report, provided after contract.

**Q168: 我是礼品公司，要节日礼品套装，能做吗？ / I'm a gift company needing holiday sets.**
A: 非常适合，产品[轻巧/精致]适合礼赠，支持礼盒定制+LOGO 印刷，MOQ [X]件起，建议提前[X]天下单确保节前到。
A(EN): Perfect — [light/exquisite] for gifting, gift-box + LOGO customization, MOQ [X]pcs, order [X] days early.

**Q169: 我是连锁/超市采购，要稳定大量供货，能保障吗？ / I'm a chain/supermarket buyer needing volume.**
A: 可以，月产能[X]件，支持年度框架协议、按季排产，按时交货率超[X]%，有完整大客户服务机制。[待确认]
A(EN): Yes — [X]pcs/month, annual framework, quarterly scheduling, on-time over [X]%, full key-account service. [TBC]

**Q170: 我想做自己的品牌，从哪开始？ / I want to build my own brand — where to start?**
A: 三步走：①选基础款（我们荐畅销配置）；②定制 LOGO 和包装（免费初稿）；③小批量试单验证（[X]件起）。成功再放量，全程陪跑。
A(EN): Three steps: pick a base product, customize LOGO/packaging (free draft), trial order ([X]pcs). Scale after success.

**Q171: 我在[特定市场]，有当地特殊要求，能处理吗？ / I'm in [market] with local requirements.**
A: 熟悉[市场]的认证/包装/语言要求，给针对性方案，告知具体需求即匹配最优方案。
A(EN): Familiar with [market]'s cert/packaging/language rules — share specifics for a tailored solution.

**Q172: 我的营销活动时效很紧，怎么办？ / My campaign timing is tight.**
A: 提前告知活动节点，优先排产+专属生产计划，建议提前[X]天沟通，确保按时到货。
A(EN): Tell us the deadline; we prioritize with a dedicated plan — discuss [X] days ahead.

**Q173: 我是批发商，要多品类一站采购，行吗？ / I'm a wholesaler needing multi-category sourcing.**
A: 可以，我们品类覆盖[X 类]，一站采购省去多家对接，合并装柜省运费，给你做组合报价。
A(EN): Yes — [X] categories for one-stop sourcing, consolidated shipping, combined quotes.

**Q174: 我是独立站卖家，要差异化产品，有吗？ / I run a DTC site and need differentiated products.**
A: 有，可做独家定制（外观/功能/包装），帮你避开同质化红海，做出别人没有的卖点。
A(EN): Yes — exclusive customization (look/function/packaging) to escape the red ocean.

**Q175: 我预算有限，怎么以小博大？ / I'm on a tight budget — how to start small?**
A: 建议先选 1 款高需求基础品+小批量试单+信保付款，把风险降到最低，跑通了再扩。
A(EN): Pick one high-demand base product, small trial order, Trade Assurance payment — minimal risk, then scale.

**Q176: 我要长期稳定货源，怎么绑定你们？ / I want a stable long-term supply — how to lock you in?**
A: 签年度框架协议+预测排产，我们为你预留产能、锁定价格、优先发货，长期供货不断档。
A(EN): Annual framework + forecast scheduling — reserved capacity, locked prices, priority shipping.

**Q177: 我担心第一次合作有风险，怎么破？ / I'm worried about first-time risk.**
A: 三重保障：①信保托管资金；②先打样验质量；③小批量试单。三步走完信任建立，再谈大单。
A(EN): Three safeguards: Trade Assurance escrow, sample first, small trial order — build trust step by step.

**Q178: 我要做品牌升级，你们能给视觉/包装支持吗？ / Can you support brand-upgrade visuals/packaging?**
A: 可以，提供包装设计建议、产品实拍、营销素材，帮你的品牌从产品到形象一起升级。
A(EN): Yes — packaging design advice, product photography and marketing assets for a full brand upgrade.

**Q179: 我是进口商，要符合本国标准的产品，能定制吗？ / I'm an importer needing locally-compliant products.**
A: 可以，按你本国的标准/认证/标签要求做定制，确保货到即合规、能清关、能上架。
A(EN): Yes — customized to your country's standards/certs/labels so goods clear customs and hit shelves.

**Q180: 我想先了解市场再决定，你们能给建议吗？ / I want market insight before deciding.**
A: 可以，免费分享我们掌握的品类趋势、热销配置、目标市场偏好，帮你做明智决策，不催单。
A(EN): Yes — we freely share category trends, best-selling configs and market preferences. No pressure.

**Q181: 我同时对接多个供应商比价，你们怎么胜出？ / I'm comparing multiple suppliers.**
A: 欢迎对比，我们用真材实料+正规认证+稳定交期+透明报价说话，建议你重点比"总成本"和"售后保障"，不只比单价。
A(EN): Compare freely — we win on real materials, proper certs, stable delivery and transparent pricing. Compare total cost, not just unit price.

**Q182: 我有特殊定制需求不确定能不能做，怎么问？ / I have an unusual custom need.**
A: 直接把需求（图纸/描述/参考样）发来，工程师评估后给明确答复：能做就报方案报价，做不了就如实说+给替代建议。
A(EN): Send your need (drawing/description/reference); engineers give a clear yes (with quote) or an honest no (with alternatives).

**Q183: ⚠️ 什么情况需要转人工处理？（人机切换）/ When do you switch to a human? (Human handoff)**
A: 以下情况 AI 会停止回复并转接专业商务：①单笔订单超 $[X]（如 $50,000）；②要改合同条款；③质量纠纷需协调；④涉及法律问题。请稍候，我们将在[X]小时内人工回复你。
A(EN): The AI stops and hands off to a human for: orders over $[X] (e.g. $50,000), contract changes, quality disputes, or legal matters. A specialist replies within [X] hours.

## 【模块十一】行业通识 Industry Knowledge（Q184-Q200）

> 注：以下为通用模板，需按具体行业替换 [产品类目] 和对应内容。

**Q184: 采购[产品类目]时该关注哪些核心指标？ / What key metrics matter when buying [category]?**
A: [核心参数1/2/3]是最重要的评判维度。[简短解释各参数意义和判断方法]，看懂这几个就不会被忽悠。
A(EN): [param1/2/3] are the key criteria. [Brief explanation] — know these and you won't be misled.

**Q185: [产品类目]在欧美市场要哪些认证？ / What certs are needed in EU/US for [category]?**
A: 欧盟：[必须认证]（强制）；美国：[必须认证]；加拿大：[认证]；澳洲：[认证]。我们已覆盖主要市场，按需提供文件。
A(EN): EU: [certs] (mandatory); US: [certs]; Canada: [cert]; Australia: [cert]. We cover major markets.

**Q186: 亚马逊对[产品类目]有什么特别要求？ / Amazon's special requirements for [category]?**
A: [行业特定 FBA 合规，如电池 UN38.3、食品 FDA、儿童品 CPSC 报告]。我们有完整合规文件体系，保你顺利入仓。
A(EN): [Category-specific FBA rules]. We have a complete compliance system for smooth inbound.

**Q187: [产品类目]目前有哪些主流趋势？ / Current trends in [category]?**
A: 四大趋势：①[趋势1]；②[趋势2]；③[趋势3]；④[趋势4]。我们新品已布局这些方向，欢迎了解最新产品线。
A(EN): Four trends: [1/2/3/4]. Our new products already follow these directions.

**Q188: 不同地区买家采购[产品类目]偏好有何差异？ / Regional buyer preference differences?**
A: 欧洲：[偏好]；北美：[偏好]；中东：[偏好]；东南亚：[偏好]。我们有针对各市场的专属配置方案。
A(EN): EU: [pref]; NA: [pref]; ME: [pref]; SEA: [pref]. We have market-specific configs.

**Q189: [产品类目]跨境物流有哪些特殊注意点？ / Special logistics notes for [category]?**
A: [行业物流注意点，如易碎品包装、危险品申报、温控、体积重计费]。我们在这些方面都有成熟处理方案。
A(EN): [Category logistics notes]. We have mature solutions for all of these.

**Q190: 怎么判断一个[产品类目]供应商靠不靠谱？ / How to judge a [category] supplier?**
A: 五个维度：①是否源头工厂；②是否有主流市场认证；③是否有社会责任审计；④交货稳定性；⑤售后政策是否清晰。这五点我们都能给书面证明，欢迎考察。
A(EN): Five checks: factory vs trader, market certs, social audits, delivery stability, clear after-sales. We prove all five.

**Q191: 我第一次从中国采购[产品类目]，有什么建议？ / Tips for first-time sourcing from China?**
A: 三点：①从小批量试单开始；②用阿里信保保资金；③提前沟通认证需求，避免货到清不了关。我们有丰富的协助新买家落地经验。
A(EN): Three tips: start small, use Trade Assurance, clarify certs early. We're experienced in onboarding new buyers.

**Q192: [产品类目]的价格区间一般是怎样的？ / Typical price range for [category]?**
A: 市场大致分[低端/中端/高端]三档，差异主要在[材质/工艺/认证]。我们定位[档位]，给你说清每一分钱花在哪。
A(EN): The market splits into [low/mid/high] tiers by [material/process/certs]. We're [tier], transparent on value.

**Q193: [产品类目]常见的质量陷阱有哪些？ / Common quality traps in [category]?**
A: 常见坑：[陷阱1，如以次充好]；[陷阱2，如缺关键认证]；[陷阱3，如参数虚标]。和我们合作可以一一规避。
A(EN): Common traps: [1/2/3]. Working with us avoids them all.

**Q194: [产品类目]的最小起订量行业惯例是多少？ / Typical MOQ in [category]?**
A: 行业常规 MOQ 约[X]件，我们对新客户更灵活，[X]件起即可试单，降低你的入场门槛。
A(EN): Industry MOQ ~[X]pcs; we're flexible for new clients from [X]pcs.

**Q195: [产品类目]未来 1-2 年的发展方向？ / Outlook for [category] in 1-2 years?**
A: 预计向[方向1/方向2]发展，[环保/智能/个性化]需求上升，提前布局这些方向能抢占先机，我们可同步最新动态。
A(EN): Trending toward [direction1/2] with rising [eco/smart/custom] demand. Early movers win — we keep you updated.

**Q196: [产品类目]在不同季节有需求差异吗？ / Seasonal demand differences?**
A: 有，[旺季月份]是采购高峰，建议提前[X]天备货下单，避开旺季产能紧张和运费上涨。
A(EN): Yes — peak in [months]; order [X] days early to avoid capacity crunch and freight hikes.

**Q197: [产品类目]怎么做才能在终端市场卖得好？ / How to sell [category] well at retail?**
A: 关键看[卖点呈现/包装/合规/价格带]，我们不只供货，还能给你终端动销的配置和营销建议。
A(EN): It comes down to [USP presentation/packaging/compliance/price]. We advise on retail sell-through, not just supply.

**Q198: 采购[产品类目]怎么平衡价格和质量？ / Balancing price and quality?**
A: 别只盯单价，算"到手总成本+退货率+复购"。我们帮你找性价比最优解，而不是最便宜但最坑的那个。
A(EN): Don't chase unit price — count total landed cost, return rate and repeat sales. We optimize value, not just cheapness.

**Q199: [产品类目]有哪些常见认证误区？ / Common certification myths in [category]?**
A: 常见误区：①以为"有认证"就行（其实要看是否第三方、是否在有效期）；②以为一证通全球（不同市场要不同认证）。我们帮你理清。
A(EN): Myths: "any cert is fine" (check third-party & validity) and "one cert fits all markets" (each market differs). We clarify.

**Q200: 和你们合作做[产品类目]，最大的省心点是什么？ / What's the biggest peace-of-mind in working with you?**
A: 一句话：从选品、合规、生产、品控到物流，一条龙都帮你想到位，你只管卖，剩下的交给我们，少操心、少踩坑、多赚钱。
A(EN): In one line: from sourcing, compliance, production and QC to logistics, we handle it all — you just sell. Less worry, fewer pitfalls, more profit.

---

# 附录 B：极简 10 问快答（信息严重不全的新供应商用）

> 新店没什么公开信息？让供应商只回答这 10 个问题，就能生成基础 QA 库，查不到的标 `[待完善]`。

1. **公司主营**：我们专注做什么产品，做了多少年？
2. **工厂规模**：厂有多大？多少人？工厂还是工贸？
3. **核心优势**：客户为什么选我们而不是别家？（说 3 个）
4. **认证情况**：我们有什么证书？哪些市场能卖？
5. **定制能力**：支持改 LOGO / 改包装 / 改结构吗？最低几件起？
6. **交期**：现货多久发？定制多久交？
7. **价格策略**：定位高端 / 中端 / 性价比？主要付款方式？
8. **售后政策**：质量问题怎么处理？质保多久？
9. **主要市场**：现在主要卖给哪些国家的客户？
10. **最想强调**：你最希望 AI 介绍我们时重点突出什么？

---

*整合版 V3.0 | 200 条中英双语 QA + 阿里官方 41 一级类目全覆盖 | 由①巩 知识库建立 + ②陶磊 问答对生成 + ③SOP.md + ④QA_TEMPLATE.md 四份材料合并优化而成*
*V2.0 修正：统一锁定 200 条、修正 .xlsl→.md、消除数字矛盾、补全双语、植入价格反击/红线/人机切换 QA*
*V3.0 升级：行业通识对齐阿里国际站官方 41 个一级类目（8 大组），配套 3615 三级类目参考文件 `category_reference.md`，做到任意类目可套*

## 配套文件

- `SKILL.md`（本文件）：技能主体 + 200 条双语 QA 模板
- `category_reference.md`：阿里国际站完整类目表（41 一级 / 956 二级 / 3615 三级），匹配细分类目时查阅
