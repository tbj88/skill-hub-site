---
name: 业务员-T竞对买家深挖与决策人撬客
description: |
  外贸「竞对海外买家反查 + 决策人联系方式挖掘 + 撬客户跟进打法」四阶段一体化情报技能。
  给一个阿里国际站店铺链接（或公司名 / 官网 / 1688 链接），自动走完：
  ① 店铺画像（公司全名 / 品类 / HS Code / 出口市场 / 认证 / OEM还是品牌方）
  → ② 海关提单反查（ImportYeti / Panjiva / ImportGenius / Volza / 52WMB / Seair 六源交叉，产出具名买家清单）
  → ③ 决策人挖掘（LinkedIn 岗位侦查 + 官网 team 页 + 邮箱格式推测 + 工商注册核验，每家 3-5 人）
  → ④ 撬客打法（6 步跟进节奏 + 5 封开发信序列 + LinkedIn 差异化话术 + 风控评级）。
  触发关键词：竞对买家、挖买家、买家信息、海外买家名单、海关数据、反查买家、找客户联系方式、
  决策人、采购决策人、决策链、买家邮箱、撬客户、撬同行客户、挖同行客户、抢客户、
  同行在给谁供货、这家公司卖给谁、客户开发、开发信、跟进方法、
  importyeti、panjiva、提单数据、bill of lading、consignee、买家反查。
  适用场景：主公给一个店铺链接 / 公司名 + 一句「挖买家 / 查他给谁供货 / 要联系方式 / 怎么撬」，
  即触发本技能，产出具名买家表 + 决策人联系表 + 可直接发的开发信序列。
  与 `overseas-client-due-diligence` 差异：那个是「已知一家客户做 6 模块尽调」，
  本 skill 是「从零开始找出有哪些客户，再挑重点做尽调 + 撬客」。
  与 `客户背调2026.7.12` 差异：那个是「单条询盘 30 分钟风控红绿灯」，本 skill 是「主动进攻挖名单」。
---

# 竞对买家深挖与决策人撬客 · Competitor Buyer Intel

> 主公给一个竞对 / 目标企业的店铺链接或公司名，本 skill 从「他在给谁供货」一路打到
> 「这些买家的决策人叫什么、邮箱是多少、第一封信怎么写」，全链路闭环。

## 📌 触发信号

用户消息命中以下**任一**信号即触发：

- "挖一下这家公司的买家 / 他给海外哪些买家供货 / 这家卖给谁"
- "查买家信息 / 买家名单 / 海外客户名单"
- "要采购决策人的联系方式 / 邮箱 / LinkedIn"
- "怎么撬这些客户 / 撬同行客户 / 抢竞对的客户"
- "海关数据反查 / importyeti / panjiva / 提单 / consignee"
- 粘贴一个 `*.en.alibaba.com` 链接 + 「买家」「客户」「供货」任一词
- 已完成店铺分析后追问「必须结论出买家信息」

## 🚦 执行前置：分级判断

先判断主公要的深度，选择对应档位（不确定就默认 L2）：

| 档位 | 触发语 | 执行范围 | 耗时 |
|---|---|---|---|
| **L1 速查** | "看看他卖给谁" | 阶段 1 + 2（店铺画像 + 买家名单） | 5-8 分钟 |
| **L2 标配** | "挖买家信息" | 阶段 1 + 2 + 3（+ 决策人联系方式） | 10-15 分钟 |
| **L3 全案** | "怎么撬 / 要跟进方法 / 开发信" | 阶段 1-4 全套 | 20-30 分钟 |
| **L4 攻坚** | "重点客户深挖 / 要背调 / 能给多少账期" | L3 + 对 Top1-3 买家做 6 模块尽调 | 30-45 分钟 |

---

## 阶段 1 · 店铺画像（browser sub-agent）

**目的**：拿到海关反查必需的「公司英文全名 + HS Code + 品类关键词」三件套。

### 1.1 派 browser sub-agent（只读，禁止点 Contact / Chat）

必抓字段：

| 字段 | 为什么必须 | 抓取位置 |
|---|---|---|
| **公司英文全名** | 海关数据 shipper 字段就用这个名字搜 | Company Profile 顶部 / 页面 title |
| **公司中文名** | 52WMB / 外贸邦中文海关源要用 | 商标 / 认证图 / 页面推断 |
| **注册地址** | 与海关 shipper 地址交叉验证，确认同一实体 | Company Profile |
| **主营 5 品类** | 反推 HS Code + 后续开发信钩子 | 首页热销 / 产品分类 |
| **出口市场 Top5 + 占比** | 与海关数据交叉验证，识别隐藏市场 | Trade & Market 板块 |
| **认证清单** | 开发信里的信任背书（TÜV/CE/RoHS/FDA） | 认证区 |
| **员工数 / 厂房面积 / 年份** | 开发信里的工厂实力证明 | 制造能力页 |
| **客户类型标签** | 判断 OEM / 品牌方 / 贸易商 | Company Profile |
| **买家评价（含匿名昵称+国家）** | 匿名昵称国别是海关数据的旁证 | Reviews 页 |

### 1.2 企业类型判定表（决定后续打法）

| 信号 | 判定 |
|---|---|
| 自有商标 0-1 个 + 主打来图/来样/按需定制 + 复购率低 | 🏭 **纯 OEM 代工厂** → 买家多为中间商，好撬 |
| 自有商标 3+ 个 + 有品牌官网 + 年新品多 | 🏷 **品牌方** → 买家多为区域独家代理，难撬 |
| 无自有厂房 + 品类极杂 + 员工 <30 | 📦 **贸易商** → 买家分散，撬点在价格 |

### 1.3 输出「海关反查关键词包」（交给阶段 2）

```
英文名：<公司英文全名> / <简称>
中文名：<中文全名> / <简称>
HS Code：<根据品类推断的 2-4 个>
出货港：<宁波 / 深圳 / 上海 / 青岛>
品类英文词：<3-5 个产品英文名>
已知市场：<官方披露 Top5>
```

---

## 阶段 2 · 海关提单反查（general sub-agent · 六源交叉）

**铁律：至少跑 4 个源，不能只查一个就交差。**

### 2.1 数据源优先级与用法

| 优先级 | 数据源 | 覆盖 | URL 模式 | 特点 |
|---|---|---|---|---|
| ⭐⭐⭐⭐⭐ | **ImportYeti** | 美国 | `importyeti.com/company/<slug>`<br>`importyeti.com/search?q=<name>` | 免费、公司名基本不打码、最好用 |
| ⭐⭐⭐⭐ | **ImportGenius** | 美/印/南美 | `importgenius.com/importers/<slug>`<br>`importgenius.com/india/importers/<slug>` | 交易频次准确 |
| ⭐⭐⭐⭐ | **52WMB（中文）** | 全球 | `en.52wmb.com/company/<id>`<br>`52wmb.com/search?q=` | 补南美/东南亚盲区 |
| ⭐⭐⭐ | **Panjiva** | 美国 | `panjiva.com/search?query=` | 部分打码，靠 Google 索引片段反查 |
| ⭐⭐⭐ | **Volza** | 全球 | `volza.com/p/<slug>/` | 免费预览部分买家 |
| ⭐⭐⭐ | **Seair / Eximpedia / Zauba** | 印度 | `seair.co.in/import-shipment-data.aspx?search=` | 印度市场必查 |
| ⭐⭐ | **Tendata / ImportInfo** | 全球 | `tendata.com/en/buyer/<slug>` | 兜底交叉验证 |

### 2.2 Google 高级搜索兜底语法（源都空手时用）

```
site:importyeti.com "<公司英文名>"
site:panjiva.com "<公司英文名>"
"<公司英文名>" bill of lading
"<公司英文名>" consignee shipment
"shipper <公司英文名>" consignee
"<品类英文>" importer USA "<公司简称>"
```

### 2.3 每个买家必须记录 8 个字段

| 字段 | 说明 |
|---|---|
| 买家公司名 | 原文照抄，不翻译 |
| 国家 + 城市/州 | 精确到州（美国）或城市 |
| 类型 | 分销商 / 3PL / 电商大卖 / 政府机构 / 工程商 / 采购公司 |
| 采购品类 | 提单货描原文 |
| 累计货运次数 | 判断是大客户还是散单 |
| 最近到港日期 | **判断是否活跃，超过 12 个月的降权** |
| 数据源 URL | 主公要能点开核验 |
| 可信度 | 🟢高（多源交叉）/ 🟡中（单源权威）/ 🔵低（仅关键词命中） |

### 2.4 隐藏市场识别（高价值动作）

**把海关数据的国家分布 与 阿里官方披露 Top5 做对比**，重点找：

- **官方没提但海关数据大量出现的国家** → 这是竞对的隐藏金矿市场（如 Luba 案例中的印度，官方只写"东亚 20%"，实际印度有 3 家大分销商 150+ 单）
- **官方声称占比高但海关查不到的市场** → 大概率走香港/第三方代理转口，或数据源不覆盖（欧洲/非洲常见）

### 2.5 ⛔ 阶段 2 红线

- **禁止编造买家名**。宁可写「仅见打码 M\*\*\*\*O」也不能猜一个像样的公司名
- **禁止用训练数据里的旧记忆**填名单
- **每条必须附数据源 URL**
- 若所有源都打码，也必须交付「共 X 条记录 + 前 Top N 打码结果 + 涉及品类 + 国家分布」

---

## 阶段 3 · 决策人挖掘（general sub-agent · 5 步）

对 Top 3-5 买家逐个执行，**每家至少挖出 3-5 个具体人名**。

### Step 1 · 官网深挖

```
Google "公司名" 找官网
→ web_fetch 官网 / + /about + /contact + /team + /leadership
→ 提取：总机电话、地址、通用邮箱（info@ / sales@）、具名员工
```

### Step 2 · LinkedIn 岗位侦查（核心）

按**采购决策链优先级**搜：

```
site:linkedin.com/in "公司名" purchasing
site:linkedin.com/in "公司名" procurement
site:linkedin.com/in "公司名" sourcing
site:linkedin.com/in "公司名" supply chain
site:linkedin.com/in "公司名" buyer
site:linkedin.com/in "公司名" CEO OR founder OR president
site:linkedin.com/in "公司名" VP OR director
```

**岗位优先级矩阵**：

| 优先级 | 岗位 | 价值 | 触达难度 |
|---|---|---|---|
| ⭐⭐⭐⭐⭐ | Purchasing Manager / Sourcing Director / Head of Procurement | 直接拍板采购 | 中 |
| ⭐⭐⭐⭐⭐ | COO / VP Operations | 决定供应链换不换供应商 | 高 |
| ⭐⭐⭐⭐ | VP of Brands / Product Manager | 决定品类和设计 | 中 |
| ⭐⭐⭐⭐ | Founder / CEO / Owner（中小公司） | 一人拍板 | 高 |
| ⭐⭐⭐ | Controller / CFO | 只谈付款条件，别谈产品 | 低 |
| ⭐⭐⭐ | **Project Development / Business Development** | **最容易破冰的入口** | **低** |
| ⭐⭐ | Import Manager / Warehouse Manager | 执行层，可作 warm intro 跳板 | 低 |

### Step 3 · 邮箱格式推测与验证

```
1. 从官网找到已知邮箱 → 反推格式（first@ / first.last@ / f.last@）
2. 结合 LinkedIn 人名批量推测
3. 验证：Google 搜 "人名" "@域名" 看是否公开泄露过
4. 辅助：hunter.io/search/<域名>、rocketreach.co/<公司名> 公开预览页
```

**邮箱可信度标注**：
- ✅ **已验证**：Google 搜到公开泄露过该邮箱
- 🟡 **极高（匹配模式）**：官网已确认邮箱格式，按格式推出
- 🔵 **中（推测）**：格式来自行业惯例，未确认

### Step 4 · 工商与风险核验

```
site:opencorporates.com "公司名"
州务卿官网（美国）如佛州 search.sunbiz.org
site:dnb.com "公司名"           → DUNS 号 + PAYDEX
site:bloomberg.com "公司名"
site:zoominfo.com "公司名"      → 营收估算
site:courtlistener.com "公司名"  → 诉讼记录
unicourt.com 搜公司名            → 债务追偿类诉讼（关键！）
BBB / Trustpilot / Yelp / Glassdoor → 口碑与员工评价
OFAC SDN: sanctionssearch.ofac.treas.gov
```

### Step 5 · 联系人画像补全

- LinkedIn 最新动态（近 30 天有无跳槽 / 新项目 / 发帖）
- 任职时长（新上任的高管更愿意换供应商）
- 教育背景 / 发帖风格（决定话术调性）

---

## 阶段 4 · 撬客打法（本 skill 的护城河）

### 4.1 六步跟进节奏（黄金节拍）

| 时间 | 动作 | 要点 |
|---|---|---|
| **Day 0** | LinkedIn 加好友 | ≤300 字符，**零 pitch**，只建立连接。让邮件抵达时对方已眼熟你头像 |
| **Day 3-5** | 第 1 封冷邮件 · 精准钩子 | 主题 ≤60 字符含**具体品类+数字**；正文 ≤180 词；**必须有价格锚** |
| **Day 7-8** | 第 2 封 · 价值加码 | 不催回复，改**送礼物**（白皮书 / 成本对比表 / 合规清单） |
| **Day 14** | 第 3 封 · 迂回破冰 | 承认对方忙，请求**转发给具体岗位**；给公司总机作备选渠道 |
| **Day 21** | 第 4 封 · 稀缺性 + 免费样品 | 制造**合规硬理由**（法规更新）+ 主动寄样 + 产能稀缺暗示 |
| **Day 30** | 第 5 封 · Breakup Email | 3 行，触发损失厌恶。「我把您移入非活跃名单了」 |

### 4.2 开发信写作铁律

**主题行公式**：`具体动作 + 数字 + 对方公司名`
- ✅ `Cut 12-15% Sourcing Costs: Direct from Taizhou Factory`
- ✅ `SKU Expansion: 35% Lower FBA Damage for JEG & Sons`
- ❌ `Cooperation` / `Best Supplier from China` / `Quotation`

**正文 5 段结构**（英文 ≤180 词）：
1. **点出对方业务证据**（"noticed your recent shipments to Long Beach"）
2. **我方身份 1 句**（工厂 + 面积 + 员工数）
3. **3 条 bullet**：耐用性数据 / 具体价格锚（SKU 号 + FOB 价）/ 认证
4. **1 个低门槛 CTA**（5 分钟通话 / 免费样品 / catalog）
5. 署名 + 签名档

**⛔ 开发信合规红线**：
- **禁止说「我从海关数据看到您在采购…」** → 改成 "noticed your recent shipments to [港口]"，听起来像行业观察而非被跟踪，降低戒备
- 免费寄样物流单抬头写**公司名**不写个人名，避免被认定个人物品扣关
- 报价前必须与工厂对齐真实成本，话术里的价格锚不能拍脑袋

### 4.3 LinkedIn 差异化话术（按岗位）

| 岗位 | 关心 | 忌讳 | 话术策略 |
|---|---|---|---|
| COO / 运营 | 效率、成本、供应链确定性 | 被推销打扰 | 数字驱动、极简、直击降本 |
| VP Brands | 品牌调性、新品差异化、转化率 | 低端货、山寨感 | 设计能力 + CTR 数据 + FBA 打包 |
| GTM / 上市运营 | 上架速度、包装合规、平台规则 | 交期不稳、合规不达标 | 认证 + 快反打样 + 预贴标 |
| Controller / 财务 | 付款条件、发票规范、税务合规 | 报关不规范 | 阶梯 T/T + 现金流优化天数 |
| Project Dev / BD | 新供应商机会、样品、目录 | 无 | **送资源包，最容易破冰，优先攻** |

### 4.4 岗位互攻矩阵（撬客核心武器）

单点被拒不代表死局，用**已破冰的人激活未破冰的人**：

```
BD/Project Dev 破冰 → warm intro 给 COO
  话术："I've been chatting with [BD名] about your PD projects.
        He suggested I reach out regarding the logistics scaling side..."

技术/GTM 认可合规 → 转 VP Brands
  话术："Since the technical side is cleared, thought you'd like to
        see the brand-exclusive designs..."

COO 提到降本 → 转 Controller
  话术："[COO名] mentioned cost-optimization is a priority.
        I'd share our tiered payment structures..."
```

### 4.5 一周触达日历（防 LinkedIn 判 spam）

```
周一：加 2 人（优先 BD + 执行层，最易通过）
周二：加 1 人（品类决策层）+ 给已通过者发 Part 2
周三：加 1 人（核心决策人，此时他已收到邮件，LinkedIn 是二次触达）
周四：加 1 人（财务）+ 处理互动
周五：只跟进，不加新人（周末前加会被无视）
```

**一周不超过 5 人**，超了触发 LinkedIn 风控。

### 4.6 回复应对话术库

| 对方回复 | 应对 |
|---|---|
| "Send me your catalog" | 立刻发 PDF，**并主动挑 3 个最匹配他现有品类的 SKU 报价**（别只甩目录） |
| "Your price is too high" | 不降价，改**换算维度**：用「损耗率 / 复购率 / 到岸成本」重新定义便宜 |
| "We already have a supplier" | 提议做 **Price Benchmarking**，承诺只占 2 分钟，不要求换供应商 |
| "Too busy" | 提议发一个 **60 秒工厂视频**，零阅读成本 |
| 已读不回 | 去他 LinkedIn 最新动态下留一条**有价值的行业评论**，激活印象 |

---

## 📊 风险评级与合作红线（L4 档位必做）

对准备重点开发的买家，必须跑一遍风险矩阵：

| 维度 | 查什么 | 高危信号 |
|---|---|---|
| 主体真实性 | 州务卿注册状态、成立年份、Annual Report | Inactive / 成立 <2 年 |
| 财务健康度 | 营收估算、PPP 贷款记录、员工增长 | 大额纾困贷款 + 员工缩减 |
| **支付信誉** | **UniCourt / CourtListener 债务追偿诉讼** | **有 Debt Collection 案底** |
| 供应链稳定性 | 海关进口活跃度趋势 | 近 12 个月进口量断崖 |
| 法律合规性 | OFAC / BIS Entity List | 命中任一制裁名单 |
| 舆情口碑 | Yelp / BBB / Trustpilot / Glassdoor | B2C 端大量退款投诉（预示现金流紧张） |

### 账期建议对照表

| 综合评级 | 首单条件 | 后续账期 | 授信上限 |
|---|---|---|---|
| 🟢 绿灯（≥4 分） | 30% 定金 + 70% 见提单 | 可谈 NET 30-60 | $200K+ |
| 🟡 黄灯（3 分或有诉讼记录） | 30% + 70% T/T against BL copy | **必须投中信保**后按额度放 NET 30 | $100K-$150K |
| 🔴 红灯（≤2 分或命中制裁） | 100% 前 T/T 或 LC at sight | 不给账期 | 首单 $30K 以内试水 |

**单据铁律**：付款账号名必须与 PO 抬头一致，防止离岸账号付款引发合规风险。

---

## 📦 标准交付物清单

| 档位 | 交付内容 |
|---|---|
| L1 | 店铺画像卡 + 买家名单表（含数据源 URL）+ 市场交叉验证 |
| L2 | L1 + 每家 Top 买家的决策人联系表（姓名/岗位/邮箱/LinkedIn/优先级） |
| L3 | L2 + 5 封开发信序列（中英双语）+ LinkedIn 差异化话术 + 一周日历 |
| L4 | L3 + Top 1-3 买家 6 维风险矩阵 + 账期建议 + 谈判弹药 |

**所有交付物必须包含**：
- 每条数据的**来源 URL**
- 每条数据的**可信度评级**（🟢🟡🔵）
- 一段**合规提醒**（海关数据使用边界 + 开发信话术红线）

---

## ⛔ 全局红线（违反即判定任务失败）

1. **不编造**：买家名、人名、邮箱、电话，任何一项没查到就写"未查到"，绝不用训练数据填坑
2. **不单源**：海关反查至少跑 4 个源；决策人至少跑官网 + LinkedIn + 工商三条线
3. **必附源**：每一条结论必须能点开 URL 核验
4. **不空手**：即使全打码，也要交付「记录数 + 打码 Top N + 国家分布 + 品类」
5. **不越界**：开发信禁止暴露"我查了你的海关数据"，改用行业观察式表述
6. **不承诺**：话术里的价格 / 产能 / 交期在与工厂对齐前只是模板，交付时必须标注"待工厂确认"

---

## 🔗 与其他 skill 的协作

| 场景 | 转交给 |
|---|---|
| 挖出买家后要对某一家做完整 6 模块尽调 | `overseas-client-due-diligence` |
| 收到该买家的询盘要做单条风控红绿灯 | `客户背调2026.7.12` |
| 要对自己店铺做经营诊断 | `ICBU 店铺定位分析方法论` |
| 要把开发信序列做成 EDM 批量发送 | `AiReach跟进助手` |
| 挖到的买家要建档跟进 | `inquiry-master`（OKKI 建档模块） |

---

## 📝 实战案例索引

| 案例 | 目标 | 关键收获 |
|---|---|---|
| Zhejiang Luba Traffic（交通设施） | 前台零披露买家 → 海关反查出 10 个美国买家 | 阿里官方只写"东亚 20%"，海关挖出印度 3 家大分销商 150+ 单的隐藏市场 |
| Zhejiang Jinmao / AUCAT（塑料收纳） | 挖出 7 美国 + 1 印度买家 + 11 个决策人 | JEG & Sons 邮箱格式 `first@jegsons.com` 已公开验证；查出 2020 年债务追偿诉讼，评级从绿转黄 |
