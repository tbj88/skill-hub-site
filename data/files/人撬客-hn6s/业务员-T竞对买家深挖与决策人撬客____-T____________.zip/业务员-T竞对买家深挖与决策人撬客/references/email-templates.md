# 开发信与 LinkedIn 话术模板库

> 全部为实战验证过的成品模板，替换 `<>` 内变量即可发送。英文在上，中文对照在下。

---

## 一、Day 0 · LinkedIn 加好友（≤300 字符硬限制）

### 通用公式

```
Hi <FirstName>, <一句真诚的业务观察，点出对方公司具体成绩>.
I'm in the <品类> manufacturing space (supplying <对方所在渠道> vendors)
and would love to connect.
```

### 按岗位变体

**对 COO / 运营高管**
```
Hi <Name>, noticed your focus on scaling <Company>'s 3PL and distribution arms.
We've been helping <州名>-based distributors optimize their <品类> supply chains
with 100% on-time delivery. Would love to connect and follow your insights.
```

**对 VP of Brands / 品类决策**
```
Hi <Name>, your work at <Company> in brand expansion is impressive.
We specialize in designing high-conversion <品类> for Amazon/Walmart sellers.
Would love to join your network and stay updated on your brand portfolio.
```

**对 GTM / 上市运营**
```
Hi <Name>, noticed your role in GTM Operations at <Company>.
We've streamlined our manufacturing to support rapid FBA deployment
and TUV/FDA compliance. Would love to connect and exchange thoughts
on supply chain agility.
```

**对 Controller / 财务**
```
Hi <Name>, I lead international accounts for a major <品类> manufacturer.
We prioritize financial transparency and flexible terms for our US
distribution partners. Would love to connect with a fellow professional.
```

**对 BD / Project Development（最易通过，优先攻）**
```
Hi <Name>, love the projects <Company> is taking on. I'm with <品牌>,
and we're always looking for innovative partners in the US.
Would love to connect and send you our latest product development toolkit.
```

---

## 二、Day 3-5 · 第 1 封冷邮件（精准钩子）

### 结构模板

```
Subject: <具体动作> + <数字> + for <对方公司名>

Hi <Name>,

<第1段：点出对方业务证据，用"noticed your recent shipments to <港口>"这类
行业观察式表述，禁止说"我从海关数据看到">

I'm <你的名字> from <公司英文名>, a <厂房面积>㎡ factory in <城市>.
We specialize in <品类> that are "<对方渠道>-Ready":
- Durability: <具体测试数据，如 tested for 2m drop-tests>
- Price Anchor: Our SKU #<型号> is currently at $<价格> (FOB <港口>).
- Compliance: <认证清单>

Would you be open to a <5-minute chat / sample kit> about
<具体价值主张>?

Best regards,
<签名>
```

### 三种钩子方向（按买家类型选）

| 买家类型 | 钩子 | 主题行示例 |
|---|---|---|
| 3PL / 电商大卖 | **降低 FBA 破损率 / 退货率** | `SKU Expansion: 35% Lower FBA Damage for <Company>` |
| 采购公司（现用贸易商） | **工厂直供替代贸易商加价** | `Cut 12-15% Sourcing Costs: Direct from <城市> Factory` |
| 中小零售进口商 | **认证合规零风险 + 美西仓补货快** | `FDA Compliant <品类>: Faster Restock for <城市> Warehouse` |
| 工业/工程商 | **耐用性 + 长周期供货稳定** | `100% On-time Delivery for <Company>'s <品类> Line` |
| 政府/机构采购 | **合规审查通过记录** | `<认证名> Certified <品类> for Public Procurement` |

---

## 三、Day 7-8 · 第 2 封（价值加码 · 送礼物）

```
Subject: Free resource: <资源名>

Hi <Name>,

Thought this might be useful for your <部门> team in <城市>.
We've compiled a brief "<资源全名>" focusing on <解决什么具体问题>.

It covers:
- <要点 1，越具体越好>
- <要点 2，带数据>

No strings attached. You can download it here [Link].
We maintain a <100% on-time delivery rate / 16% repurchase rate>
to ensure <对方最在意的结果>.

Cheers,
<签名>
```

### 资源包选型对照

| 买家类型 | 送什么 |
|---|---|
| 3PL / 仓储 | 《3PL 供应商包装破损率优化白皮书》 |
| 采购公司 | 《义乌贸易商 vs 产地工厂直采成本对比表》 |
| 合规敏感型（食品接触/儿童品） | 《FDA 21 CFR 178 / CPSC 合规自查清单》 |
| 品牌方 / 电商大卖 | 《2026 品类差异化设计趋势报告》 |
| 工程 / 政府 | 《认证与检测报告索引 + 项目案例集》 |

---

## 四、Day 14 · 第 3 封（迂回破冰）

```
Subject: Quick question regarding <品类> Sourcing

Hi <Name>,

I realize you are likely tied up with <对方层级> strategy.
Could you point me to whoever handles your <具体品类> sourcing?

We currently support full customization (Design/Sample/Requirement-based)
with a ≤2h response time. If it's easier, your team can reach our
direct line at <电话>.

Best,
<签名>
```

**要点**：这封信的目的不是成交，是**拿到具体经办人名字**。哪怕对方只回一句 "talk to Mike"，也是巨大胜利。

---

## 五、Day 21 · 第 4 封（稀缺性 + 免费样品）

```
Subject: <法规名> Compliance & Free Samples for <Company>

Hi <Name>,

With the upcoming <具体法规更新，如 US CPSC 2026 / 州级环保法>
for <品类>, I wanted to ensure your SKU expansion remains risk-free.
Our materials are already <认证 1> and <认证 2> certified.

I'd like to send you a sample of our best-selling <产品名>
(SKU #<型号>). We can have it at your <城市> office via DHL
within 3-5 days—on us.

This will be my last follow-up for a while, but I'd hate for you
to miss the factory-direct pricing advantage before our
<季度> production slots fill up.

Best,
<签名>
```

**双钩子**：① 合规恐惧（不换供应商有风险）② 稀缺性（产能有限）+ 零成本试错（免费样品）

---

## 六、Day 30 · 第 5 封（Breakup Email · 3 行）

```
Subject: Permission to close your file?

Hi <Name>,

I'm moving your file to our "inactive" list as I haven't heard back.
If your sourcing priorities change regarding factory-direct <品类>,
feel free to reach out.

Best of luck with <Company>'s <对方业务方向> growth.

<签名>
```

**心理机制**：损失厌恶。实测 breakup email 回复率往往高于前 4 封任意一封。

---

## 七、LinkedIn 4 段互动序列（加好友通过后）

### Part 2 · 24-48 小时（建立价值，不 pitch）

```
Thanks for connecting, <Name>. I recently saw a report on
<行业具体变化，如 rising container costs into Miami>.
To mitigate this, we've <我方具体做法，带数字，如 optimized our
folding designs to increase container utilization by 22%>.
Just wanted to share that "<关键词，如 efficiency first>" mindset.
No reply needed!
```

**关键**：结尾一定要写 **"No reply needed!"** —— 降低对方心理负担，反而更容易得到回复。

### Part 3 · 第 5-7 天（行业洞察 + 开放式提问）

```
<Name>, thought you'd find this interesting: A few of our
<对方同类> partners in the US are moving toward <行业趋势>
to <具体收益，带百分比>. Given your operations,
is <该趋势关键词> a priority for you this year?
```

### Part 4 · 第 10-14 天（软 pitch + 具体时间选项）

```
<Name>, I know your time is premium. We provide factory-direct
<品类> solutions that prioritize <对方最在意的点> for
high-volume <对方类型>. Would you be open to a 10-min intro call
next <具体星期> at <具体时间> EST to see if we can
<具体量化收益，如 shave 5-8% off your landing costs>?
```

**铁律**：CTA 必须给**具体时间选项**（"周三 10am EST 或周四 2pm EST"），不要问 "when are you free"。

### Part 5 · 补救话术（三种状态）

| 状态 | 话术 |
|---|---|
| 已读未回 | `Hi <Name>, circling back briefly—no pressure. If the timing is off for a cost audit, I'll check back next quarter.` |
| 对方发了新动态 | `Great point on your recent post about <话题>! It aligns perfectly with what we're seeing in manufacturing.` |
| 长期无动态 | `Since you're tied up, I'll sync with <同事名> to see if he'd like a copy of our latest catalog first.`（改攻同事，同时给对方留台阶） |

---

## 八、回复应对话术库

### "Send me your catalog"
❌ 只甩一个 PDF
✅ 发 PDF + **主动挑 3 个最匹配他现有采购品类的 SKU 单独报价**，附一句
```
I've highlighted 3 SKUs that closely match what you're currently
importing. Happy to quote MOQ-specific pricing on any of them.
```

### "Your price is too high"
❌ 直接降价（一降就再也回不去）
✅ **换算维度**，把"单价"重定义为"到岸成本 / 损耗率 / 复购率"
```
Understood. Can I show you the math on landed cost instead of unit price?
Our clients see a 12% lower return rate, which typically offsets a
$0.30 unit difference within the first 500 units.
```

### "We already have a supplier"
❌ 说自己更好
✅ 提议 **Price Benchmarking**，零承诺、零切换成本
```
Totally understand—I'm not asking you to switch. Would you be open
to a 2-minute price benchmark? Even if you stay with your current
supplier, it gives you leverage at your next negotiation.
```

### "Too busy"
✅ 提议 **60 秒工厂视频**，零阅读成本
```
No problem at all. Instead of a call, can I send you a 60-second
factory walkthrough video? You can watch it whenever you have a
spare minute.
```

### 完全已读不回
✅ 去他 LinkedIn 最新动态下留一条**有价值的行业评论**（不是"Great post!"），激活印象后再隔 3 天发信

---

## 九、⛔ 话术合规红线

| 禁止 | 改成 |
|---|---|
| "I saw from customs data that you import from..." | "noticed your recent shipments to <港口>" |
| "Your current supplier is <竞对名>" | "if you're benchmarking your current sourcing channels" |
| 承诺具体价格未经工厂确认 | 标注 "indicative pricing, subject to final confirmation" |
| 免费样品单据写个人名 | 一律写**公司名 + 公司地址**，避免个人物品扣关 |
| 声称有对方竞品客户 | 只说"US-based distributors of similar scale"，不点名 |

---

## 十、发送时间建议（按美国时区）

| 目标位置 | 最佳发送时间 | 备注 |
|---|---|---|
| 美东（NY/FL/MI） | 周二 09:30 EST | 周一堆积邮件已清完 |
| 美中（MO/OH/TX） | 周一 12:30 CST | 午休时段翻手机 |
| 美西（CA/WA/OR） | 周三 10:00 PST | 周中效率最高 |
| 山地时区（CO/UT） | 周三 10:00 MST | 同上 |
| 印度 | 周二 11:00 IST | 避开周五（周末前无心谈事） |
| 欧洲 | 周二/周四 09:00 CET | 严格避开 8 月休假季 |

**通用禁忌**：周五下午、周一早晨、当地公共假期、斋月/圣诞等宗教节期发信。
