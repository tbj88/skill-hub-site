# 海关数据源速查手册

> 反查「某中国出口商 → 卖给了哪些海外买家」的全部可用免费/半免费渠道。
> 使用原则：**至少跑 4 个源交叉验证**，单源结论一律标 🟡 中等可信度。

---

## 一、数据源全景表

| 源 | 主覆盖 | 免费度 | URL 模式 | 打码情况 |
|---|---|---|---|---|
| **ImportYeti** ⭐⭐⭐⭐⭐ | 美国 | 高 | `importyeti.com/company/<slug>`<br>`importyeti.com/supplier/<slug>`<br>`importyeti.com/search?q=<name>` | 公司名基本不打码，货值需付费 |
| **ImportGenius** ⭐⭐⭐⭐ | 美/印/南美 | 中 | `importgenius.com/importers/<slug>`<br>`importgenius.com/india/importers/<slug>`<br>`importgenius.com/search?q=` | 交易次数可见，明细部分打码 |
| **52WMB（外贸邦系）** ⭐⭐⭐⭐ | 全球 | 中 | `en.52wmb.com/company/<id>`<br>`52wmb.com/search?q=`<br>`52wmb.com/buyer/<id>` | 中文界面，补南美/东南亚盲区 |
| **Panjiva（S&P）** ⭐⭐⭐ | 美国 | 低 | `panjiva.com/<Company-Name>`<br>`panjiva.com/search?query=` | 大量打码，靠 Google 索引片段反查 |
| **Volza** ⭐⭐⭐ | 全球 | 中 | `volza.com/p/<slug>/`<br>`volza.com/us-import-data/?keyword=` | 免费预览 Top N 买家 |
| **Seair Exim** ⭐⭐⭐ | 印度 | 中 | `seair.co.in/import-shipment-data.aspx?search=` | 印度市场必查 |
| **Eximpedia** ⭐⭐⭐ | 印度/全球 | 中 | `eximpedia.app/companies/<slug>/<id>` | 补 Seair 遗漏 |
| **Zauba** ⭐⭐ | 印度 | 中 | `zauba.com/import-<keyword>-hs-code.html` | 老牌印度海关库 |
| **Tendata** ⭐⭐ | 全球 | 低 | `tendata.com/en/buyer/<slug>` | 兜底交叉 |
| **ImportInfo** ⭐⭐ | 美国 | 中 | `importinfo.com/<company-slug>` | 有时能捡漏 Panjiva 打码内容 |
| **TradeSNS 外贸邦** ⭐⭐ | 全球 | 中 | `tradesns.com/business_analysis/company.html?keywords=` | 中文，可搜中文公司名 |
| **大数跨境** ⭐⭐ | 中国出口 | 中 | `dashuu.cn` 搜公司名 | 中文源 |

---

## 二、检索关键词构造法

### 2.1 必须准备的 5 类关键词

```
① 英文全名：Zhejiang Jinmao Plastic Industry Co., Ltd.
② 英文简称：Zhejiang Jinmao / Jinmao Plastic / JM Plastic
③ 中文全名：浙江金猫塑业有限公司
④ 中文简称：浙江金猫 / 金猫塑料
⑤ 品牌名/店铺 subdomain：AUCAT
```

**注意**：阿里国际站 subdomain（如 `aucat`）常常就是品牌名，在海关提单的 Model / Brand 字段中会出现，是重要的交叉验证信号。

### 2.2 公司名变体陷阱

| 陷阱 | 应对 |
|---|---|
| 工商注册名 ≠ 出口报关名 | 同时搜 "Industry" / "Industrial" / "Trade" / "Import & Export" 后缀变体 |
| 有 "Co., Ltd." 的搜不到 | 去掉后缀只搜核心词 |
| 集团下多个主体 | 用**注册地址**反查，同地址不同名的都是关联方 |
| 品牌名与公司名不同 | 品牌名单独搜一遍（可能出现在 Model 字段） |

---

## 三、Google 高级搜索兜底语法

当直连数据源都空手时，用 Google 索引片段捞：

```
site:importyeti.com "<公司英文名>"
site:panjiva.com "<公司英文名>"
site:volza.com "<公司英文名>"
site:importgenius.com "<公司英文名>"

"<公司英文名>" bill of lading
"<公司英文名>" consignee
"shipper <公司英文名>" consignee
"<公司英文名>" B/L number

"<品类英文>" importer USA "<公司简称>"
"<品类英文>" distributor "<公司简称>"
```

**为什么有效**：Panjiva / ImportGenius 页面本身要登录，但 Google 已经索引了页面标题和摘要，摘要里常常直接带买家公司名。

---

## 四、买家记录标准字段（8 项，缺一不可）

| 字段 | 示例 | 用途 |
|---|---|---|
| 买家公司名 | `SmartSign (Xpressmyself.com LLC)` | 原文照抄，含 DBA 别名 |
| 国家 + 城市/州 | `美国 / Brooklyn, NY` | 精确到州，影响后续时区/物流话术 |
| 类型 | `垂直电商 / 3PL / 分销商 / 政府机构` | 决定开发信钩子 |
| 采购品类 | `traffic cone, cable protector` | 提单货描原文 |
| 累计货运次数 | `20+` | 判断大客户 vs 散单 |
| 最近到港日期 | `2026-07-15` | **>12 个月的降权，>24 个月不列入重点** |
| 数据源 URL | 完整可点击链接 | 主公核验用 |
| 可信度 | 🟢 / 🟡 / 🔵 | 见下表 |

### 可信度评级标准

| 级别 | 标准 |
|---|---|
| 🟢 **高** | ≥2 个独立数据源出现同一买家名，且有具体提单号或到港日期 |
| 🟡 **中** | 单一权威源（ImportYeti/ImportGenius），有日期和品类 |
| 🔵 **低** | 仅关键词命中，无交易明细；或买家名部分打码 |

---

## 五、隐藏市场识别法（高价值动作）

**做法**：把海关数据的国家分布 与 阿里官方 Company Profile 披露的 Top5 市场做对比。

| 差异模式 | 含义 | 行动 |
|---|---|---|
| 官方没提，海关大量出现 | **隐藏金矿市场**（竞对不想让同行知道） | 重点研究，这是最有价值的情报 |
| 官方声称高占比，海关查不到 | 走香港/新加坡转口，或数据源不覆盖 | 标注"代理出口"，不当作无效 |
| 两边都高度吻合 | 数据可信，说明该企业出口结构透明 | 可放心引用官方数据 |

**实战案例**：Zhejiang Luba 官方只写"东亚 20%"，海关数据挖出印度有 3 家大分销商（Axnoy Industries 累计 150+ 单），印度才是被隐藏的战略市场。

---

## 六、买家活跃度判断

```
最近到港 ≤ 3 个月   → 🔥 活跃大客户，重点开发
最近到港 3-12 个月  → 🟢 正常客户
最近到港 12-24 个月 → 🟡 可能已流失，可作为"竞对丢单"切入
最近到港 > 24 个月  → 🔵 不列入重点名单
```

**"竞对丢单"是最好的切入点**：一个 12-24 个月没下单的买家，说明他对原供应商不满意或换了渠道，此时开发成功率远高于活跃客户。

---

## 七、⛔ 使用红线

1. **禁止编造**：数据源没返回的买家名，绝不用训练数据补
2. **打码如实记录**：只看到 `M****O` 就写 `M****O`，不猜完整名
3. **必附 URL**：每条记录必须能点开核验
4. **不空手**：全打码时也要交付「总记录数 + Top N 打码结果 + 国家分布 + 品类分布」
5. **合规提醒**：海关提单数据在美国/印度属法定公开信息，可合规使用；但**在开发信中禁止暴露"我查了你的海关数据"**，改用行业观察式表述

---

## 八、常见失败与应对

| 失败情形 | 原因 | 应对 |
|---|---|---|
| 所有源都搜不到公司名 | 公司名拼写不同 / 通过贸易代理出口 | 改用**注册地址** + **HS Code + 出货港**组合反查 |
| 只搜到 1-2 条记录 | 该企业主要走空运/快递，不产生海运提单 | 说明情况，转 LinkedIn / 展会名录 / 官网案例路径 |
| 买家名全是"XX Trading" | 大量小型贸易公司 | 说明该企业客户结构分散，无大客户依赖，撬客难度高 |
| 只有欧洲市场查不到 | 欧盟海关数据不公开 | 如实说明，欧洲买家需走展会名录 / LinkedIn / 行业协会路径 |
