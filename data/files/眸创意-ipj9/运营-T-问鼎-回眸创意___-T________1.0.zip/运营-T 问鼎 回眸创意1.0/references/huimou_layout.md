# 回眸创意 版式指南(基于平台真实样式提炼)

> 参考图见 `assets/huimou_refs/`(3 张平台真实回眸位样式)。
> 出回眸图前**必读本文件 + 把参考图作为 image_edit 的 reference_images 传入**,确保对齐平台调性。
> 回眸是信息流"回访召回"位,基调是"逛 / 发现新供应商",**轻盈干净、非促销硬广**。

## 尺寸(以 ad_specs.md 为准)
- PC 端:380×304(<500k,jpg/png,3 张)— 参考图即此版式,≈1.25:1
- APP 端:486×816(<500k,jpg/png,3 张)— 竖版,把同款版式纵向拉伸,产品区更高

## 版式 DNA(5 个固定元素,从真实样式提炼)

1. **背景**:浅色柔和渐变(浅蓝 #cfe0f5 系 / 浅紫 #c9b8f0 系),叠隐约几何科技线条纹理;
   上半浅、下半略深的双层"地台"感,产品像摆在浅色台面上。
2. **顶部标题**:居中,深色(深蓝/深灰)粗黑体,简短有力。
   - 英文化示例:`Hot Picks` / `Discover New Manufacturers` / `Top Category Suppliers` / `Verified Factory Direct`
3. **中部产品陈列**:**多个去背产品悬浮错落摆放**(3~5 件),大小有层次,体现"多品类 / 一站采购"。
   必须用店铺真实产品图去背后摆入。
4. **底部 CTA**:居中**椭圆深色按钮**(深蓝 #1a2b5c / 深紫),白字短文案。
   - 英文化示例:`View More` / `Explore Now` / `See Details` / `Shop Now`
5. **留白**:四周留白充足,不塞满,轻盈高级。

## 三张一组的叙事建议(回眸需 3 张)
建议 3 张形成递进,而非简单重复:
- 图1 — **多品类精选**:`Hot Picks` + 多品类产品悬浮(主打 SKU 广度)
- 图2 — **工厂/制造实力**:`Discover the Manufacturer` + 代表产品 + 可叠"Self-Owned Factory"小字
- 图3 — **资质/龙头背书**:`Top Category Supplier` + 主推品 + 可叠"ISO·CE Verified"小字

## image 生成要点(配合 SKILL.md 第 3 步)
- 用 `image_edit`,reference_images 同时传:① 对应的平台样式参考图(定版式)② 店铺真实产品去背图(定产品)。
- 提示词强调:`light gradient background (light blue/purple), subtle geometric tech lines, multiple products floating arranged with depth, bold centered top title in dark color, rounded dark CTA button at bottom center, clean, airy, lots of white space, B2B discovery feel`
- aspect_ratio:PC 用最接近 1.25:1 的 `5:4`;APP 竖版用 `9:16`。生成后用 fit_canvas.py 切到精确 380×304 / 486×816。
- 文案语言:默认英文(海外信息流)。标题词务必短,CTA 用平台习惯动词。
- 颜色基调可随品牌主色微调,但保持"浅底 + 深标题 + 深 CTA"的高对比可读结构。

## 自检
- 背景是浅色渐变(不是深色/纯白)
- 标题在顶部居中、深色、可读
- 中部是多个去背真实产品、错落悬浮
- 底部有居中椭圆深色 CTA
- 3 张构成广度→实力→背书的递进
- 精确 380×304(PC)/486×816(APP),体积 <500k
