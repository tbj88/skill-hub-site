#!/usr/bin/env python3
"""
fit_canvas.py — Crop/resize an image to an EXACT pixel size and compress it
below a hard file-size limit (KB).

Why this exists: Alibaba 品牌广告(问鼎/回眸)广告位有两条死规矩——
(1) 尺寸必须精确(很多是非标准超宽比, 如 1280x330 / 1400x140),
(2) 文件体积有上限(多数 <=100k, banner 类 <=500k)。
AI 生成图既不是这些比例, 体积也偏大, 直接上传必然被拒。
本脚本把任意输入图"装进"指定画布并压到限制内, 输出可直接上传的成品。

用法:
  python3 fit_canvas.py INPUT OUTPUT --w 1280 --h 330 --max-kb 100 \
      [--mode cover|contain|pad] [--gravity center|top|bottom|left|right] \
      [--pad-color "#ffffff"] [--fmt jpg|png]

模式说明:
  cover   (默认) 等比放大后居中裁切, 铺满画布无留白 —— 适合背景图/banner。
  contain 等比缩放至完整放入画布, 不裁切, 空白用 pad-color 填充。
  pad     同 contain, 语义别名。
  logo 类透明 PNG 建议用 --fmt png --mode contain 保留透明通道。
"""
import argparse
import io
import os
import sys

try:
    from PIL import Image
except ImportError:
    sys.exit("缺少 Pillow, 请先 pip install Pillow")


def parse_color(s):
    s = s.strip()
    if s.startswith("#"):
        s = s[1:]
    if len(s) == 3:
        s = "".join(c * 2 for c in s)
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


def resize_cover(img, tw, th, gravity):
    iw, ih = img.size
    scale = max(tw / iw, th / ih)
    nw, nh = round(iw * scale), round(ih * scale)
    img = img.resize((nw, nh), Image.LANCZOS)
    # 计算裁切起点
    if gravity == "left":
        x = 0
    elif gravity == "right":
        x = nw - tw
    else:
        x = (nw - tw) // 2
    if gravity == "top":
        y = 0
    elif gravity == "bottom":
        y = nh - th
    else:
        y = (nh - th) // 2
    return img.crop((x, y, x + tw, y + th))


def resize_contain(img, tw, th, pad_color, keep_alpha):
    iw, ih = img.size
    scale = min(tw / iw, th / ih)
    nw, nh = max(1, round(iw * scale)), max(1, round(ih * scale))
    img = img.resize((nw, nh), Image.LANCZOS)
    if keep_alpha:
        canvas = Image.new("RGBA", (tw, th), pad_color + (0,))
    else:
        canvas = Image.new("RGB", (tw, th), pad_color)
    canvas.paste(img, ((tw - nw) // 2, (th - nh) // 2),
                 img if (keep_alpha and img.mode == "RGBA") else None)
    return canvas


def save_under_limit(img, out_path, fmt, max_kb):
    """循环降质/缩放, 直到体积 <= max_kb。返回最终 KB。"""
    max_bytes = int(max_kb * 1024)

    if fmt == "png":
        # PNG 无损, 先试 optimize, 超限则量化到调色板, 仍超限则降分辨率
        for colors in [None, 256, 128, 64]:
            im = img
            if colors:
                im = img.convert("RGBA").quantize(colors=colors, method=Image.FASTOCTREE).convert("RGBA")
            buf = io.BytesIO()
            im.save(buf, "PNG", optimize=True)
            if buf.tell() <= max_bytes:
                with open(out_path, "wb") as f:
                    f.write(buf.getvalue())
                return buf.tell() / 1024
        # 还超限 -> 逐步降分辨率
        scale = 0.9
        while scale > 0.3:
            w, h = img.size
            im = img.resize((max(1, int(w * scale)), max(1, int(h * scale))), Image.LANCZOS)
            buf = io.BytesIO()
            im.save(buf, "PNG", optimize=True)
            if buf.tell() <= max_bytes:
                with open(out_path, "wb") as f:
                    f.write(buf.getvalue())
                return buf.tell() / 1024
            scale -= 0.1
        # 兜底
        img.save(out_path, "PNG", optimize=True)
        return os.path.getsize(out_path) / 1024

    # JPG: 先降质量, 再必要时降分辨率
    rgb = img.convert("RGB")
    for q in range(92, 30, -4):
        buf = io.BytesIO()
        rgb.save(buf, "JPEG", quality=q, optimize=True, progressive=True)
        if buf.tell() <= max_bytes:
            with open(out_path, "wb") as f:
                f.write(buf.getvalue())
            return buf.tell() / 1024
    # 质量降到底仍超限 -> 等比降分辨率(保持目标比例)
    tw, th = rgb.size
    scale = 0.92
    while scale > 0.3:
        im = rgb.resize((max(1, int(tw * scale)), max(1, int(th * scale))), Image.LANCZOS)
        for q in range(80, 30, -5):
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=q, optimize=True, progressive=True)
            if buf.tell() <= max_bytes:
                im_final = im.resize((tw, th), Image.LANCZOS)  # 拉回目标尺寸
                buf2 = io.BytesIO()
                im_final.save(buf2, "JPEG", quality=q, optimize=True, progressive=True)
                data = buf2.getvalue() if buf2.tell() <= max_bytes else buf.getvalue()
                # 若拉回后又超限, 保留缩小版(尺寸不达标会在校验时报警)
                with open(out_path, "wb") as f:
                    f.write(data)
                return len(data) / 1024
        scale -= 0.08
    rgb.save(out_path, "JPEG", quality=35, optimize=True)
    return os.path.getsize(out_path) / 1024


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--w", type=int, required=True)
    ap.add_argument("--h", type=int, required=True)
    ap.add_argument("--max-kb", type=float, required=True)
    ap.add_argument("--mode", default="cover", choices=["cover", "contain", "pad"])
    ap.add_argument("--gravity", default="center",
                    choices=["center", "top", "bottom", "left", "right"])
    ap.add_argument("--pad-color", default="#ffffff")
    ap.add_argument("--fmt", default="jpg", choices=["jpg", "jpeg", "png"])
    args = ap.parse_args()

    fmt = "png" if args.fmt == "png" else "jpg"
    img = Image.open(args.input)
    if img.mode in ("P", "LA"):
        img = img.convert("RGBA")

    keep_alpha = (fmt == "png")
    if args.mode == "cover":
        out = resize_cover(img.convert("RGBA") if keep_alpha else img.convert("RGB"),
                           args.w, args.h, args.gravity)
    else:
        out = resize_contain(img, args.w, args.h, parse_color(args.pad_color), keep_alpha)

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    final_kb = save_under_limit(out, args.output, fmt, args.max_kb)

    # 校验
    chk = Image.open(args.output)
    ok_size = (chk.size == (args.w, args.h))
    ok_kb = final_kb <= args.max_kb + 0.5
    flag = "OK" if (ok_size and ok_kb) else "WARN"
    print(f"[{flag}] {args.output} -> {chk.size[0]}x{chk.size[1]}, "
          f"{final_kb:.1f}KB (limit {args.max_kb}KB)")
    if not ok_size:
        print(f"  ! 尺寸不达标(目标 {args.w}x{args.h}) — 体积限制太紧, 建议简化画面后重试")
    sys.exit(0 if (ok_size and ok_kb) else 2)


if __name__ == "__main__":
    main()
