#!/usr/bin/env python3
"""
circle_strip.py — 把多张产品图裁成圆形缩略,等距排成一行,合成到指定画布上,
底部可加文字标签。专为阿里「自主上传」超宽位(1400x140 等)设计——圆形排列
天然适配极宽画幅,不会因裁切丢内容。

用法:
  python3 circle_strip.py OUTPUT --w 1400 --h 140 --max-kb 5120 \
      --bg "#ffffff" --label-color "#222222" \
      --img p1.jpg "1 Ton" --img p2.jpg "1.3 Ton" ...

说明:
  --img 可重复,每个后跟 图片路径 和 该圆下方的文字标签(标签可为空字符串 "")。
  圆形直径自动按画布高度和是否有标签计算;所有圆在画布内水平居中等距排列。
"""
import argparse
import io
import os
import sys

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    sys.exit("缺少 Pillow")


def parse_color(s):
    s = s.strip().lstrip("#")
    if len(s) == 3:
        s = "".join(c * 2 for c in s)
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


def load_font(size):
    candidates = [
        "/System/Library/Fonts/Helvetica.ttc",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/Library/Fonts/Arial.ttf",
    ]
    for p in candidates:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()


def circle_crop(img, d):
    """center-crop 成正方形再裁成直径 d 的圆形(RGBA)。"""
    img = img.convert("RGB")
    iw, ih = img.size
    s = min(iw, ih)
    img = img.crop(((iw - s) // 2, (ih - s) // 2, (iw - s) // 2 + s, (ih - s) // 2 + s))
    img = img.resize((d, d), Image.LANCZOS).convert("RGBA")
    mask = Image.new("L", (d, d), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, d - 1, d - 1), fill=255)
    img.putalpha(mask)
    return img


def save_under_limit(canvas, out_path, max_kb):
    rgb = canvas.convert("RGB")
    max_bytes = int(max_kb * 1024)
    for q in range(95, 30, -3):
        buf = io.BytesIO()
        rgb.save(buf, "JPEG", quality=q, optimize=True, progressive=True)
        if buf.tell() <= max_bytes:
            with open(out_path, "wb") as f:
                f.write(buf.getvalue())
            return buf.tell() / 1024
    rgb.save(out_path, "JPEG", quality=35, optimize=True)
    return os.path.getsize(out_path) / 1024


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("output")
    ap.add_argument("--w", type=int, required=True)
    ap.add_argument("--h", type=int, required=True)
    ap.add_argument("--max-kb", type=float, required=True)
    ap.add_argument("--bg", default="#ffffff")
    ap.add_argument("--label-color", default="#222222")
    ap.add_argument("--img", nargs=2, action="append", metavar=("PATH", "LABEL"),
                    required=True, help="图片路径 + 文字标签(可为空)")
    ap.add_argument("--title", default="", help="可选:左侧标题文字(占画布左侧一块)")
    ap.add_argument("--subtitle", default="", help="可选:左侧副标题")
    ap.add_argument("--title-color", default="#1a2b5c")
    args = ap.parse_args()

    W, H = args.w, args.h
    bg = parse_color(args.bg)
    label_color = parse_color(args.label_color)
    title_color = parse_color(args.title_color)
    items = args.img
    n = len(items)
    has_label = any(lbl.strip() for _, lbl in items)

    # 圆直径:留出顶部/底部边距;有标签时给底部留文字高度
    label_h = max(14, int(H * 0.16)) if has_label else 0
    top_pad = int(H * 0.08)
    bot_pad = int(H * 0.06)
    d = H - top_pad - bot_pad - label_h
    d = max(20, d)

    font = load_font(max(10, int(label_h * 0.78)))

    canvas = Image.new("RGB", (W, H), bg)
    draw = ImageDraw.Draw(canvas)

    # 可选左侧标题区
    title_w = 0
    if args.title.strip():
        title_w = int(W * 0.26)
        tfont = load_font(max(14, int(H * 0.30)))
        sfont = load_font(max(10, int(H * 0.16)))
        tx = int(W * 0.03)
        if args.subtitle.strip():
            ty = int(H * 0.20)
            draw.text((tx, ty), args.title, fill=title_color, font=tfont)
            sb = draw.textbbox((0, 0), args.title, font=tfont)
            draw.text((tx, ty + (sb[3] - sb[1]) + int(H * 0.12)),
                      args.subtitle, fill=label_color, font=sfont)
        else:
            tb = draw.textbbox((0, 0), args.title, font=tfont)
            draw.text((tx, (H - (tb[3] - tb[1])) // 2 - tb[1]),
                      args.title, fill=title_color, font=tfont)

    # 水平等距:把 n 个圆均匀分布在标题区右侧
    side = int(W * 0.03)
    left = title_w + side
    avail = W - left - side
    slot = avail / n
    cy = top_pad + d // 2

    for i, (path, label) in enumerate(items):
        cx = int(left + slot * (i + 0.5))
        try:
            im = Image.open(path)
        except Exception as e:
            print(f"WARN 跳过 {path}: {e}")
            continue
        circ = circle_crop(im, d)
        canvas.paste(circ, (cx - d // 2, cy - d // 2), circ)
        if label.strip():
            bbox = draw.textbbox((0, 0), label, font=font)
            tw = bbox[2] - bbox[0]
            ty = top_pad + d + max(1, (label_h - (bbox[3] - bbox[1])) // 2) - bbox[1]
            draw.text((cx - tw // 2, ty), label, fill=label_color, font=font)

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    kb = save_under_limit(canvas, args.output, args.max_kb)
    chk = Image.open(args.output)
    ok = chk.size == (W, H) and kb <= args.max_kb + 0.5
    print(f"[{'OK' if ok else 'WARN'}] {args.output} -> {chk.size[0]}x{chk.size[1]}, "
          f"{kb:.1f}KB (limit {args.max_kb}KB), {n} circles")
    sys.exit(0 if ok else 2)


if __name__ == "__main__":
    main()
