#!/usr/bin/env python3
"""
add_badges.py — 在一张背景图上精确叠加"卖点药丸标签(pill badges)"和一个高亮尺寸/数字 tag。
用于把 AI 生成的干净场景背景 + 可控清晰的文案标签结合(AI 直接生成小号多标签不可靠)。

用法:
  python3 add_badges.py INPUT OUTPUT --max-kb 100 \
      --anchor lower-left --start-x 40 --start-y-frac 0.62 \
      --pill "UV Resistant" --pill "Reversible 2-in-1" --pill "Easy to Clean" \
      --accent "Sizes 5'x8' · 6'x9'"

说明:
  - 白色圆角药丸 + 深色文字, 依次纵向排列在锚点(默认左下)。
  - --accent 是一个高亮(陶土橙)标签, 放在药丸上方, 作为视觉抓手。
  - 不改变图片尺寸; 叠加后按 --max-kb 压缩。
  - 字体自动找系统字体。
"""
import argparse, io, os, sys
try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    sys.exit("缺少 Pillow")


def load_font(size, bold=False):
    cands = [
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
        "/Library/Fonts/Arial.ttf",
    ]
    for p in cands:
        if os.path.exists(p):
            try: return ImageFont.truetype(p, size)
            except Exception: pass
    return ImageFont.load_default()


def rounded(draw, xy, r, fill):
    draw.rounded_rectangle(xy, radius=r, fill=fill)


def save_under(img, out, max_kb):
    rgb = img.convert("RGB"); mb = int(max_kb*1024)
    for q in range(95, 30, -3):
        b = io.BytesIO(); rgb.save(b, "JPEG", quality=q, optimize=True, progressive=True)
        if b.tell() <= mb:
            open(out,"wb").write(b.getvalue()); return b.tell()/1024
    rgb.save(out, "JPEG", quality=35, optimize=True); return os.path.getsize(out)/1024


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input"); ap.add_argument("output")
    ap.add_argument("--max-kb", type=float, required=True)
    ap.add_argument("--start-x", type=int, default=40)
    ap.add_argument("--start-y-frac", type=float, default=0.60)
    ap.add_argument("--pill", action="append", default=[])
    ap.add_argument("--accent", default="")
    ap.add_argument("--title", default="", help="大标题文字(无底, 放在标签上方)")
    ap.add_argument("--title-color", default="#1f6b32")
    args = ap.parse_args()

    def parse_color(s):
        s = s.strip().lstrip("#")
        if len(s) == 3: s = "".join(c*2 for c in s)
        return tuple(int(s[i:i+2],16) for i in (0,2,4))

    img = Image.open(args.input).convert("RGBA")
    W, H = img.size
    overlay = Image.new("RGBA", (W, H), (0,0,0,0))
    d = ImageDraw.Draw(overlay)

    fs = max(16, int(H*0.075))
    font = load_font(fs, bold=True)
    pad_x = int(fs*0.7); pad_y = int(fs*0.45); gap = int(fs*0.5)
    x0 = args.start_x
    y = int(H*args.start_y_frac)

    # 大标题(无底)
    if args.title.strip():
        tfs = max(22, int(H*0.16))
        tfont = load_font(tfs, bold=True)
        tb = d.textbbox((0,0), args.title, font=tfont)
        d.text((x0 - tb[0], y - tb[1]), args.title, font=tfont, fill=parse_color(args.title_color)+(255,))
        y += (tb[3]-tb[1]) + int(gap*1.4)

    # accent tag (terracotta)
    if args.accent.strip():
        b = d.textbbox((0,0), args.accent, font=font)
        tw, th = b[2]-b[0], b[3]-b[1]
        w = tw + pad_x*2; h = th + pad_y*2
        rounded(d, (x0, y, x0+w, y+h), h//2, (198,93,59,255))  # terracotta
        d.text((x0+pad_x - b[0], y+pad_y - b[1]), args.accent, font=font, fill=(255,255,255,255))
        y += h + gap

    # white pills
    for txt in args.pill:
        b = d.textbbox((0,0), txt, font=font)
        tw, th = b[2]-b[0], b[3]-b[1]
        w = tw + pad_x*2; h = th + pad_y*2
        rounded(d, (x0, y, x0+w, y+h), h//2, (255,255,255,235))
        d.text((x0+pad_x - b[0], y+pad_y - b[1]), txt, font=font, fill=(38,43,56,255))
        y += h + gap

    out = Image.alpha_composite(img, overlay)
    kb = save_under(out, args.output, args.max_kb)
    chk = Image.open(args.output)
    print(f"[OK] {args.output} -> {chk.size[0]}x{chk.size[1]}, {kb:.1f}KB")


if __name__ == "__main__":
    main()
