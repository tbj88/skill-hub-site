---
name: 汤 交通锥详情制作
description: |
  阿里巴巴国际站「交通锥筒 / 道路安全设施 / PVC 反光警示品」类目专属详情制作技能。
  覆盖 PVC 交通锥、伸缩护栏、反光柱、路桩、防撞条、警示三角、路障、隔离墩、水马、
  减速带等 10 大类道路交通安全后市场产品。给一张产品图（或产品链接/产品名）+「详情制作」二字，
  自动走「4 图极简 · 1200px 宽 · 大宗师 5 步公式（Hook→Scene→Benefit→Proof→CTA）· 
  AIDA 心理链路」路径，产出 4 张模块图 → 拼成 750px 阿里详情标准长图 →
  切成 4 段独立切片（每片 ≤ 1200px 高 · ≤ 500KB · 独立 alt 优化 SEO）→ 
  桌面归档 + 中英文案 txt + alt 标注文件。
  触发关键词：交通锥、路锥、雪糕筒、traffic cone、road cone、safety cone、
  reflective cone、PVC cone、防撞桩、反光柱、警示柱、路桩、隔离桩、
  伸缩护栏、路障、水马、减速带、警示三角、速度限制标志、道路交通设施、
  交通安全用品、safety barrier、traffic barrier、road safety、
  做详情、详情制作、详情图、详情长图、结构详情图、8模块详情、4模块详情、
  出详情、生成详情、做一套详情。
  适用场景：主公提供交通/道路安全类产品图（含 90cm PVC 交通锥、伸缩护栏等），
  要做一套可直接上架国际站/亚马逊的详情长图时触发。
triggers:
  - 交通锥
  - 路锥
  - 雪糕筒
  - traffic cone
  - road cone
  - safety cone
  - 反光锥
  - PVC锥
  - 防撞桩
  - 反光柱
  - 警示柱
  - 路桩
  - 隔离桩
  - 伸缩护栏
  - 路障
  - 水马
  - 减速带
  - 警示三角
  - 道路安全
  - 交通设施
  - safety barrier
  - traffic barrier
  - 详情制作
  - 详情图
  - 4图详情
  - 详情长图
examples:
  - "把这张交通锥做一套详情"
  - "traffic cone 详情制作"
  - "帮我做防撞柱的详情图"
  - "这个伸缩护栏出一套 4 图详情长图"
created_by: user
version: 1.0
last_updated: 2026-07-22
---

# 汤 交通锥详情制作 · SKILL

> 一句话定义：**给一张交通/道路安全产品图 + "详情制作" → 自动出 4 张 1200px 宽模块图 + 750px 长图 + 4 段切片 + 中英文案 + 桌面归档，全流程 15 分钟。**

---

## 一、方法论内核（不可删改）

### 1.1 大宗师 5 步高转化公式（每张图必须承担一步）
```
Hook（痛点唤醒）→ Scene（场景带入）→ Benefit（利益陈述）→ Proof（信任背书）→ CTA（强力召唤）
```

### 1.2 AIDA 心理链路（4 张图 = 4 个阶段）
| # | 图名 | AIDA 阶段 | 大宗师步骤 | 停留目标 |
|---|---|---|---|---|
| 1 | Hero + Value Prop | Attention | Hook + Benefit | 3 秒 |
| 2 | Structure + Spec | Interest | Benefit | 15 秒 |
| 3 | Scene + Proof | Desire | Scene + Proof | 20 秒 |
| 4 | Trust + CTA | Action | Proof + CTA | 15 秒 |
| | | | **总停留** | **≥ 53 秒** |

### 1.3 转化数据基准
- Amazon A+ 精心制作版本转化 **+8~12%**
- 阿里 PIS 评分（Listing 完整度 + 图片质量 + 关键词 + 响应速度）达标即 SEO 加权
- 详情停留 ≥ 50 秒 → 询盘率显著提升

---

## 二、执行流程（固定 6 步，不得增删）

### Step 1 · 触发校验
主公输入必须包含：
- **1 张产品图**（附件 / URL / 阿里 SKU 链接）
- **"详情制作"或同义词**（详情图/做详情/出详情/4图详情/详情长图）

缺任一项 → 立即回复"请补充产品图/详情制作指令"，不启动。

### Step 2 · 产品识别（内部执行，不问主公）
- 读取产品图，识别核心属性：
  - **产品类型**（交通锥 / 护栏 / 路桩 / 减速带 / 水马 / 警示三角）
  - **尺寸**（高度、底座、重量）
  - **材质**（PVC / 橡胶 / PE / 反光膜等级）
  - **配色**（主色 + 反光带颜色 + 底座色）
  - **认证暗示**（MUTCD 美标 / CE EN13422 欧标 / DG3 反光等级）
- 未识别到明确尺寸时用**行业默认值**填充（如交通锥高度 90cm / 底座 45×45cm）。

### Step 3 · 并行生成 4 张模块图（1200px 宽 · 2K 分辨率）

**统一参数**：
- `aspect_ratio="4:5"` · `resolution="2K"` · `task_type="complex_generation"`
- `preserve_product=true` · `reference_images=[原图 URL]`
- **必须并行调用 4 次 `image_edit`，不得串行**

**4 张图 prompt 模板**（按下述结构填充产品参数）：

#### 图 1 · Hero + Value Prop
```
Professional B2B e-commerce hero banner for Alibaba.com. 
Layout: LEFT 45% shows the exact [产品名] from reference at 45° angle on clean light gray gradient background, product occupies 70% of left panel. 
RIGHT 55% shows English bold headline "[产品全称含尺寸]" in 48pt sans-serif black, subtitle "[3 个核心差异卖点]" in 22pt gray, 4 certification badges horizontal: "MUTCD", "CE EN 13422", "[反光等级]", "ISO 9001". 
BOTTOM third: 4 selling point cards in 1x4 horizontal row, each 280x200px with icon+title+one-line spec: 
(1) [高可见性卖点] (2) [重底座/稳定卖点] (3) [耐候性卖点] (4) [堆叠/物流卖点]. 
Style: clean white background, orange accent matching product, professional B2B, no clutter. Aspect ratio 4:5.
```

#### 图 2 · Structure + Spec
```
Professional B2B product structure infographic for Alibaba.com. 
UPPER HALF: Exploded cross-section cutaway diagram of the [产品名] from reference in center, 
5 callout lines with English labels: 
(1) Top: "[顶部部件]" (2) Upper body: "[主体材质厚度密度]" 
(3) Middle: "[反光带/工艺]" (4) Base: "[底座材质重量选项]" (5) Bottom: "[防滑纹理]". 
LOWER HALF: SKU matrix showing 5 sizes side by side ascending: [尺寸1/2/3/4/5], 
current SKU highlighted with orange border and "BEST SELLER" badge, spec label below each: 
Height · Base · Weight · [关键规格] · MOQ. 
Section title "FULL SIZE RANGE - CUSTOM AVAILABLE". Style: clean technical drawing / engineering blueprint feel, white background. English only. 4:5.
```

#### 图 3 · Scene + Proof
```
Professional B2B application scene infographic. 
UPPER HALF: 2x2 grid of 4 real overseas application scenes showing SAME [产品名]: 
(1) [场景 1 - 美国道路施工] (2) [场景 2 - 欧洲停车场] 
(3) [场景 3 - 夜间高速反光] (4) [场景 4 - 校园/活动引导]. 
Section labels in bold English. 
LOWER HALF: Before vs After comparison with center divider. 
LEFT red ❌ "CHEAP COMPETITOR" with 3 bullets: [弱点1/2/3 具体数字]. 
RIGHT green ✅ "OUR [产品]" with 3 bullets: [优势1/2/3 具体数字]. 
Bottom: horizontal comparison bar showing [关键指标 vs 数字]. 
Style: photorealistic scenes merged with clean infographic, English only. 4:5.
```

#### 图 4 · Trust + CTA
```
Professional B2B factory trust and CTA infographic. FOUR SECTIONS stacked: 
SECTION 1 "OUR FACTORY": left factory floor photo, right stats "Monthly Capacity · Established · Area · Workers". 
SECTION 2 "CERTIFICATIONS": 4 badge icons in row "ISO 9001", "CE EN 13422", "MUTCD", "SGS", 
below: "OEM · ODM · Custom Logo · Custom Color · Custom [产品维度]". 
SECTION 3 "PACKAGING & SHIPPING": 3 columns (a) 堆叠图+文案 (b) 20GP/40HQ 装柜量 (c) 4步流程图+lead time. 
SECTION 4 "FAQ": 3 cards horizontal "MOQ: xxx", "Lead Time: xxx", "Sample: xxx". 
BOTTOM CTA: large orange gradient button "GET FOB [港口] QUOTE IN 24 HOURS" + "▶ Send Inquiry Now" + WhatsApp/Email QR icons. 
Style: professional B2B trust-building, orange accent, English only. 4:5.
```

### Step 4 · 拼成 750px 详情长图 + 切片（Python PIL）

**必须执行**下述脚本（不得手工拼接）：

```python
from PIL import Image
import os

sources = [
    "media-output/图1-hero.png",
    "media-output/图2-structure.png",
    "media-output/图3-scene.png",
    "media-output/图4-trust-cta.png",
]

TARGET_W = 750  # 阿里详情标准宽度（勿改）

# 等比缩放并拼接
resized = []
for p in sources:
    img = Image.open(p).convert("RGB")
    w, h = img.size
    new_h = int(h * TARGET_W / w)
    resized.append(img.resize((TARGET_W, new_h), Image.LANCZOS))

total_h = sum(img.height for img in resized)
long_img = Image.new("RGB", (TARGET_W, total_h), "white")
y = 0
for img in resized:
    long_img.paste(img, (0, y))
    y += img.height

# 完整长图
out_full = "[产品名]_详情长图_750px_完整版.jpg"
long_img.save(out_full, "JPEG", quality=88, optimize=True)

# 缩略预览（300px 宽，方便聊天预览）
preview_w = 300
preview_h = int(total_h * preview_w / TARGET_W)
long_img.resize((preview_w, preview_h), Image.LANCZOS).save(
    "[产品名]_详情长图_缩略预览_300px.jpg", "JPEG", quality=85)

# 切片（每片 ≤ 1200px 高，遵守阿里"图片墙防降权"铁律）
SLICE_H = 1200
y, idx = 0, 1
while y < total_h:
    h = min(SLICE_H, total_h - y)
    long_img.crop((0, y, TARGET_W, y + h)).save(
        f"[产品名]_切片_{idx:02d}.jpg", "JPEG", quality=88, optimize=True)
    y += SLICE_H
    idx += 1
```

### Step 5 · 生成中英文案 txt

固定输出 3 个 txt：
- `01_中英标题_5版.txt` — 5 版爆品标题（3 版长尾 SEO + 2 版短促单）
- `02_中英卖点_9条.txt` — 9 条卖点（3 材质 + 3 性能 + 3 服务）
- `03_alt标注_4切片.txt` — 每张切片对应的 alt 关键词

**标题公式**：
```
[材质]+[核心属性]+[产品名]+[尺寸/规格]+[差异卖点]+[认证]
例：PVC High-Visibility Traffic Cone 90cm with 3M Reflective Bands MUTCD DG3 Certified
```

### Step 6 · 桌面归档 + present_files

- 归档路径：`~/Desktop/图片优化/详情/[产品序列号]_[产品名]/`
- `present_files` 展示：完整长图 + 4 张切片 + 3 个 txt

---

## 三、铁律（不可违反）

### 3.1 视觉铁律
1. **4 张图统一 1200px 宽**（源图 4:5 · 2K），拼接后长图 750px 宽
2. **主色调不超过 3 种**（产品色 + 白 + 强调橙/红）
3. **英文字号 ≥ 20pt**（PC）
4. **全部英文**（B2B 主战场是海外买家，禁中英混排）
5. **认证 badge 必须真实**（MUTCD/CE/DG3/ISO/SGS 可查）
6. **场景图必须海外真实场景**（欧美/中东/东南亚），禁国内工地图

### 3.2 内容铁律
1. **参数 → 利益转化**（"3mm 壁厚" → "抗车辆碾压 3 年不裂"）
2. **Before/After 必须具体数字**（"80m vs 300m"，禁"更好"）
3. **CTA 必须给时间承诺**（"24 小时报价"，禁"欢迎垂询"）
4. **场景图必须海外场景**（美国高速 / 欧洲停车场 / 中东活动）

### 3.3 SEO 铁律（阿里 PIS 加分项）
1. 标题埋 3-5 个核心长尾词
2. 每张切片独立 alt（**不得所有切片同 alt**）
3. 属性字段填 100%（材质/尺寸/认证/产地/OEM）
4. 切片 ≤ 500KB / 每片 ≤ 1200px 高

### 3.4 流程铁律
1. **4 张图必须并行生成**（不得串行浪费时间）
2. **preserve_product=true 必开**（防 AI 篡改产品本体）
3. **每张 prompt 必挂原图作 reference_images**
4. **拼接必用 Python PIL**（不得手工 / 不得用 image_edit 拼）
5. **中文文件名用 Python 绝对路径**（不用 zsh cd 中文路径）

---

## 四、跨子品类适配

主 skill 覆盖 10 大类道路交通安全设施，针对不同子品类做**图 2/3 参数微调**：

| 子品类 | 图 2 特化 | 图 3 场景组合 |
|---|---|---|
| **PVC 交通锥**（默认） | 圆锥爆炸图 + 5 尺寸叠层 | 施工/停车场/夜反光/校园 |
| **伸缩护栏 Retractable Barrier** | 伸缩机构 + 展开长度矩阵 | 排队/展会/机场/银行 |
| **反光柱/警示柱 Delineator Post** | 柱体剖面 + 高度矩阵 | 高速/停车场/桥梁/收费站 |
| **路桩 Bollard** | 固定/嵌入方式对比 | 步行街/商店门口/广场 |
| **减速带 Speed Bump** | 拼接结构爆炸 + 长度矩阵 | 小区/停车场/学校/工业区 |
| **水马 Water Barrier** | 注水口结构 + 容量矩阵 | 高速施工/大型活动/边境 |
| **警示三角 Warning Triangle** | 展开机构 + 反光等级 | 汽车后备箱/车辆抛锚现场 |
| **防撞条 Rubber Guard** | 剖面结构 + 长度选项 | 车库/仓库/停车场角落 |
| **隔离墩 Concrete-like Barrier** | 内部注水/注砂结构 | 施工/临时路径/安保 |
| **反光膜 Reflective Sheet** | 反光层级微观图 + 等级对比 | 车贴/标牌/工作服 |

---

## 五、成功案例参考

- **90cm PVC 交通锥**（本 skill 首个案例，2026-07-22）
  - 长图：750×4500 · 0.70MB
  - 切片：4 段（118KB/164KB/261KB/168KB）
  - 存档：主公 project 目录
  - 效率：4 张图并行生成 + 拼接 = 15 分钟

---

## 六、下一步选项（每次交付后必给主公 3 选 1）

- **A. 全部通过** → 桌面归档 + 出中英文案 txt + alt 标注
- **B. 某张重做** → 说清哪张 + 改什么（如"图 3 场景全换白天欧洲街景"）
- **C. 直接发品** → 挂《alibaba-product-publish》skill，上架国际站

---

_版本历史_：
- v1.0 (2026-07-22)：主公在 90cm PVC 交通锥项目验证通过后沉淀，融合《汤 详情制作技能》4 图版 + 大宗师 5 步公式 + 阿里 PIS 铁律 + Amazon A+ 2026 转化数据。
