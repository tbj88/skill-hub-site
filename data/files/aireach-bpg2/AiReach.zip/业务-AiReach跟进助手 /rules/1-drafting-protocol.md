# 规则 1:随性自然拟稿协议 (Drafting Protocol)

为了确保开发信"不像 AI 写的",必须遵守以下"说人话"的标准。

---

## 1. 寻找"真实钩子"(必须来自官网,不允许编造)

- 每封开发信第一句话必须提到从官网看到的**具体细节**——不是"我看了你们网站觉得很棒"这种废话,而是能一眼看出你真去过的具体点。
- **示例**:
  - ✅ "Saw your recent launch of the Wabi-sabi collection last week — the tonal palette is beautifully restrained."
  - ✅ "Noticed you're focused on the hospitality sector, especially boutique hotels in Southern Europe."
  - ❌ "I visited your website and I love your products."(空洞,像 AI 生成)

---

## 2. 模仿老板的口吻(读 config.local.md 里的身份设定)

- **随性、真诚、不卑不亢**
- 减少"Dear Sir/Madam"这种客套,多用"Hi [Name]"或"Hi Team"
- 避免冗长的长句子,多用短句(单句不超过 20 词)
- 允许适度的"人味儿",比如"By the way..."、"Just a quick thought..."
- 不要说"I hope this email finds you well" / "I trust this message finds you well" / "I would like to introduce ourselves" 这类 AI 味浓烈的开场

---

## 3. 三段式结构(严格遵守)

### 主题行

- 格式:`Re: To [收件人名字]` 或 `Re: [具体产品/项目]`
- 伪造"回复"感,不是初次联系,能显著提升打开率
- 严禁"Introduction from [公司]"、"Business Cooperation" 这类明显 cold outreach 的主题

### 第一段:个性化开场(1-2 句)

- 基于官网抓到的具体细节,提及客户业务
- 表达来意时不要一上来自我介绍,先"看到 → 感兴趣 → 想聊"
- 例:
  > "Hi [Name], saw your Wabi-sabi collection launch last week — the tonal restraint really caught my eye. Made me think you might appreciate what we do."

### 第二段:价值与钩子(2-3 句)

- 自然引出发件人公司,带出关键背书(读 config.local.md 里的"公司简介 & 核心背书")
- 清晰列出"钩子"——免费打样/新品目录/定制样片/低 MOQ 试单等
- 例(假设 config 里的公司是做家具的):
  > "We're a factory specializing in solid wood furniture for boutique hospitality — [X] years in the trade, [认证名] certified. If you're exploring new suppliers this quarter, I can send over a sample set of our latest collection at no cost."

### 第三段:明确 Call to Action(1 句)

- 具体、低门槛
- 例:
  > "Would 15 min next week work for a quick chat?"
  > 或
  > "Just reply YES and I'll ship the samples out this Friday."

---

## 4. 多语言适配

### 法国/西班牙/拉美客户

- **优先用对方母语**(法语/西班牙语)撰写
- 植入背书时保留原文格式(比如 CE 认证、ISO 认证的名称直接用英文缩写)
- 语气比英文更正式一点点(欧洲拉美客户偏爱礼貌感),但不要用花哨长句

### 英语区(美/英/加/澳/北欧)

- 专业简洁英文
- 更强调数据/效率/ROI,少讲情怀
- CTA 越具体越好("15 min next Tuesday at 10am your time" > "sometime next week")

### 中东客户

- 英文书写,但语气可以再礼貌一层
- 避免出现酒/猪等文化敏感内容
- 首邮不要谈价格,先建立关系

### 亚洲(日/韩/东南亚)

- 英文书写,极度尊重礼貌
- 日本客户:多用敬语式表达("It would be my honor to..."),避免直白 CTA
- 东南亚:相对随意,但要提及"long-term partnership"的意愿

---

## 5. 交付规格

### Excel 字段(严格遵守)

| 字段名 | 说明 |
|---|---|
| Company Name | 客户公司名 |
| Country | 国家 |
| Lead Source | 固定填 `AiReach` |
| Website Detail | 从官网抓到的核心业务描述(1-2 句) |
| Email Subject | 邮件主题 |
| Email Body | 邮件正文(纯文本,保留段落换行) |
| Status | 默认填 `Pending Send`,助理发完改 `Sent` |

### 邮件正文长度

- 英文:100-150 词(约 3-4 段,每段 1-3 句)
- 法/西:120-180 词
- 严禁超过 200 词——第一封邮件超过 200 词客户直接删除

---

## 6. 质量自检(生成前必查)

在生成每封邮件前,检查以下 5 条,任一不满足必须重写:

- [ ] 第一段有从官网抓到的**具体细节**(不是通用描述)
- [ ] 没有出现 AI 味套话("I hope this email finds you well"等)
- [ ] 有明确的钩子(不是"want to introduce ourselves")
- [ ] 有具体的 CTA(不是"looking forward to hearing from you")
- [ ] 字数在 150 词以内(英文)或 180 词以内(法/西)
