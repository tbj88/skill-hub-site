# 首次运行配置示例(config.local.md 的填写样例)

⚠️ **本文件仅为示例参考**,请勿直接使用。首次运行 skill 时,skill 会引导你填写你自己公司的信息,并保存到 `config.local.md`(同目录下)。

---

## 一、发件人身份(填你自己)

- **发件人姓名**:Alex(你希望客户邮件里看到的英文名,可以是英文名或全名)
- **职位**:Sales Director(建议用 CEO/Sales Director/Founder 这类抬头,提高被认真回复的概率)
- **公司名称(英文完整名)**:XXX International Co., Ltd.
- **公司主页 URL**:https://www.your-company.com

## 二、公司简介 & 核心背书(2-3 句话)

- **主营产品/服务类别**:solid wood furniture(实木家具)/ home textile(家纺)/ 换成你自己的
- **关键背书**:
  - X 年工厂/贸易经验(具体年数)
  - 关键资质认证(CE / FSC / BSCI / ISO 等,填你实际有的)
  - 服务过的知名客户(如果可以公开提及)
- **差异化卖点**:
  - 卖点 1(例如"低 MOQ 支持 100 pcs 起订")
  - 卖点 2(例如"7 天内出样")
  - 卖点 3(例如"欧洲本地仓可 3 天达")

## 三、销售政策

- **起订量(MOQ)**:100 pcs / 500 pcs / 具体数字
- **打样政策**:免费打样 / 样品费 $XX(下单后返)
- **付款条件**:T/T 30% deposit + 70% before shipment / L/C at sight

---

## 完整示例(替换成你自己的)

```markdown
# 我的公司配置

## 发件人身份
- 姓名:Alex
- 职位:Sales Director  
- 公司:XXX International Co., Ltd.
- 网站:https://www.your-company.com

## 公司简介
15+ years OEM/ODM manufacturer of solid wood furniture, based in Zhejiang, China.
Certifications: FSC, CARB P2, BSCI.
Known clients: [填你能公开提的]

## 差异化卖点
- MOQ from 100 pcs
- 7-day sampling turnaround  
- EU warehouse in Rotterdam (3-day delivery)

## 销售政策
- MOQ: 100 pcs
- Sample: Free (customer pays freight)
- Payment: T/T 30% + 70% before shipment
```

---

**填好后,请重命名为 `config.local.md` 保存在本技能同目录下。**
**⚠️ `config.local.md` 不要提交到 git 或分享给他人,里面是你自己公司的销售政策。**
