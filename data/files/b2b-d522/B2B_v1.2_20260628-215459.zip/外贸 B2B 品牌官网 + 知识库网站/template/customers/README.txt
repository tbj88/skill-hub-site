# 合作客户 Logo

5-8 个核心客户即可，文件命名：序号-品牌名.png
要求：PNG 透明背景，宽度 ≥ 200px

示例：
  001-home-depot.png
  002-lidl.png
  003-aldi.png

本目录还需一个 README.txt，记录每个客户的：
  - 合作开始年份
  - 合作类型（ODM / OEM / 私标 / 直供 / 渠道）
  - 年订单量（可选，可写区间如 $200K+）

—— 涉及保密 ——
有 NDA 不能公开的客户：
  - 文件名加 [INTERNAL] 前缀，如：[INTERNAL]-walmart.png
  - 网站对外不展示，仅内部模式（业务员）可见
