# 资质证书

文件命名格式：序号-资质名.jpg（一张证书一个文件）
示例：
  001-高新技术企业证书.jpg
  002-TUV-Rheinland.jpg
  003-CE-Certificate.jpg
  004-BSCI-Report.jpg
  005-发明专利-ZL2018xxx.jpg

本目录还需要一个 README.txt，列出每张证书的：
  - 颁发机构（必填）
  - 有效期
  - 官网查询链接（强烈建议 —— 没有验证链接的资质，B2B 买家信任度下降 60%）

—— 示例 README ——

001-高新技术企业证书
颁发机构: 浙江省科技厅
有效期: 2023-2026
官网查询: https://www.most.gov.cn/...

002-TUV-Rheinland
颁发机构: 德国 TÜV Rheinland
证书编号: AK60123456
官网查询: https://www.certipedia.com/cert/AK60123456
