# 产品信息（二选一）

## 方式 A：Excel 表格（推荐 — 适合 20+ 个产品）
将本目录新建一个 products.xlsx，表头：

SKU | 产品名（中文）| 产品名（英文）| 价格区间 | 起订量 | 详情链接 | 主图链接

把表格填好，AI 会自动批量导入。

## 方式 B：单独文件夹（适合 < 10 个产品，信息更详细）
为每个 SKU 建一个子文件夹：
  AY-001/
    info.txt
    01-main.jpg
    02-detail.jpg
    03-scene.jpg
  AY-002/
    ...

info.txt 格式见 INPUT_GUIDE.md 第 02 节。

## 已有 Alibaba.com 店铺？
不用准备这个文件夹，直接把店铺链接发给 AI 即可，会自动爬。
