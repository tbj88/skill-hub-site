# 📦 公司资料准备指南
# Company Materials Preparation Guide

> 把这份指南发给客户/公司行政，让他们按照下面的文件夹结构准备资料。
> 准备好后整个文件夹打包发给你，AI 就能直接做出网站。

---

## 🗂️ 必须的 6 个子文件夹（缺一会做不全）

复制 `template/` 文件夹，重命名为客户名字（如 `aiyisi-materials/`），里面 6 个子文件夹按下面填：

```
你的公司名-materials/
├── 01-company-profile/       # 公司基础信息
├── 02-products/              # 产品清单 + 图片
├── 03-certifications/        # 资质证书扫描件
├── 04-customers/             # 合作客户 Logo
├── 05-trade-shows/           # 参展记录
└── 06-team-photos/           # 工厂/团队/办公环境照片
```

---

## 📁 01-company-profile/ — 公司基础信息

**必填 3 个文件**：

### `info.txt`（公司核心信息）

```
公司中文全称：台州爱以思休闲用品有限公司
公司英文全称：Taizhou Aiyisi Leisure Products Co., Ltd.
品牌名（短）：AIYISI
成立日期：2014-08-26
注册资本：500 万人民币
厂区面积：25000 平方米
员工人数：80
年产能：100 万件
出口比例：90%
主营品类（一句话）：户外 PP 编织地垫（房车 / 露台 / 沙滩用）
目标市场：北美、欧洲、大洋洲、中东
官方邮箱：sales@tzaiyisi.com
公司地址：浙江省台州市
高新技术企业：是（编号 XXX）
专利数量：9
```

### `usp.txt`（3-5 个核心卖点，每个 1 句话）

```
1. 国家级高新技术企业 + 9 项产品专利
2. 德国 TÜV Rheinland 认证，符合欧美主流标准
3. 200+ 套全工艺设备：机织+提花+绞编+双面可逆
4. 2 名研发工程师，支持图纸/打样定制
5. 广交会 6+ 届常驻，Spoga+Gafa & Heimtextil 持续参展
```

### `logo.png`（品牌 Logo）

- **要求**：PNG 透明背景，分辨率 ≥ 500×500
- **如果只有 JPG**：附在文件夹，AI 帮抠图
- **如果完全没有**：留空，AI 帮生成

---

## 📁 02-products/ — 产品清单

**两种方式选一个**：

### 方式 A：Excel 表格（推荐 — 适合 20+ 个产品）

文件名 `products.xlsx`，表头如下：

| SKU | 产品名（中文） | 产品名（英文） | 价格区间 | 起订量 | 详情链接 | 主图链接 |
|---|---|---|---|---|---|---|
| AY-001 | 户外 PP 房车垫 6x9 | Outdoor RV Mat 6x9 | $6.5-9.0 | 200 pcs | https://... | https://... |

### 方式 B：单独文件夹（适合 < 10 个产品 + 有详细信息）

```
02-products/
├── AY-001/
│   ├── info.txt           # SKU/价格/起订量/规格参数
│   ├── 01-main.jpg        # 主图（必须）
│   ├── 02-detail.jpg      # 附图（可选，多张）
│   └── 03-scene.jpg
└── AY-002/
    └── ...
```

`info.txt` 示例：

```
SKU: AY-001
名称（中）: 户外 PP 房车垫 6x9
名称（英）: Outdoor RV Mat 6x9
价格: $6.5-9.0
起订量: 200 pcs
材质: 100% 再生聚丙烯 PP
工艺: 双面可逆编织
尺寸: 6x9 ft (180x270 cm)
克重: 800 g/m²
特性: 可水洗、防霉、抗 UV、防滑
卖点: 北美房车市场首选 ODM，复购率 38-50%
YouTube 视频: https://youtube.com/...（可选）
```

**如果你已经有 Alibaba.com 店铺**：发我店铺链接即可，**不用填 Excel**，AI 自动爬。

---

## 📁 03-certifications/ — 资质证书

每张证书一张图（JPG 或 PDF 转 JPG），文件名规范：

```
03-certifications/
├── 001-高新技术企业证书.jpg
├── 002-TUV-Rheinland.jpg
├── 003-CE-Certificate.jpg
├── 004-BSCI-Report.jpg
├── 005-发明专利-ZL2018xxx.jpg
└── README.txt          # 列每张证书的简介 + 颁发机构 + 验证链接（如有）
```

`README.txt` 示例：

```
001-高新技术企业证书
颁发机构: 浙江省科技厅
有效期: 2023-2026
官网查询: https://www.most.gov.cn/...

002-TUV-Rheinland
颁发机构: 德国 TÜV Rheinland
证书编号: AK60123456
官网查询: https://www.certipedia.com/cert/AK60123456
```

**没有官网查询链接的资质**：列出来也行，但减分（B2B 买家最看重可验证性）。

---

## 📁 04-customers/ — 合作客户 Logo

**5-8 个核心客户的 Logo**（PNG 透明背景，宽度 ≥ 200px）：

```
04-customers/
├── 001-home-depot.png
├── 002-lidl.png
├── 003-aldi.png
├── 004-kmart.png
├── 005-metro.png
└── README.txt          # 列每个客户的合作年限 + 合作类型
```

`README.txt` 示例：

```
The Home Depot
合作开始: 2018
合作类型: ODM 供应
年订单量: $200K+

Lidl
合作开始: 2020
合作类型: 私标代工
```

**有 NDA 不能公开**的客户：放在文件夹但 README 标注 `[INTERNAL]`，AI 只在内部模式显示。

---

## 📁 05-trade-shows/ — 参展记录

每个展会一个子文件夹：

```
05-trade-shows/
├── canton-fair/
│   ├── info.txt           # 展会基本信息
│   ├── poster.jpg         # 展会海报
│   ├── 2024-spring.jpg    # 各届实景照
│   ├── 2024-autumn.jpg
│   └── 2025-spring.jpg
├── spoga-gafa/
│   ├── info.txt
│   └── ...
└── heimtextil/
    └── ...
```

`info.txt` 示例：

```
展会名称（中）: 广交会
展会名称（英）: Canton Fair
官方网址: https://www.cantonfair.org.cn/
举办城市: 广州
我们的展位号传统: H11.2 G12（每届一般固定区域）
参展届次:
  - 2024 春季（第 135 届）展位 11.2 G12
  - 2024 秋季（第 136 届）展位 11.2 G12
  - 2025 春季（第 137 届）展位 11.2 H08
```

**没有展会的中小企业**：留空文件夹也行，网站会自动隐藏该模块。

---

## 📁 06-team-photos/ — 工厂/团队/办公照

5-10 张高清横幅图（用作 Hero 轮播 + Why 卡片背景）：

```
06-team-photos/
├── 01-factory-exterior.jpg     # 工厂外景（最重要）
├── 02-production-line.jpg      # 生产线
├── 03-warehouse.jpg            # 仓库
├── 04-quality-control.jpg      # 质检
├── 05-rd-team.jpg              # 研发团队
├── 06-office.jpg               # 办公环境
├── 07-product-in-scene.jpg     # 产品在使用场景（最高优先级）
└── 08-shipping-loading.jpg     # 装柜出货
```

**Hero 大图要求**（最关键）：
- 宽度 ≥ 1920px
- **横版 21:9 比例**（如果是方形，AI 会自动扩展，但效果不如原生横版）
- 不能有水印、不能有 QR 码、不能有公司文字标识（让 AI 写文字标语）

**如果没有专业摄影**：拍手机也行，但**白天自然光 + 横屏 + 镜头平视 + 不要逆光**。

---

## 🚀 准备完成后

把整个 `你的公司名-materials/` 文件夹**压缩成 zip**，发给 AI（拖进对话即可）。

AI 收到后会：
1. **5 分钟内**回复一份"我看到了什么 + 我缺什么"的清单
2. **30 分钟内**做出网站雏形给你预览
3. **2-4 小时内**完成正式部署 + 给你 3 个 URL + 操作手册

---

## ❌ 常见错误 / 避坑指南

| 错误 | 后果 | 怎么改 |
|---|---|---|
| 文件名带中文 + 空格 + 特殊字符 | AI 处理失败 | 文件名用英文/数字/连字符，如 `001-tuv-cert.jpg` |
| 照片有水印 / 二维码 / 文字 | 网站显得 low | 重拍，或让 AI 抹除 |
| 把 30 张图都叫 `IMG_xxxx.jpg` | AI 不知道哪是哪 | 重命名为 `01-factory-exterior.jpg` 这种 |
| Excel 表格表头不规范 | 数据导入错乱 | 严格按本文档表头复制 |
| 客户 Logo 是 JPG 不是 PNG | 背景白底突兀 | 让 AI 抠图，或换 PNG 透明背景版本 |
| Hero 图是竖版（手机拍的） | 网站头部被截掉一半 | 必须横屏拍，或专业摄影 |
| 资质证书没填颁发机构 | 买家不信 | 一定要写颁发机构 + 验证链接 |

---

## 📞 还有问题？

把这份指南发给客户时，强调一句话：

> **"质量胜过数量。10 张精心准备的高清照片 + 5 个完整资质，胜过 100 张乱七八糟的截图。"**

