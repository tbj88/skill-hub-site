# SKILL.patch.md — 铁律补丁 (v1.1)

> 本补丁基于 QIDA Recycling + XinNeng Silicone 两次真实项目沉淀。
> 加载 SKILL.md 后**必须同时应用本补丁**。冲突以本补丁为准。
> 任何"首版交付"必须默认带这里所有项，不要等主公一次次让加。

---

## §1 部署链路铁律（最高优先级）

### §1.1 GitHub Pages 部署：必须用 Contents API 兜底

`git push` 经常因运营商/防火墙间歇性限制 `github.com:443` HTTP/2 framing 失败（典型报错 `HTTP/2 stream X was not closed cleanly` / `Empty reply from server`）。一旦 push 第二次仍失败：

**立即切到 GitHub Contents API 单文件 PUT**：
```python
PUT https://api.github.com/repos/{OWNER}/{REPO}/contents/{path}
body = {"message":"...", "content": base64(file), "branch":"main", "sha":<前次sha>}
```
- API 端点是 `api.github.com`（不是 `github.com`），通常不被同一规则拦截
- 含图片/PDF 时直接 base64 上传二进制
- 每个文件 PUT 后 sleep 0.3-0.4s，避免触发 secondary rate limit
- 路径含中文时用 `urllib.parse.quote`，否则会 404

**禁止行为**：
- ❌ 反复重试 git push 超过 2 次（会卡住主流程很久）
- ❌ 让用户自己 push（除非用户主动表示愿意）
- ❌ 用 `gh auth login` 让用户在终端授权（增加用户操作步骤）

### §1.2 PAT 创建：用 browser 子代理代操作

不要让主公手动复制粘贴。spawn `browser` 子代理直接操作他已登录的 GitHub 页面：

```
sessions_spawn(agent_id="browser", task="""
打开 https://github.com/settings/personal-access-tokens/new
确认已登录 tbj88；填写：
- Token name: {project}-deploy
- Expiration: 30 days
- Repository access: All repositories
- Permissions: Administration/Contents/Pages 均 Read and write
点 Generate token，返回 token 字符串
""")
```

### §1.3 PAT 生命周期

- 部署完成立即提醒主公"30 天后失效，建议手动 Revoke 并日常用小权限 PAT"
- 日常 admin PAT 只需 `Contents: Read and write` + 单仓库 access
- 一个 PAT 跨多个项目复用可以，但部署完务必提醒可撤销

---

## §2 多语言铁律

### §2.1 所有面向用户的字段必须 4 语言完整覆盖

每个 `data.json` 文本字段（hero/why/cats/partners/regions/certs/products name+desc/footer 标签）格式：
```json
{"en":"...", "zh":"...", "de":"...", "es":"..."}
```
**禁止只填 en**——admin 后台机翻按钮一秒补全，初版交付就要 4 语全。

### §2.2 防机翻钢印（极其重要 · 主公必踩坑）

Chrome 自带翻译/沉浸式翻译/百度翻译插件会把整页英文界面机翻成奇怪中文：
- "QIDA Recycling" → "QIDA回收" ❌
- "Home" → "家" ❌
- "Product Catalog" → "产品目录"（覆盖了网站真正的中文版本）
- "English" → "英语" ❌

**必须给以下元素加 `translate="no"`**：
1. `<html lang="en" translate="no">` + `<meta name="google" content="notranslate">`
2. 品牌名（顶部 logo + 页脚）
3. 语言切换器 + 所有语言名按钮
4. 所有 H2 大标题
5. 所有 `.section-head` 容器
6. SKU / 型号 / 数据成就横条（数字+单位不需要翻）

**`setLang()` 切换语言时**必须同步：
```js
document.documentElement.lang = (l==="zh"?"zh-CN":l);  // 让 Chrome 知道已切换
document.documentElement.setAttribute("translate","no"); // 阻止再次提示翻译
```

### §2.3 UI 字段统一从 `DATA.ui` 取

按钮文字、占位符、filter 下拉、面包屑等所有 UI 文案：
- HTML 用 `data-uk="keyName"` 取文本
- input/textarea 用 `data-uk-placeholder="keyName"` 取 placeholder
- 必备 ui 键清单：navHome/navCatalog/navCerts/navPartners/navStaff/navSop/ctaContact/ctaCatalog/ctaInquire/catalogEyebrow/catalogPageTitle/catalogSearchHint/filterAll/filter<Category>/backHome

### §2.4 标准 16 语言体系（v1.2 升级）

不再是 4 语（EN/ZH/DE/ES）兜底，**首版即上 16 语**，对应 Alibaba.com 国际站官方 16 语种入口（覆盖全球 95% 跨境买家市场）：

```js
const LANGS = [
  {code:"en", flag:"🇺🇸", label:"English",       group:"global"},
  {code:"zh", flag:"🇨🇳", label:"简体中文",       group:"asia",   htmlLang:"zh-CN"},
  {code:"de", flag:"🇩🇪", label:"Deutsch",       group:"europe"},
  {code:"es", flag:"🇪🇸", label:"Español",       group:"europe"},
  {code:"fr", flag:"🇫🇷", label:"Français",      group:"europe"},
  {code:"it", flag:"🇮🇹", label:"Italiano",      group:"europe"},
  {code:"pt", flag:"🇵🇹", label:"Português",     group:"europe"},
  {code:"nl", flag:"🇳🇱", label:"Nederlands",    group:"europe"},
  {code:"ru", flag:"🇷🇺", label:"Русский",       group:"europe"},
  {code:"tr", flag:"🇹🇷", label:"Türkçe",        group:"europe"},
  {code:"ja", flag:"🇯🇵", label:"日本語",         group:"asia"},
  {code:"ko", flag:"🇰🇷", label:"한국어",         group:"asia"},
  {code:"th", flag:"🇹🇭", label:"ไทย",           group:"asia"},
  {code:"vi", flag:"🇻🇳", label:"Tiếng Việt",    group:"asia"},
  {code:"hi", flag:"🇮🇳", label:"हिन्दी",          group:"asia"},
  {code:"ar", flag:"🇸🇦", label:"العربية",       group:"mideast", rtl:true}
];
```

**地理分组**（弹窗按区显示）：Global / Asia Pacific / Europe / Middle East

**默认显示语**：英文。`setLang()` 同时更新：
- `document.documentElement.lang = meta.htmlLang || l`
- `document.documentElement.setAttribute("translate","no")`
- `document.documentElement.dir = meta.rtl ? "rtl" : "ltr"`（阿语 RTL 必须）
- 切换器按钮显示 `flag + label`

### §2.5 全屏语言弹窗（替代下拉菜单）

≥10 语时下拉条放不下。**强制用全屏 modal**：
- 触发器：导航栏右侧一个 🌐 图标按钮，点击 `openLangModal()`
- 弹窗：rgba(15,23,42,.55) 半透明遮罩 + blur(4px) + 中央 max-width 1100px 卡片
- 内容：标题 + 4 列网格 × 4 地理分组，每行 `flag + label + (active时✓)`
- 关闭：右上 ×、点击遮罩、按 ESC 三种
- 弹窗打开时 `document.body.style.overflow="hidden"` 锁背景滚动
- 移动端：`@media(max-width:900px)` 改 2 列，500px 改 1 列
- 当前语言行高亮：`.lang-row.active` 主色边框 + 主色文字 + 加粗

完整 CSS / HTML / JS 模板见参考实现：`xns/index.html`（`.lang-modal-*` 选择器 + `openLangModal()` 函数）。

### §2.6 批量机翻 12+ 语言：用 Google 公共端点 + **降低并发**

新加语言时把 data.json 所有 i18n 字段批量机翻到目标语言：

```python
# 端点（公共、不需 key）
url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl={lang}&dt=t&q={urllib.parse.quote(text[:5000])}"
```

**关键教训（v1.2 实战踩坑）**：
- ❌ **不要用 12 线程并发** → Google 公共端点会软限速，实测 12 线程跑 1500 条任务要 10+ 分钟还跑不完
- ✅ **用 4 线程 + 每条 sleep 0.3s** → 1500 条约 4-5 分钟稳定完成
- ✅ **必须加缓存 `CACHE = {(text, lang): result}`** → 同一句话重复出现时不重复请求
- ✅ **失败回退用英文原文**，不要让字段空着
- ✅ **每 50 条打印进度**，跑长任务时主公能看到状态
- ✅ **整页用 `run_in_background:true`** 一次跑完，主流程不阻塞
- ✅ **递归扫描**：`is_i18n_dict(v)` 判断只要含 `en` 键就视为 i18n 字段，自动覆盖 hero/why/cats/partners/regions/certs/products/footer/ui 所有层级
- ⚠️ 翻译完后 data.json 体积会膨胀 4-5 倍（16 语 vs 4 语），但仍在 GitHub Pages 1GB 限制内远远没事

**禁止行为**：
- ❌ 用 admin 后台 🌐 Translate 按钮逐条点（1500 次点击不现实）
- ❌ 跨主进程修改 data.json（后台翻译时如果手改会冲突）


- input/textarea 用 `data-uk-placeholder="keyName"` 取 placeholder
- 必备 ui 键清单（首版就要齐）：
  - `navHome / navCatalog / navCerts / navPartners / navStaff / navSop`
  - `ctaContact / ctaCatalog / ctaInquire`
  - `catalogEyebrow / catalogPageTitle / catalogSearchHint`
  - `filterAll / filter<Category>` (每个产品分类一个)
  - `backHome`

**禁止行为**：HTML 里硬编码英文文本（除品牌名/型号/SKU 外）。

---

## §3 路由与导航铁律

### §3.1 所有子页必须有"返回首页"按钮

包括：catalog / certs / partners / intel / sop。位置：左上角，标题之前。样式：
```css
.page-back{display:inline-flex;align-items:center;gap:8px;padding:9px 16px;background:#fff;border:1px solid var(--c-line);border-radius:8px;font-weight:600;color:var(--c-primary);transition:all .15s}
.page-back:hover{background:var(--c-primary);color:#fff;border-color:var(--c-primary);transform:translateX(-2px)}
```
HTML：`<a class="page-back" href="#" onclick="route('home');return false" data-uk="backHome">← Back to Home</a>`

**产品详情页**返回按钮升级同款样式（`.pd-back` 也走这个视觉），返回到 catalog 而不是 home。

### §3.2 子页不要重复 eyebrow

子页 HTML 结构只保留：`page-back + H2 标题`。
**不要**在子页 H2 上方加小标题 eyebrow（"CATALOG / CREDENTIALS / INTERNAL"）——它会和 H2 重复，主公会要求去掉。

**首页例外**：首页 4-5 个大区段（Why Us / Catalog / Customers / Global Reach）的 eyebrow 保留，它们是首页内部分隔不同区段的视觉标签。

### §3.3 产品目录页：sticky 工具条

产品列表页用户会滚很久。**返回按钮 + 标题 + 搜索框 + 分类筛选**必须包在 `.catalog-sticky` 容器里，吸附在顶部导航下方：

```css
.catalog-sticky{position:sticky;top:69px;z-index:30;background:rgba(<bg-rgb>,.94);
  backdrop-filter:saturate(180%) blur(10px);
  margin:0 -24px 24px;padding:18px 24px 16px;
  border-bottom:1px solid var(--c-line);transition:box-shadow .2s}
.catalog-sticky.is-stuck{box-shadow:0 4px 14px rgba(<ink-rgb>,.08)}
```
+ IntersectionObserver 用 sentinel 元素判断是否吸顶，触发 `.is-stuck` 阴影。
+ catalog page 的 section 外壳 `padding-top:0` 避免上方空白叠加。

---

## §4 LOGO 处理铁律

### §4.1 LOGO 三尺寸标准

主公给的 LOGO 一定是带白底的 JPG。**必须**：
1. `image_edit` task_type=`white_background` 抠透明
2. Pillow 兜底再扫一遍（image_edit 偶尔输出 RGB 而不是 RGBA）：
```python
threshold=240; soft=215  # 接近白阈值 + 软边
```
3. 生成 3 尺寸：
   - `{brand}-logo.png` 原图 / 1024px（高清印刷）
   - `{brand}-logo-256.png` 256×256（导航 + 页脚 + apple-touch-icon）
   - `{brand}-favicon.png` 64×64（浏览器 tab）
4. `<link rel="icon">` + `<link rel="apple-touch-icon">` 都加上

### §4.2 LOGO 在导航 / 页脚的容器

- **导航 logo**：透明背景直接放（40-42px 见方），无衬底
- **页脚 logo**：深色背景需要**白色圆角衬底**（44px + padding 4px + border-radius 8px），否则深色 LOGO 在深色背景上糊掉

```css
.footer .ft-brand .gear{width:44px;height:44px;background:#fff;border-radius:8px;
  display:flex;align-items:center;justify-content:center;flex-shrink:0;padding:4px}
.footer .ft-brand .gear img{width:100%;height:100%;object-fit:contain}
```

### §4.3 没有真 LOGO 时的占位

用品牌色渐变方块 + 首字母（如 "Q"/"X"）。**绝不**用 emoji 或现成图标库。后续 admin 上传真 LOGO 后无缝替换。

---

## §5 产品目录铁律

### §5.1 不要画饼数据

主公会盯着数字成就横条 (`.stats`) 砍掉所有不可验证的硬数字：
- ❌ "11 年制造经验"（除非确认工商年份）
- ❌ "≤7h 响应时长"（看起来软）
- ❌ "100+ 已交付设备"（无凭据）

**首版只用绝对可证的硬数据**：
- ✅ 证书简称（FDA / CE / LFGB）
- ✅ MOQ 阈值（100 / 1 set）
- ✅ 关键产品技术参数（99% / 230°C）
- ✅ 厂区面积（阿里店铺已披露）

### §5.2 6 项 stats → 4 项 stats

老套路 6 项太密，新规：**4 项 4 列等宽**（max-width 1100px），数字字号放大到 32-48px。

### §5.3 产品数量决定 UI 复杂度

| 产品数 | 工具条形态 |
|---|---|
| ≤ 10 | 当前 V1：搜索框 + 1 个分类下拉 |
| 10-50 | V1 + 必须 sticky（§3.3）|
| 50-200 | V2：sticky + filter chips 多维筛选 |
| > 200 | V3：左侧 200px 永久侧边栏 |

XinNeng 项目 50 款已触发 sticky 必要性。

### §5.4 数据来源：阿里店铺批量爬

主公会要求"上传 N 个产品"。流程：
1. `sessions_spawn(browser)` 爬店铺 productlist 翻页，拿 URL+price+MOQ+缩略图
2. Python 脚本下载主图到 `products/p{NN}.jpg` 自托管
3. 英文标题从 URL slug 反推（slug 即 SEO 友好长标题）
4. 4 语言用关键词词典批量翻（专业术语保英文，长句机翻可接受）
5. SKU 自动生成 `<brand>-<category>-NN`
6. 通用 baseline specs 给每款（材质/认证/耐温/质保/MOQ/包装/交期）
7. 推送：`data.json` + 全部图片走 Contents API

**禁止**：把单款产品手动塞 50 次。

---

## §6 内容结构铁律

### §6.1 首页 7 大模块（顺序锁死）

1. Hero 大轮播（3 张 21:9）
2. 4 项 stats 横条（深色背景 + 大字）
3. Why Us 6 张卡片
4. 3 大产品线入口
5. 6 类合作客户（按行业不按 logo，避免侵权）
6. 4 大服务市场（按地理区块，从阿里店铺真实数据来）
7. 页脚

### §6.2 内部页面（仅 ?staff / ?admin 可见）

- 客户画像 (`staff_intel`)
- 话术 SOP (`staff_sop`)

字段格式：`{cat, t, c}` —— **不要做 i18n**，内部页面只给员工看一种语言。

### §6.3 业务定位决定配色

| 行业 | 主色 | 强调 | 文字 | 背景 |
|---|---|---|---|---|
| 工业重型/B2B 装备 | 深蓝 #0A4A8C | 警示橙 #F26B1F | 深墨 #0F172A | #F7F9FC |
| 食品/烘焙/家居消费品 | 暖红 #C84520 | 蜂蜜橙 #E89B3A | 烤面包棕 #3D2817 | #FBF6EE |
| 美妆/医疗/科技 | 紫蓝 #5B47C2 | 樱粉 #F76C8F | 深墨 #0F172A | #F8F7FF |
| 户外/运动/绿能 | 森绿 #2E7D5B | 砂橙 #E8924B | 深墨 #0F172A | #F5FAF6 |

**禁止行为**：所有项目都用工业蓝。配色不匹配品类 = 第一眼就让买家觉得"哦这是个工厂代加工"。

---

## §7 项目初始化清单（首次交付强制）

主公给一个店铺链接后，**首版必须自带**：

- [x] **16 语言（EN/ZH/DE/ES/FR/IT/PT/NL/RU/TR/JA/KO/TH/VI/HI/AR）全字段覆盖**（v1.2 标准）
- [x] **全屏语言弹窗**（4 地理分组 × 4 列网格 + RTL 阿语支持）
- [x] 3 级权限（公开 / `?staff` 软密码 / `?admin` PAT）
- [x] 7 大首页模块（Hero / Stats×4 / Why×6 / Cats×3 / Partners×6 / Regions×4 / Footer）
- [x] 5 个子页全部带 `.page-back` 返回首页按钮
- [x] catalog 页带 `.catalog-sticky` sticky 工具条
- [x] 所有 H2 + 品牌名 + 语言切换器 `translate="no"`
- [x] favicon + apple-touch-icon
- [x] admin 后台可编辑 10 类区块 + 自动翻译 + 图片上传
- [x] 中文操作手册 `交接说明.md`（10 章节）
- [x] 客户 + admin 两张二维码 PNG
- [x] 部署完成后用 curl 验证 3 个 URL HTTP 200
- [x] 配色匹配品类（§6.3）

**不需要再问主公**：颜色、stats 选哪 4 项、子页结构、PAT 怎么生成、二维码要不要。这些都已经决定好了。

**仍要问主公**：
- 真实成立年份（若做 "X 年经验" 数据则需要）
- 真实销售邮箱
- 是否有真 LOGO（无则用占位等后续上传）
- 仓库短名（≤5 字符，默认按品牌英文缩写）

---

## §8 部署失败时的降级清单

| 失败模式 | 处理 |
|---|---|
| git push 卡住 / HTTP/2 错误 | §1.1 切 Contents API |
| Contents API 返回 422 sha conflict | 再读一次 sha 重试 |
| 单个文件大于 100MB | GitHub Pages 不支持，必须先压缩或换 CDN |
| Pages 构建失败（rare） | 看 `https://api.github.com/repos/{o}/{r}/pages/builds/latest` 的 error.message |
| CDN 缓存未刷新 | URL 加 `?b=$(uuidgen)` 强制旁路；正常情况 30-60s 内生效 |

---

## §9 主公风格备忘

- 喜欢"一步到位" — 第一版就要有 50 款产品而不是 8 款样品
- 喜欢"配色暖" — 食品行业坚决不要工业蓝
- 不喜欢"画饼" — 任何不可证的硬数据立即砍
- 喜欢"返回键醒目" — 视觉链接不够，需要白底圆角按钮
- 喜欢"子页清爽" — 重复的 eyebrow 一定去
- 喜欢"产品列表 sticky" — 浏览 50+ 产品时工具条必须吸顶

---

📅 v1.1 沉淀于 2026-06-28（双站同款 v1.1：返回键 + sticky + 防机翻 + 4 语）
📅 v1.2 沉淀于 2026-06-28（16 语 + 全屏弹窗选择器 + RTL + 批量机翻 SOP）
🏗 项目：QIDA Recycling (qdr) + XinNeng Silicone (xns)
👤 主公账号：tbj88（GitHub Pages 主站）
🔖 参考实现：[xns/index.html](../../agents/DID-D464A3-01D464A3U1779101-1466-7B9611/project/xns/index.html) 含完整 16 语 LANGS + LANG_GROUPS + openLangModal/closeLangModal + RTL CSS
