#!/usr/bin/env python3
"""8 模块子图 -> 4 张交付图（宽度统一 1500px）。

用法:
    python3 merge_4.py <详情文件夹>

约定输入: <文件夹>/raw/01_*.jpg ... 08_*.jpg (按序号前缀匹配)
输出: D1..D4 四张交付图 + 99_完整详情长图.jpg
"""
import os
import sys
import glob

from PIL import Image

WIDTH = 1500
MAX_BYTES = 3 * 1024 * 1024
QUALITY_STEPS = (92, 88, 82, 78, 72)

PAIRS = [
    ("D1_Banner+价值主张.jpg", ("01", "02")),
    ("D2_卖点+尺寸.jpg", ("03", "04")),
    ("D3_爆炸图+安装流程.jpg", ("05", "06")),
    ("D4_场景+认证.jpg", ("07", "08")),
]

SEPARATOR_H = 2
SEPARATOR_COLOR = (229, 229, 229)


def find_module(raw_dir, seq):
    hits = sorted(glob.glob(os.path.join(raw_dir, f"{seq}_*.jpg")))
    if not hits:
        hits = sorted(glob.glob(os.path.join(raw_dir, f"{seq}_*.png")))
    if not hits:
        raise FileNotFoundError(f"缺少模块 {seq} 的图片: {raw_dir}/{seq}_*.jpg")
    return hits[0]


def load_scaled(path):
    img = Image.open(path).convert("RGB")
    h = round(img.height * WIDTH / img.width)
    return img.resize((WIDTH, h), Image.LANCZOS)


def stack(images, separator=True):
    gap = SEPARATOR_H if separator else 0
    total_h = sum(i.height for i in images) + gap * (len(images) - 1)
    canvas = Image.new("RGB", (WIDTH, total_h), SEPARATOR_COLOR)
    y = 0
    for idx, img in enumerate(images):
        canvas.paste(img, (0, y))
        y += img.height
        if separator and idx < len(images) - 1:
            y += gap
    return canvas


def save(img, path):
    for q in QUALITY_STEPS:
        img.save(path, "JPEG", quality=q, optimize=True, progressive=True)
        if os.path.getsize(path) <= MAX_BYTES:
            break
    return os.path.getsize(path)


def main():
    if len(sys.argv) < 2:
        sys.exit("用法: python3 merge_4.py <详情文件夹>")
    base = os.path.abspath(os.path.expanduser(sys.argv[1]))
    raw_dir = os.path.join(base, "raw")
    if not os.path.isdir(raw_dir):
        sys.exit(f"未找到 raw 目录: {raw_dir}")

    delivered = []
    for out_name, seqs in PAIRS:
        imgs = [load_scaled(find_module(raw_dir, s)) for s in seqs]
        merged = stack(imgs)
        out_path = os.path.join(base, out_name)
        size = save(merged, out_path)
        delivered.append(out_path)
        print(f"[OK] {out_name}  {merged.width}x{merged.height}  {size/1024/1024:.2f}MB")

    full = stack([Image.open(p).convert("RGB") for p in delivered], separator=False)
    full_path = os.path.join(base, "99_完整详情长图.jpg")
    size = save(full, full_path)
    print(f"[OK] 99_完整详情长图.jpg  {full.width}x{full.height}  {size/1024/1024:.2f}MB")
    print(f"\n发品只需上传 D1~D4 这 4 张，目录: {base}")


if __name__ == "__main__":
    main()
