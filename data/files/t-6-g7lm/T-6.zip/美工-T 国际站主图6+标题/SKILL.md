---
name: 美工-T 国际站主图6+标题
description: >
  阿里国际站 B2B 爆品「主图+附图」出图与归档一体化技能包。用户上传产品图（或产品链接/产品名）并要求
  「出图 / 做主图 / 生成主图附图 / 做一套国际站图」时触发：自动识别行业 → 套用爆品标题与卖点 →
  以原图为参考用 image_edit 生成「白底主图 + 4 张附图 + 1 张 A+ 风格多模块信息图」（产品本体 100% 不改）→ 转 jpg →
  以「文件夹为单位」归档到 ~/Desktop/图片优化/主图/（文件夹名=序列号+产品名）→ 配套文案存 txt。
  触发关键词：出图、做主图、生成主图、主图附图、做一套图、国际站图、爆品图出图、白底图+附图、
  A+信息图、多模块信息图、卖点信息图、hero image set、listing images、把这张图做成主图。
  适用场景：用户已提供产品图片并明确要"出图/生成成品图"，需要落地为本地归档的成品图集时触发。
  与 b2b-bestseller-title-image 配合：后者只出文案方案，本技能负责把方案变成成品图并归档。
license: 内部使用
---

# 阿里国际站 B2B 爆品主图出图 + 归档一体化技能包

> **一句话定位**：用户给产品图 → 产出「白底主图 + 4 附图」成品 jpg + 配套文案 txt → 以文件夹为单位归档到本地。
> **铁律**：产品本体 100% 不修改（形状/颜色/网纹/比例都不动），只做白底 / 加标签 / 换场景 / 排版。

---

## 0. 执行前必读（硬约束）

1. **产品不可改**：所有 image_edit 的 prompt 必须显式写「Keep the product 100% unchanged」。
2. **必须用 image_edit（不是 image_generate）**：用户上传了原图 → 一律以原图为 `reference_images` 调 `image_edit`。
3. **面向买家文案一律英文**；禁用 Best/Top1 等极限词；禁止中文/乱码出现在图上。
4. **标题与卖点来源**：若上一步已用 `b2b-bestseller-title-image` 出过方案，直接复用；否则先按该技能的规则快速生成标题+卖点，再出图。
5. **归档格式见 §4，不可省略**（jpg + 文件夹为单位 + 文案 txt）。
6. **文案数量铁律（见 §3）**：每次交付，**标题必须 5 条中英文对照**、**卖点必须 >8 点（≥9 条）中英文对照**。数量不足不得交付。

---

## 1. 6 张标准图集结构

| 序号 | 类型 | 内容 | 英文配文 | task_type |
|------|------|------|----------|-----------|
| 01 | 主图 | 产品 45° 全景、纯白底、右上角核心标签(OEM Available/Hot Sale 等) | 标签词 | `simple_generation` |
| 02 | 附图·细节 | 关键部件/材质/接口特写 | Durable Material / Fine Workmanship | `complex_generation` |
| 03 | 附图·规格 | 多尺寸/多配色对比 | Multiple Sizes & Colors | `complex_generation` |
| 04 | 附图·场景 | 海外 B 端使用场景（超市/工厂/仓库/工地等） | Wide Application / 行业场景词 | `complex_generation` |
| 05 | 附图·工厂 | 生产线/堆叠/认证(ISO/CE) | Certified Product / OEM Service | `complex_generation` |
| 06 | A+ 信息图主图 | 单张正方形浓缩 5 模块（主图+定制+内部/使用+场景+卖点条），亚马逊 A+ 风格 | 见 §1.6 | `complex_generation` |

> 行业专属的标签词、场景、卖点参照 `b2b-bestseller-title-image` 第 4 章 8 大行业速查表；不在表内走通用兜底。
> **第 06 张（A+ 信息图）的完整做法见 §1.6**，由「卢 亚马逊 A+ 风格多模块产品信息图」整合而来。

---

## 1.6 第 06 张：A+ 风格多模块信息图主图（整合自「卢」技能）

> 这是在原 5 张基础上**新增的第 6 张**。把完整产品故事——主图+定制+内部/使用+场景+卖点条——浓缩进**单张正方形（1:1）**信息图。原 01-05 张做法不变，此张为附加增项。
> **铁律仍适用**：产品本体 100% 不改（参考图锁定外观）。默认英文。

### 1.6.1 核心逻辑：双图参考 + 模块化分段

1. **双图参考**：
   - 参考图1 = 产品照片 → 锁定本体，prompt 写 "keep ... fully consistent — do NOT alter or reimagine the product appearance"。
   - 参考图2 = 版式模板图（可选）→ 锁定结构，prompt 写 "replicate its module structure, proportions and styling precisely"。只给产品图时，用已确认的版式描述当蓝本。
2. **模块化分段**：每个区域用「位置+标题文字+内容」描述，图上所有文字加引号；始终要求 English only、correctly spelled、legible、no overlapping text。

### 1.6.2 五个固定模块

| # | 模块 | 位置 | 内容蓝本 |
|---|------|------|---------|
| 1 | 主图 Hero | 左上 | 粗体藏青大标题 + 绿色副标题 + 标语；一排 4 个圆形功能图标带标签；产品真实场景大幅主图 |
| 2 | 定制 Customize | 右上 | 绿色标题栏 "CUSTOMIZE YOUR {产品}"；COLOR OPTIONS(3-4色块)；DOOR & WINDOW OPTIONS(缩略图)；SIZE OPTIONS "{小}/{中}/{大}" + "More sizes available to fit your space" |
| 3 | 内部/使用 Interior | 右中 | 打开/剖切视角，展示有序内部或使用中的内容 |
| 4 | 场景 Scenes | 左下 | 绿色标题栏 "PERFECT FOR VARIOUS SCENES" + 4 张缩略图各带标签 |
| 5 | 卖点条 Feature Strip | 底部 | 一排 6 个灰色圆形特写带"标题/副标题"；右下藏青色块含 3 个白色图标+标签 |

> 模块骨架固定；**文字内容按产品真实卖点改写**。不编造规格/数字，不确定就用通用功能性措辞。

### 1.6.3 提示词模板（填好所有 {...} 占位）

```
Create a professional Amazon A+ style multi-module infographic for {PRODUCT}, English only, square 1:1 layout.
STYLE: {STYLE CLAUSE — see presets}. Use the reference image as the exact product (keep the {product key features}
fully consistent — do NOT alter or reimagine the product appearance). [If layout image provided: Use the SECOND
reference image as the exact layout template — replicate its module structure, proportions and styling precisely.]

TOP-LEFT HERO MODULE: Bold dark-navy headline "{HEAD1}" with green sub-headline "{HEAD2}", small tagline "{TAGLINE}".
A row of 4 small circular feature icons with labels: "{ICON1}", "{ICON2}", "{ICON3}", "{ICON4}". Large hero photo of
{product} in a sunny {scene}.

TOP-RIGHT CUSTOMIZE MODULE: A green header bar "CUSTOMIZE YOUR {PRODUCT}". "COLOR OPTIONS" with {N} swatches
({color list}). "DOOR & WINDOW OPTIONS" row of small thumbnails. "SIZE OPTIONS" in green text "{S} / {M} / {L}"
with line "More sizes available to fit your space".

RIGHT-MIDDLE INTERIOR MODULE: A photo looking into the open {product} showing {interior/usage content}.

BOTTOM-LEFT SCENES MODULE: A green header bar "PERFECT FOR VARIOUS SCENES" with 4 photo thumbnails labeled
"{SCENE1}", "{SCENE2}", "{SCENE3}", "{SCENE4}".

BOTTOM FEATURE STRIP: A row of 6 grey circular close-up detail shots with captions: "{F1} / {S1}", "{F2} / {S2}",
"{F3} / {S3}", "{F4} / {S4}", "{F5} / {S5}", "{F6} / {S6}". At the bottom-right a dark-navy block with 3 white icons
and labels: "{B1} / {b1}", "{B2} / {b2}", "{B3} / {b3}".

All text must be clear, correctly spelled, legible English, well-positioned without overlapping. Maintain a clean,
professional, balanced e-commerce infographic layout. Do NOT add any text or elements not specified in the prompt.
```

占位对照：`{PRODUCT}`=产品名；`{HEAD1/2}`=主/副标题；`{TAGLINE}`=标语；`{ICON1-4}`=4功能图标；`{scene}`=主图场景；`{N}`=颜色数；`{color list}`=颜色清单；`{S/M/L}`=尺寸；`{interior/usage content}`=内部内容；`{SCENE1-4}`=4场景标签；`{F1-6}/{S1-6}`=6卖点标题/副标题；`{B1-3}/{b1-3}`=底部3图标标题/副标题。

### 1.6.4 风格预设（要多风格变体时，只改 STYLE 句并行跑）

| 风格 | STYLE 描述句 |
|------|-------------|
| Default Clean 默认简洁 | clean white background with green and dark-navy accent colors |
| Fresh Botanical 清新植物 | soft light-green and cream/off-white background, rounded-corner cards with gentle soft shadows, airy spacious whitespace, hand-drawn leaf accents, friendly modern sans-serif typography, warm natural daylight mood |
| Modern Dark Tech 暗黑科技 | deep charcoal-black and dark forest-green background, bright neon-green accent highlights, sharp thin grid lines and angular geometric frames, bold condensed uppercase typography, premium high-tech industrial mood with subtle glow |
| Warm Lifestyle 温馨生活 | warm beige and terracotta tones, soft lifestyle photography, cozy home-garden mood, serif + sans mix typography |
| Bold Promo 醒目促销 | high-contrast bold colors, large price/benefit callouts, energetic sale-banner style, thick borders |

### 1.6.5 工具设置（此张专用）

- 工具 `image_edit`；`task_type="complex_generation"`（多区域合成必须）；`aspect_ratio="1:1"`；`resolution="2K"`（文字多需清晰）。
- `reference_images`：`[产品照片]` 或 `[产品照片, 版式模板]`。
- 多风格 = 模块不变、只换 STYLE 句，并行发 N 次 `image_edit`。

### 1.6.6 此张专属避坑

- **CDN 参考图加载失败**（alicdn 防盗链/0字节）：先带 UA+referer 下载到本地再传本地路径。Mac：`curl -sL -A "Mozilla/5.0..." -e "https://www.alibaba.com/" -o ref.jpg "{URL}"`。
- **"terminated"/临时报错**：直接重试一次。
- **不编造规格数字**；**锁死产品本体**（"do NOT alter or reimagine the product appearance" 必写）。

### 1.6.7 归档（沿用汤的 §4 铁律）

第 06 张和 01-05 一起归档进同一个产品文件夹，文件名按汤规范：`产品名_06_A+信息图_日期.jpg`（png→jpg 转换同 §4）。

---

## 2. 出图执行规范

### 2.1 工具与参数
- 工具：`image_edit`
- `reference_images`：用户原图 URL（始终传入）
- `aspect_ratio`：`1:1`（主图/附图默认正方形，符合国际站规范）
- `resolution`：默认 `1K`，用户要高清可 `2K`

### 2.2 prompt 构造模板（按图类型填空）

**主图（01）**
```
Place this exact <产品英文名+关键特征> on a pure clean white background, professional B2B e-commerce main image. Keep the product 100% unchanged - do not alter its shape, color, pattern, or proportions. Product shown at 45-degree angle, centered, ~80% of frame. Soft studio lighting, subtle shadow. Add a small clean badge in the top-right corner with text "<核心标签>". Photorealistic, high resolution.
```

**细节图（02）**
```
Create a B2B detail close-up image using this exact <产品> as reference. Keep the product 100% unchanged. Show macro close-ups of key parts: <部件1/部件2/部件3>. Clean light-grey gradient studio background. Add clean English caption "<配文>". Photorealistic, professional product photography.
```

**规格图（03）**
```
Create a B2B spec comparison image using this exact <产品> as reference. Keep the product shape/design 100% unchanged. Show the same product in <N> color/size variants side by side. Clean white studio background. Add caption "Multiple Sizes & Colors". Photorealistic, catalog style.
```

**场景图（04）**
```
Create a B2B lifestyle scene image using this exact <产品> as reference. Keep the product 100% unchanged. Show several of them in use inside a <海外 B 端场景，如 modern Western supermarket / factory / warehouse>. Realistic lighting. Add caption "<行业场景配文>". Photorealistic, commercial photography.
```

**工厂图（05）**
```
Create a B2B factory-endorsement image using this exact <产品> as reference. Keep the product 100% unchanged. Show many of them stacked/nested in rows inside a clean modern factory warehouse, conveying mass production. Include small ISO/CE certification badge icons in a corner. Add caption "Certified Product - OEM Service". Photorealistic, industrial photography.
```

### 2.3 执行节奏
- 一次最多并行 3 张，分批跑完 6 张（避免单轮过多）。
- 每张拿到 Image URL 后记录，6 张齐了再进入归档。
- 第 06 张 A+ 信息图按 §1.6 单独构造 prompt（complex_generation / 2K），与 01-05 一并归档。

---

## 3. 归档前生成配套文案

整理一份纯文本文案，含：
1. 产品识别（行业 + 核心关键词）
2. **爆品标题：必须 5 条（中英文对照），每条标字符数（英文≤128）。1 条主推 + 4 条备选，含「主推 / 词序变体 / 长尾词 / 批发定制角度 / 场景应用角度」不同切入。**
3. **产品卖点：必须 >8 点（即 ≥9 条），每条中英文对照，并标维度（品质/功能/定制/批发/服务/认证/包装/交期 等）。**
4. 图片清单：序号 ↔ 名称 ↔ 英文配文
5. 上架前自检提醒（标签拼写核对、认证/容量按真实情况替换、定制周期标注等）

> **交付铁律（不可省略）**：标题恰好 5 条、卖点至少 9 条，且**全部中英文对照**。数量不达标视为未完成，必须补齐后再归档与交付。

---

## 4. 归档规范（铁律 · 以文件夹为单位）

> 用户固定偏好（已写入长期记忆，2026-06-13）。每次出图任务都按此归档，无需再问。

- **根目录**：`~/Desktop/图片优化/主图/`
- **每次任务建一个独立子文件夹**，命名：`序列号+产品名称`
  - 序列号两位、自动递增（扫描根目录已有 `NN_` 文件夹取下一个号，如已有 `01_xxx` → 新建 `02_xxx`）
  - 例：`01_超市购物车`、`02_不锈钢管件`
- **图片格式默认 jpg**（png 下载后用 `sips -s format jpeg` 转 jpg）
- **图片文件名**：`产品名_序号_类型_日期`（如 `超市购物车_01_主图_白底OEM标签_20260613.jpg`）
- **文案文件**：同文件夹内 `产品名_文案_日期.txt`

### 4.1 归档脚本骨架（bash）
```bash
setopt NULL_GLOB 2>/dev/null || shopt -s nullglob 2>/dev/null
BASE="$HOME/Desktop/图片优化/主图"
# 1) 计算下一个序列号
seq=1
for d in "$BASE"/[0-9][0-9]_*/; do
  [ -d "$d" ] || continue
  n=$(basename "$d" | cut -d_ -f1); n=$((10#$n))
  [ "$n" -ge "$seq" ] && seq=$((n+1))
done
SEQ=$(printf "%02d" "$seq")
FOLDER="$BASE/${SEQ}_<产品名>"
mkdir -p "$FOLDER"
DATE=$(date +%Y%m%d)
# 2) 下载每张图为 png → 转 jpg（命名 产品名_序号_类型_日期.jpg）
#    curl -fsSL "<imgurl>" -o "$FOLDER/<产品名>_01_主图_白底OEM标签_${DATE}.png"
#    sips -s format jpeg "$FOLDER/xxx.png" --out "$FOLDER/xxx.jpg"
# 3) 默认只留 jpg（按需删 png）；写入文案 txt
```

> 如用户未明确，默认 png 与 jpg 都保留；用户说「只留 jpg」时删 png。

---

## 5. 标准交付（出图完成后给用户）

1. 在对话内用 markdown `![](url)` 内联展示 6 张成品图（按 01-06 顺序，06 为 A+ 信息图）
2. 附 5 条中英文标题 + >8 点中英文卖点（按 §3 数量铁律，对话内完整展示，不只给一行速览）
3. 报告归档路径：`~/Desktop/图片优化/主图/NN_产品名/` 及文件清单
4. 提醒：AI 图英文小字标签可能变形、认证/容量按真实情况替换
5. 询问是否需要调整某张图 / 是否只留 jpg / 是否继续下一个产品

---

## 6. 避坑

| 项 | 红线 |
|----|------|
| 产品本体 | 任何 prompt 都不能改产品形状/颜色/比例，必须写 Keep 100% unchanged |
| 场景图 | 用海外 B 端场景，不用纯国内场景 |
| 认证 | ISO/CE 等 logo 提示按真实情况，避免虚标（海外买家会核查） |
| 文字 | AI 生成英文小字易变形，交付时提醒人工核对拼写 |
| 归档 | 必须文件夹为单位 + 序列号递增 + jpg，不可散放根目录 |
